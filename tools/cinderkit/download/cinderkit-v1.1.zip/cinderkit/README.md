# CinderKit

CinderKit is a no-build static website starter kit for small websites, landing pages, product experiments, and client launch pages.

You get plain HTML, CSS, and JavaScript. No npm. No framework. No lockfile. No build step. Open the files, edit the copy, and deploy the folder.

## What is included

```
cinderkit/
├── index.html       # Complete starter page
├── styles.css       # Theme tokens, layout, components, responsive rules
├── main.js          # Optional nav, modal, toast, smooth scroll, form checks
├── 404.html         # Matching not-found page
├── robots.txt       # Search crawler template
├── sitemap.xml      # Sitemap template
├── _headers         # Cloudflare Pages / Netlify header preset
├── vercel.json      # Vercel header preset
├── LICENSE.txt      # Use-it-freely license note
└── assets/
    ├── logo.svg
    ├── favicon.svg
    ├── og-image.svg
    └── screenshot.svg
```

## Quick start

1. Unzip the folder.
2. Open `index.html` in your browser.
3. Replace the project name, headline, CTA links, and section copy.
4. Update the colors in `:root` inside `styles.css`.
5. Replace the files in `assets/` with your logo, favicon, social image, and screenshot.
6. Update `robots.txt`, `sitemap.xml`, and the canonical/social URLs in `index.html`.
7. Deploy the whole folder to any static host.

## Pair it with Website Launch Kit

CinderKit gives you the editable website starter. Website Launch Kit can generate or review the launch files around it: meta tags, robots.txt, sitemap.xml, legal drafts, security headers, and a launch checklist.

Suggested flow:

1. Build the page with CinderKit.
2. Run the Website Launch Kit preflight with your site name, URL, host, and compliance needs.
3. Compare the generated metadata and security headers with the starter files.
4. Replace the placeholder files before publishing.

## Deploy notes

### Cloudflare Pages

Upload this folder or connect the repository. The `_headers` file can live at the project root for a no-build static site.

### Netlify

Drag-and-drop the folder or connect the repository. Netlify also supports the root `_headers` file when it is in the published directory.

### Vercel

Deploy the folder as a static project. `vercel.json` contains the response header preset.

### GitHub Pages

GitHub Pages will ignore `_headers` and `vercel.json`, but the site still works as static HTML. Configure headers through your fronting CDN if needed.

## Editing checklist

- [ ] Page title and meta description
- [ ] Canonical URL and social URLs
- [ ] Logo, favicon, and social image
- [ ] Hero headline and CTA
- [ ] Feature cards and proof points
- [ ] Contact or signup form endpoint
- [ ] `robots.txt` sitemap URL
- [ ] `sitemap.xml` URLs and dates
- [ ] Security headers for your host
- [ ] 404 page copy

## Forms

The sample signup form uses a placeholder `action="#"`. Replace it with your form provider or server endpoint.

The JavaScript includes two basic spam checks:

- a hidden honeypot field named `_gotcha`
- a time check that blocks submissions made too quickly

If you use an external form provider, update `form-action` in your Content Security Policy.

## License

Use CinderKit for personal projects, client work, experiments, and commercial launches. Attribution is appreciated but not required.

Built by Matt Livingston: https://mattlivingston.com
