# Security Policy

## Supported Versions

Security fixes target the current `1.x` release line.

## Reporting Vulnerabilities

Report suspected vulnerabilities through the support channel listed on the Script Shed Form Inbox page. Do not post private exploit details publicly before maintainers have had time to respond.

## Deployment Guidance

- Put `storage-private/` outside the public web root whenever possible.
- Keep `config.php` private and never expose password hashes.
- Delete `tools/generate-password.php` after setup.
- Use HTTPS for administrator sessions and public form endpoints.
- Use restrictive file permissions for private data and attachments.
- Keep attachment uploads disabled unless you need them.

## Important Limits

Public form tokens are visible in browser HTML. They prevent accidental or malformed posts, but they are not passwords.

Allowed-origin checks and CORS reduce casual abuse, but they do not prove a request came from the legitimate webpage. Server-side validation, rate limiting, honeypots, and attachment restrictions are still required.

Extension and MIME checks do not guarantee uploaded files are harmless. Treat unexpected files cautiously and use local antivirus or host malware scanning.

PHP `mail()` can fail silently later in the delivery chain. Form Inbox records whether `mail()` returned success, but that is not proof of final delivery.
