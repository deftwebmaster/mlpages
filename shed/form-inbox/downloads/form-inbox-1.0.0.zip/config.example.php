<?php

declare(strict_types=1);

return [
    'app_name' => 'Form Inbox',
    'tagline' => 'A private form backend for static websites.',
    'base_url' => 'https://forms.example.com',
    'timezone' => 'America/Chicago',

    'admin_password_hash' => 'REPLACE_WITH_PASSWORD_HASH',
    'session_timeout_minutes' => 30,

    'storage_path' => __DIR__ . '/storage-private',
    'attachment_path' => __DIR__ . '/storage-private/attachments',

    'default_sender_email' => 'forms@example.com',
    'default_sender_name' => 'Form Inbox',
    'default_notification_recipients' => [],
    'mail_transport' => 'php_mail',

    'maximum_request_bytes' => 26214400,
    'maximum_fields' => 50,
    'maximum_field_name_length' => 100,
    'maximum_field_bytes' => 20000,
    'maximum_array_depth' => 2,

    'backup_retention' => 10,
    'trash_retention_days' => 30,
    'spam_retention_days' => 30,
    'rejected_event_limit' => 500,

    'rate_limit_requests' => 5,
    'rate_limit_window_seconds' => 600,
    'duplicate_window_seconds' => 60,
    'visitor_hash_salt' => 'CHANGE_THIS_RANDOM_LONG_VALUE',

    'track_referrer' => true,
    'track_device_category' => true,
    'store_raw_ip' => false,

    'accent_color' => '#2563eb',
    'admin_footer' => 'Form Inbox is free PHP software from the Script Shed.',
    'support_url' => 'https://mattlivingston.com/shed/form-inbox/',
    'documentation_url' => 'https://mattlivingston.com/shed/form-inbox/',
    'public_attribution' => true,

    'routing_mode' => 'rewrite',
    'debug' => false,
];
