# Form Inbox

Form Inbox is a self-hosted PHP form backend for static websites. Create a private form endpoint, point any ordinary HTML form at it, and read submissions in a browser-based inbox.

It uses PHP 8.2+, JSON flat files, local assets, PHP sessions, and the host's configured `mail()` transport. It does not use SQL, Composer, Node.js, a frontend framework, or a third-party form service.

## Features

- Single administrator login with secure sessions, CSRF tokens, and login rate limiting.
- Multiple registered form endpoints at `/submit/{slug}` plus `submit.php?form={slug}` fallback.
- Public form tokens, allowed-origin checks, CORS preflight support, honeypot checks, timing checks, duplicate suppression, and flat-file rate limiting.
- Flexible fields by default, optional schema validation for required fields and typed values.
- Segmented JSON submission storage with locked atomic writes and a rebuildable index.
- Inbox search, filtering, status changes, spam/trash views, submission detail pages, CSV export, backups, diagnostics, and optional private attachments.
- Email notifications through PHP `mail()` with Reply-To safely set from a configured visitor email field.

## Requirements

- PHP 8.2 or newer
- Apache with `mod_rewrite` recommended
- Writable private storage directory
- PHP extensions: JSON and sessions required, Fileinfo recommended, ZipArchive recommended

## Installation

1. Upload the files to a PHP-capable host.
2. Move `storage-private/` outside the public web root when your host allows it.
3. Copy `config.example.php` to `config.php`, or edit the included `config.php`.
4. Set `base_url`, `timezone`, `storage_path`, `attachment_path`, sender email, and administrator password hash.
5. Open `/tools/generate-password.php`, generate a password hash, paste it into `config.php`, then delete the helper.
6. Ensure `data/`, `attachments/`, `backups/`, `logs/`, `locks/`, and `temporary/` are writable.
7. Open `/admin/login.php`, log in, create a form, and copy the generated integration HTML.

## Static HTML Example

```html
<form action="https://forms.example.com/submit/contact" method="post">
    <input type="hidden" name="_form_token" value="PUBLIC_FORM_TOKEN">
    <input type="hidden" name="_form_loaded_at" value="UNIX_TIMESTAMP">

    <label>Name <input type="text" name="name" required></label>
    <label>Email <input type="email" name="email" required></label>
    <label>Message <textarea name="message" required></textarea></label>

    <div style="position:absolute; left:-10000px; width:1px; height:1px; overflow:hidden;" aria-hidden="true">
        <label>Website <input type="text" name="_website" tabindex="-1" autocomplete="off"></label>
    </div>

    <button type="submit">Send</button>
</form>
```

For JavaScript `fetch()` submissions from another domain, add the exact page origin, such as `https://example.com`, to the form's allowed origins. Form Inbox never returns wildcard CORS headers for configured browser integrations.

## Nginx Example

```nginx
location /submit/ {
    rewrite ^/submit/([a-zA-Z0-9-]+)/?$ /submit.php?form=$1 last;
}

location ~ ^/(storage-private|includes|templates|bin)/ {
    deny all;
}

location ~ /(config|config\.example)\.php$ {
    deny all;
}
```

## Email Notes

Version 1 uses PHP `mail()`. A successful `mail()` call means the host accepted the message for delivery; it does not guarantee the email reached the final inbox. Form Inbox stores valid submissions before notification attempts, so mail failures are visible in the admin dashboard and can be retried.

Use a sender address owned by the PHP host domain. Visitor email addresses are used only as `Reply-To` when configured.

## Privacy

By default Form Inbox does not store raw visitor IP addresses, does not set tracking cookies, strips referrer query strings, stores only broad device categories, and keeps visitor hashes only for abuse prevention.

## Maintenance

Run manually or from cron:

```sh
php bin/maintenance.php
php bin/rebuild-index.php
```

The app still works without cron.

## Scalability

Form Inbox is designed for small and medium static sites with hundreds or low thousands of submissions. Very high-volume forms should use a database-backed or dedicated form-processing service.
