<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/bootstrap.php';
fi_send_admin_headers();
fi_require_admin();
$pageTitle = 'Backups';
$backups = fi_backup_list();
ob_start();
?>
<form class="toolbar" method="post" action="actions/create-backup.php"><?= fi_csrf_field() ?><button type="submit">Create backup</button></form>
<?php if ($backups === []): ?><div class="panel"><p class="muted">No backups yet.</p></div><?php else: ?>
<table><thead><tr><th>Name</th><th>Created</th><th>Size</th></tr></thead><tbody>
<?php foreach ($backups as $backup): ?><tr><td><?= fi_h($backup['name']) ?></td><td><?= fi_h($backup['created_at']) ?></td><td><?= number_format((int) $backup['size'] / 1024, 1) ?> KB</td></tr><?php endforeach; ?>
</tbody></table>
<?php endif; ?>
<?php
$content = ob_get_clean();
require fi_root_path('templates/admin-layout.php');
