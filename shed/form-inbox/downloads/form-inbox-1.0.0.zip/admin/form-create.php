<?php

declare(strict_types=1);

require_once __DIR__ . '/../includes/bootstrap.php';
fi_send_admin_headers();
fi_require_admin();
$pageTitle = 'Create Form';
$form = fi_form_defaults(['name' => '', 'slug' => '']);
$action = 'actions/form-create.php';
ob_start();
require fi_root_path('templates/components/form-editor.php');
$content = ob_get_clean();
require fi_root_path('templates/admin-layout.php');
