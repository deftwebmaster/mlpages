<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/bootstrap.php';
fi_send_admin_headers();
fi_require_admin();
$pageTitle = 'Settings';
$config = fi_config();
ob_start();
?>
<section class="panel">
    <h2>Configuration</h2>
    <table><tbody>
    <?php foreach (['app_name','base_url','timezone','storage_path','attachment_path','default_sender_email','mail_transport','maximum_request_bytes','track_referrer','track_device_category','store_raw_ip','debug'] as $key): ?>
        <tr><th><?= fi_h($key) ?></th><td><?= fi_h(is_bool($config[$key] ?? null) ? (($config[$key] ?? false) ? 'true' : 'false') : (string) ($config[$key] ?? '')) ?></td></tr>
    <?php endforeach; ?>
    </tbody></table>
    <p class="muted">Edit <code>config.php</code> to change global settings. Form-specific settings are managed from the Forms screen.</p>
</section>
<?php
$content = ob_get_clean();
require fi_root_path('templates/admin-layout.php');
