<?php
declare(strict_types=1);
require_once __DIR__ . '/../../includes/bootstrap.php';
fi_stream_attachment((string) ($_GET['submission'] ?? ''), (string) ($_GET['attachment'] ?? ''));
