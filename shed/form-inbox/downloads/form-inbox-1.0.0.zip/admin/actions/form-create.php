<?php
declare(strict_types=1);
require_once __DIR__ . '/../../includes/bootstrap.php';
fi_require_admin();
fi_require_csrf();
try {
    $form = fi_form_create(fi_form_from_post());
    fi_admin_flash('Form created.', 'success');
    fi_redirect(fi_admin_url('form-edit.php?id=' . rawurlencode($form['id'])));
} catch (Throwable $e) {
    fi_admin_flash($e->getMessage(), 'error');
    fi_redirect(fi_admin_url('form-create.php'));
}
