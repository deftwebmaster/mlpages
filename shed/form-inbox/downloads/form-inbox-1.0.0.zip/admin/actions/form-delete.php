<?php
declare(strict_types=1);
require_once __DIR__ . '/../../includes/bootstrap.php';
fi_require_admin();
fi_require_csrf();
$id = (string) ($_POST['id'] ?? '');
$mode = (string) ($_POST['mode'] ?? 'archive');
$forms = fi_forms_all();
$found = false;
try {
    fi_backup_create('before-form-delete');
    foreach ($forms as $index => $form) {
        if (($form['id'] ?? '') !== $id) {
            continue;
        }
        $found = true;
        if ($mode === 'delete_config') {
            unset($forms[$index]);
        } else {
            $forms[$index]['status'] = 'archived';
            $forms[$index]['updated_at'] = fi_now();
        }
        break;
    }
    if (!$found) {
        throw new RuntimeException('Form not found.');
    }
    fi_forms_save($forms);
    fi_admin_flash($mode === 'delete_config' ? 'Form configuration deleted. Submissions were retained.' : 'Form archived.', 'success');
} catch (Throwable $e) {
    fi_admin_flash($e->getMessage(), 'error');
}
fi_redirect(fi_admin_url('forms.php'));
