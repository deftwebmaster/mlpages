<?php
declare(strict_types=1);
require_once __DIR__ . '/../../includes/bootstrap.php';
fi_require_admin();
fi_require_csrf();
try {
    fi_backup_create('manual');
    fi_admin_flash('Backup created.', 'success');
} catch (Throwable $e) {
    fi_admin_flash($e->getMessage(), 'error');
}
fi_redirect(fi_admin_url('backups.php'));
