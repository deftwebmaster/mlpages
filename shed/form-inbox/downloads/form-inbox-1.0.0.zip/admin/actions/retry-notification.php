<?php
declare(strict_types=1);
require_once __DIR__ . '/../../includes/bootstrap.php';
fi_require_admin();
fi_require_csrf();
$id = (string) ($_POST['id'] ?? '');
try {
    fi_retry_notification($id);
    fi_admin_flash('Notification retry completed.', 'success');
} catch (Throwable $e) {
    fi_admin_flash($e->getMessage(), 'error');
}
fi_redirect(fi_admin_url('submission.php?id=' . rawurlencode($id)));
