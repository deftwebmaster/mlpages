<?php
declare(strict_types=1);
require_once __DIR__ . '/../../includes/bootstrap.php';
fi_require_admin();
fi_require_csrf();
$id = (string) ($_POST['id'] ?? '');
try {
    $existing = fi_form_find_by_id($id);
    if (!$existing) {
        throw new RuntimeException('Form not found.');
    }
    $form = fi_form_update($id, fi_form_from_post($existing));
    fi_admin_flash('Form updated.', 'success');
    fi_redirect(fi_admin_url('form-edit.php?id=' . rawurlencode($form['id'])));
} catch (Throwable $e) {
    fi_admin_flash($e->getMessage(), 'error');
    fi_redirect(fi_admin_url('forms.php'));
}
