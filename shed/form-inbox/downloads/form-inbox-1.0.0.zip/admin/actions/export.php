<?php
declare(strict_types=1);
require_once __DIR__ . '/../../includes/bootstrap.php';
fi_require_admin();
fi_require_csrf();
$forms = [];
foreach (fi_forms_all() as $form) {
    $forms[(string) $form['id']] = $form;
}
if (!empty($_GET['id'])) {
    $submission = fi_submission_find((string) $_GET['id']);
    if (!$submission) {
        http_response_code(404);
        exit('Submission not found.');
    }
    fi_export_download([$submission], $forms, 'form-inbox-submission.csv');
}
$list = fi_submission_list([
    'form_id' => $_GET['form_id'] ?? '',
    'status' => $_GET['status'] ?? '',
    'q' => $_GET['q'] ?? '',
], 1, 10000);
$submissions = array_values(array_filter(array_map(static fn(array $row): ?array => $row['submission'], $list['items'])));
fi_export_download($submissions, $forms, 'form-inbox-export.csv');
