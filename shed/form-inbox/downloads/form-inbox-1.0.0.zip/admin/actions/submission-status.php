<?php
declare(strict_types=1);
require_once __DIR__ . '/../../includes/bootstrap.php';
fi_require_admin();
fi_require_csrf();
$id = (string) ($_POST['id'] ?? '');
$status = (string) ($_POST['status'] ?? '');
fi_submission_status($id, $status);
fi_admin_flash('Submission updated.', 'success');
fi_redirect(fi_admin_url('submission.php?id=' . rawurlencode($id)));
