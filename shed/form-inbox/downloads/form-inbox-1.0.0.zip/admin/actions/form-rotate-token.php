<?php
declare(strict_types=1);
require_once __DIR__ . '/../../includes/bootstrap.php';
fi_require_admin();
fi_require_csrf();
$id = (string) ($_POST['id'] ?? '');
fi_form_rotate_token($id);
fi_admin_flash('Public token rotated. Update the hidden field on your website.', 'success');
fi_redirect(fi_admin_url('form-edit.php?id=' . rawurlencode($id)));
