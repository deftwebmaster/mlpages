<?php
declare(strict_types=1);
require_once __DIR__ . '/../../includes/bootstrap.php';
fi_require_admin();
fi_require_csrf();
$count = fi_submission_rebuild_index();
fi_admin_flash('Rebuilt submission index with ' . $count . ' record(s).', 'success');
fi_redirect(fi_admin_url('diagnostics.php'));
