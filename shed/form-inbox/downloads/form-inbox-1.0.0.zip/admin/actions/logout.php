<?php
declare(strict_types=1);
require_once __DIR__ . '/../../includes/bootstrap.php';
fi_require_admin();
fi_require_csrf();
fi_admin_logout();
fi_redirect(fi_admin_url('login.php'));
