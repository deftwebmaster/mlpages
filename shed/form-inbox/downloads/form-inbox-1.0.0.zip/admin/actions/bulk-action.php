<?php
declare(strict_types=1);
require_once __DIR__ . '/../../includes/bootstrap.php';
fi_require_admin();
fi_require_csrf();
$status = (string) ($_POST['action'] ?? '');
$ids = array_map('strval', (array) ($_POST['ids'] ?? []));
$count = 0;
if (in_array($status, ['new','read','replied','archived','spam','deleted'], true)) {
    foreach ($ids as $id) {
        fi_submission_status($id, $status);
        $count++;
    }
}
fi_admin_flash($count . ' submission(s) updated.', 'success');
fi_redirect(fi_admin_url('inbox.php'));
