<?php
declare(strict_types=1);
$_GET['status'] = 'deleted';
require __DIR__ . '/inbox.php';
