<?php

declare(strict_types=1);

require_once __DIR__ . '/../includes/bootstrap.php';
fi_send_admin_headers();
fi_require_admin();
$pageTitle = 'Inbox';
$filters = [
    'q' => $_GET['q'] ?? '',
    'form_id' => $_GET['form_id'] ?? '',
    'status' => $_GET['status'] ?? '',
    'failed_notifications' => !empty($_GET['failed_notifications']),
    'attachments' => !empty($_GET['attachments']),
];
$page = max(1, (int) ($_GET['page'] ?? 1));
$list = fi_submission_list($filters, $page, 25);
$forms = fi_forms_all();
ob_start();
?>
<form class="toolbar" method="get">
    <label>Search <input name="q" value="<?= fi_h($filters['q']) ?>" maxlength="120"></label>
    <label>Form <select name="form_id"><option value="">All forms</option><?php foreach ($forms as $form): ?><option value="<?= fi_h($form['id']) ?>" <?= $filters['form_id'] === $form['id'] ? 'selected' : '' ?>><?= fi_h($form['name']) ?></option><?php endforeach; ?></select></label>
    <label>Status <select name="status"><option value="">Any status</option><?php foreach (['new','read','replied','archived','spam','deleted'] as $status): ?><option value="<?= $status ?>" <?= $filters['status'] === $status ? 'selected' : '' ?>><?= ucfirst($status) ?></option><?php endforeach; ?></select></label>
    <button type="submit">Filter</button>
</form>
<form method="post" action="actions/bulk-action.php">
    <?= fi_csrf_field() ?>
    <div class="toolbar">
        <select name="action" aria-label="Bulk action">
            <option value="read">Mark read</option>
            <option value="new">Mark unread</option>
            <option value="archived">Archive</option>
            <option value="spam">Mark spam</option>
            <option value="deleted">Move to trash</option>
        </select>
        <button class="ghost" type="submit">Apply</button>
        <a class="button ghost" href="exports.php">Export</a>
    </div>
    <?php if ($list['items'] === []): ?>
        <div class="panel"><p class="muted">No matching submissions.</p></div>
    <?php else: ?>
        <table>
            <caption><?= (int) $list['total'] ?> submission(s)</caption>
            <thead><tr><th><span class="muted">Select</span></th><th>Status</th><th>Form</th><th>Sender</th><th>Preview</th><th>Attachments</th><th>Notification</th><th>Received</th></tr></thead>
            <tbody>
            <?php foreach ($list['items'] as $row): $submission = $row['submission']; $form = $list['forms'][(string) $submission['form_id']] ?? []; ?>
                <tr>
                    <td><input type="checkbox" name="ids[]" value="<?= fi_h($submission['id']) ?>" aria-label="Select <?= fi_h($submission['id']) ?>"></td>
                    <td><span class="badge <?= fi_h($submission['status']) ?>"><?= fi_h($submission['status']) ?></span></td>
                    <td><?= fi_h($form['name'] ?? $submission['form_id']) ?></td>
                    <td><a href="submission.php?id=<?= fi_h(rawurlencode($submission['id'])) ?>"><?= fi_h(fi_submission_sender($submission)) ?></a><br><small><?= fi_h(fi_submission_email($submission) ?? '') ?></small></td>
                    <td><?= fi_h(fi_submission_preview($submission)) ?></td>
                    <td><?= count((array) ($submission['attachments'] ?? [])) ?></td>
                    <td><span class="badge <?= fi_h($submission['notification_status'] ?? '') ?>"><?= fi_h($submission['notification_status'] ?? 'n/a') ?></span></td>
                    <td><?= fi_h(fi_local_time($submission['received_at'])) ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</form>
<?php
$content = ob_get_clean();
require fi_root_path('templates/admin-layout.php');
