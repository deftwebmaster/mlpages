<?php

declare(strict_types=1);

require_once __DIR__ . '/../includes/bootstrap.php';
fi_send_admin_headers();
fi_require_admin();
$submission = fi_submission_find((string) ($_GET['id'] ?? ''));
if (!$submission) {
    http_response_code(404);
    exit('Submission not found.');
}
if (($submission['status'] ?? '') === 'new') {
    fi_submission_status((string) $submission['id'], 'read');
    $submission = fi_submission_find((string) $submission['id']) ?? $submission;
}
$form = fi_form_find_by_id((string) $submission['form_id']) ?? [];
$pageTitle = 'Submission';
$email = fi_submission_email($submission);
ob_start();
?>
<section class="panel">
    <div class="toolbar">
        <?php foreach (['new' => 'Unread', 'read' => 'Read', 'replied' => 'Replied', 'archived' => 'Archive', 'spam' => 'Spam', 'deleted' => 'Trash'] as $status => $label): ?>
            <form method="post" action="actions/submission-status.php">
                <?= fi_csrf_field() ?><input type="hidden" name="id" value="<?= fi_h($submission['id']) ?>"><input type="hidden" name="status" value="<?= fi_h($status) ?>">
                <button class="ghost" type="submit"><?= fi_h($label) ?></button>
            </form>
        <?php endforeach; ?>
        <form method="post" action="actions/retry-notification.php"><?= fi_csrf_field() ?><input type="hidden" name="id" value="<?= fi_h($submission['id']) ?>"><button class="ghost" type="submit">Retry email</button></form>
        <a class="button ghost" href="actions/export.php?id=<?= fi_h(rawurlencode($submission['id'])) ?>&_csrf=<?= fi_h(fi_csrf_token()) ?>">Export CSV</a>
        <?php if ($email): ?><a class="button ghost" href="mailto:<?= fi_h(rawurlencode($email)) ?>?subject=<?= fi_h(rawurlencode('Re: your message')) ?>">Reply</a><?php endif; ?>
    </div>
    <dl class="form-grid">
        <div><dt class="muted">Submission ID</dt><dd><?= fi_h($submission['id']) ?></dd></div>
        <div><dt class="muted">Form</dt><dd><?= fi_h($form['name'] ?? $submission['form_id']) ?></dd></div>
        <div><dt class="muted">Status</dt><dd><span class="badge <?= fi_h($submission['status']) ?>"><?= fi_h($submission['status']) ?></span></dd></div>
        <div><dt class="muted">Received</dt><dd><?= fi_h(fi_local_time($submission['received_at'])) ?></dd></div>
        <div><dt class="muted">Origin</dt><dd><?= fi_h($submission['origin'] ?? 'unknown') ?></dd></div>
        <div><dt class="muted">Referrer</dt><dd><?= fi_h($submission['referrer_url'] ?? 'not stored') ?></dd></div>
        <div><dt class="muted">Device</dt><dd><?= fi_h($submission['user_agent_category'] ?? 'unknown') ?></dd></div>
        <div><dt class="muted">Notification</dt><dd><?= fi_h($submission['notification_status'] ?? 'n/a') ?> <?= fi_h($submission['notification_message'] ?? '') ?></dd></div>
        <div class="span-2"><dt class="muted">Spam</dt><dd>Score <?= (int) ($submission['spam_score'] ?? 0) ?>: <?= fi_h(implode(', ', (array) ($submission['spam_reasons'] ?? []))) ?></dd></div>
    </dl>
</section>
<section class="panel" style="margin-top:16px">
    <h2>Fields</h2>
    <table><thead><tr><th>Field</th><th>Value</th></tr></thead><tbody>
    <?php foreach ((array) $submission['fields'] as $key => $value): ?>
        <tr><td><?= fi_h($key) ?></td><td><pre class="field-value"><?= fi_h(is_array($value) ? implode("\n", array_map('strval', $value)) : $value) ?></pre></td></tr>
    <?php endforeach; ?>
    </tbody></table>
</section>
<section class="panel" style="margin-top:16px">
    <h2>Attachments</h2>
    <?php if (empty($submission['attachments'])): ?><p class="muted">No attachments.</p><?php else: ?>
        <ul><?php foreach ($submission['attachments'] as $att): ?><li><a href="actions/download-attachment.php?submission=<?= fi_h(rawurlencode($submission['id'])) ?>&attachment=<?= fi_h(rawurlencode($att['id'])) ?>"><?= fi_h($att['original_filename']) ?></a> <span class="muted"><?= number_format((int) $att['file_size'] / 1024, 1) ?> KB</span></li><?php endforeach; ?></ul>
    <?php endif; ?>
</section>
<?php
$content = ob_get_clean();
require fi_root_path('templates/admin-layout.php');
