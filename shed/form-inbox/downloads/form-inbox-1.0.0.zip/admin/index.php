<?php

declare(strict_types=1);

require_once __DIR__ . '/../includes/bootstrap.php';
fi_send_admin_headers();
fi_require_admin();
$pageTitle = 'Dashboard';
$counts = fi_submission_counts();
$forms = fi_forms_all();
$recent = fi_submission_list([], 1, 6);
$attention = [];
if (is_file(fi_root_path('tools/generate-password.php'))) {
    $attention[] = ['warning', 'Password helper is present. Delete tools/generate-password.php after setup.'];
}
if (!is_writable(fi_storage_root())) {
    $attention[] = ['failure', 'Private storage is not writable.'];
}
if (!is_writable(fi_attachment_root())) {
    $attention[] = ['failure', 'Attachment storage is not writable.'];
}
if ($counts['failed_notifications'] > 0) {
    $attention[] = ['warning', $counts['failed_notifications'] . ' submission notification(s) failed.'];
}
ob_start();
?>
<section class="grid stats">
    <div class="card stat"><span class="muted">Active forms</span><strong><?= count(array_filter($forms, static fn(array $f): bool => ($f['status'] ?? '') === 'active')) ?></strong></div>
    <div class="card stat"><span class="muted">New submissions</span><strong><?= (int) $counts['new'] ?></strong></div>
    <div class="card stat"><span class="muted">Today</span><strong><?= (int) $counts['today'] ?></strong></div>
    <div class="card stat"><span class="muted">Last 7 days</span><strong><?= (int) $counts['seven_days'] ?></strong></div>
</section>
<section class="grid" style="grid-template-columns:2fr 1fr;margin-top:16px">
    <div class="panel">
        <h2>Recent Submissions</h2>
        <?php fi_render_submission_table($recent['items'], $recent['forms']); ?>
    </div>
    <div class="panel">
        <h2>Attention Required</h2>
        <?php if ($attention === []): ?>
            <p class="muted">No urgent issues detected.</p>
        <?php else: ?>
            <?php foreach ($attention as [$type, $message]): ?><p><span class="badge <?= fi_h($type) ?>"><?= fi_h($type) ?></span> <?= fi_h($message) ?></p><?php endforeach; ?>
        <?php endif; ?>
        <p class="muted">Most active form: <?= fi_h($counts['most_active_form']) ?></p>
        <p class="muted">Attachment storage: <?= number_format((int) $counts['attachment_bytes'] / 1024, 1) ?> KB</p>
    </div>
</section>
<?php
$content = ob_get_clean();
require fi_root_path('templates/admin-layout.php');

function fi_render_submission_table(array $items, array $forms): void
{
    if ($items === []) {
        echo '<p class="muted">No submissions yet.</p>';
        return;
    }
    echo '<table><thead><tr><th>Status</th><th>Form</th><th>Sender</th><th>Preview</th><th>Received</th></tr></thead><tbody>';
    foreach ($items as $row) {
        $submission = $row['submission'];
        if (!$submission) {
            continue;
        }
        $form = $forms[(string) $submission['form_id']] ?? [];
        echo '<tr><td><span class="badge ' . fi_h((string) $submission['status']) . '">' . fi_h($submission['status']) . '</span></td>';
        echo '<td>' . fi_h($form['name'] ?? $submission['form_id']) . '</td>';
        echo '<td><a href="submission.php?id=' . fi_h(rawurlencode((string) $submission['id'])) . '">' . fi_h(fi_submission_sender($submission)) . '</a></td>';
        echo '<td>' . fi_h(fi_submission_preview($submission)) . '</td>';
        echo '<td>' . fi_h(fi_local_time((string) $submission['received_at'])) . '</td></tr>';
    }
    echo '</tbody></table>';
}
