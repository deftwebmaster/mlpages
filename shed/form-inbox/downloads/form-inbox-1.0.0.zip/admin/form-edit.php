<?php

declare(strict_types=1);

require_once __DIR__ . '/../includes/bootstrap.php';
fi_send_admin_headers();
fi_require_admin();
$form = fi_form_find_by_id((string) ($_GET['id'] ?? ''));
if (!$form) {
    http_response_code(404);
    exit('Form not found.');
}
$pageTitle = 'Edit Form';
$action = 'actions/form-update.php';
ob_start();
require fi_root_path('templates/components/form-editor.php');
require fi_root_path('templates/components/integration-guide.php');
$content = ob_get_clean();
require fi_root_path('templates/admin-layout.php');
