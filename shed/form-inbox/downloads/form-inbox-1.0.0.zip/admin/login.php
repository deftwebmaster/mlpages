<?php

declare(strict_types=1);

require_once __DIR__ . '/../includes/bootstrap.php';
fi_send_admin_headers();
fi_boot_session();
$error = null;
if (fi_request_method() === 'POST') {
    fi_require_csrf();
    if (fi_admin_login((string) ($_POST['password'] ?? ''))) {
        fi_redirect(fi_admin_url('index.php'));
    }
    $error = 'The login could not be completed.';
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Log in - <?= fi_h(fi_config('app_name')) ?></title>
    <link rel="stylesheet" href="../assets/css/admin.css">
</head>
<body>
<main class="public-card" style="margin:10vh auto;max-width:420px">
    <p class="eyebrow">Administrator</p>
    <h1><?= fi_h(fi_config('app_name')) ?></h1>
    <?php if ($error): ?><div class="notice error"><?= fi_h($error) ?></div><?php endif; ?>
    <?php if (str_starts_with((string) fi_config('admin_password_hash'), 'REPLACE_')): ?>
        <div class="notice warning">Set an administrator password hash in <code>config.php</code> before logging in.</div>
    <?php endif; ?>
    <form method="post">
        <?= fi_csrf_field() ?>
        <label>Password <input type="password" name="password" required autocomplete="current-password"></label>
        <p><button class="full" type="submit">Log in</button></p>
    </form>
</main>
</body>
</html>
