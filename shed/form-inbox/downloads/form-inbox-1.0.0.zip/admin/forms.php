<?php

declare(strict_types=1);

require_once __DIR__ . '/../includes/bootstrap.php';
fi_send_admin_headers();
fi_require_admin();
$pageTitle = 'Forms';
$pageAction = '<a class="button" href="form-create.php">Create form</a>';
$forms = fi_forms_all();
ob_start();
?>
<?php if ($forms === []): ?>
    <div class="panel"><p class="muted">No forms yet. Create one and point your static HTML form at its endpoint.</p></div>
<?php else: ?>
<table>
    <thead><tr><th>Name</th><th>Slug</th><th>Status</th><th>Origins</th><th>Notifications</th><th>Updated</th><th>Actions</th></tr></thead>
    <tbody>
    <?php foreach ($forms as $form): ?>
        <tr>
            <td><?= fi_h($form['name']) ?></td>
            <td><code><?= fi_h($form['slug']) ?></code></td>
            <td><span class="badge <?= fi_h($form['status']) ?>"><?= fi_h($form['status']) ?></span></td>
            <td><?= fi_h(implode(', ', (array) $form['allowed_origins'])) ?></td>
            <td><?= !empty($form['notification_enabled']) ? 'Enabled' : 'Disabled' ?></td>
            <td><?= fi_h(fi_local_time($form['updated_at'] ?? $form['created_at'])) ?></td>
            <td><a href="form-edit.php?id=<?= fi_h(rawurlencode($form['id'])) ?>">Edit</a></td>
        </tr>
    <?php endforeach; ?>
    </tbody>
</table>
<?php endif; ?>
<?php
$content = ob_get_clean();
require fi_root_path('templates/admin-layout.php');
