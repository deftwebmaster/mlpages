<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/bootstrap.php';
fi_send_admin_headers();
fi_require_admin();
$pageTitle = 'Exports';
$forms = fi_forms_all();
ob_start();
?>
<form class="panel" method="get" action="actions/export.php">
    <input type="hidden" name="_csrf" value="<?= fi_h(fi_csrf_token()) ?>">
    <div class="form-grid">
        <label>Form <select name="form_id"><option value="">All forms</option><?php foreach ($forms as $form): ?><option value="<?= fi_h($form['id']) ?>"><?= fi_h($form['name']) ?></option><?php endforeach; ?></select></label>
        <label>Status <select name="status"><option value="">Any status</option><?php foreach (['new','read','replied','archived','spam','deleted'] as $status): ?><option value="<?= $status ?>"><?= ucfirst($status) ?></option><?php endforeach; ?></select></label>
        <label class="span-2">Search <input name="q" maxlength="120"></label>
    </div>
    <p><button type="submit">Download CSV</button></p>
    <p class="muted">CSV values beginning with formula characters are prefixed to prevent spreadsheet formula injection.</p>
</form>
<?php
$content = ob_get_clean();
require fi_root_path('templates/admin-layout.php');
