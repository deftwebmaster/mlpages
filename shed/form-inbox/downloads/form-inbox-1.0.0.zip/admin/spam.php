<?php
declare(strict_types=1);
$_GET['status'] = 'spam';
require __DIR__ . '/inbox.php';
