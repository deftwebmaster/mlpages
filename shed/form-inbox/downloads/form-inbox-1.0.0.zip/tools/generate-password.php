<?php

declare(strict_types=1);

$hash = null;
if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
    $password = (string) ($_POST['password'] ?? '');
    if ($password !== '') {
        $hash = password_hash($password, PASSWORD_DEFAULT);
    }
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Generate Form Inbox Password Hash</title>
    <link rel="stylesheet" href="../assets/css/public.css">
</head>
<body>
<main class="public-card">
    <p class="eyebrow">Setup helper</p>
    <h1>Password Hash</h1>
    <p>Enter the administrator password you want to use. This helper displays a hash created with PHP <code>password_hash()</code> and does not save the password.</p>
    <form method="post">
        <label>Password <input type="password" name="password" required></label>
        <p><button type="submit">Generate hash</button></p>
    </form>
    <?php if ($hash): ?>
        <p>Paste this value into <code>config.php</code> as <code>admin_password_hash</code>:</p>
        <pre class="codebox"><?= htmlspecialchars($hash, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') ?></pre>
        <p><strong>Delete this helper after setup.</strong> The dashboard warns while it remains present.</p>
    <?php endif; ?>
</main>
</body>
</html>
