<?php

declare(strict_types=1);

require_once __DIR__ . '/../includes/bootstrap.php';

$failures = 0;
function ok(bool $condition, string $label): void
{
    global $failures;
    echo ($condition ? 'PASS ' : 'FAIL ') . $label . PHP_EOL;
    if (!$condition) {
        $failures++;
    }
}

$testFile = 'data/tests-' . bin2hex(random_bytes(3)) . '.json';
fi_json_write_locked($testFile, ['hello' => 'world']);
ok(fi_json_read($testFile, [])['hello'] === 'world', 'locked JSON write/read');
fi_json_update_locked($testFile, static function (array $data): array {
    $data['count'] = 2;
    return $data;
}, []);
ok(fi_json_read($testFile, [])['count'] === 2, 'locked JSON update');

$form = fi_form_defaults(['name' => 'Test Form', 'slug' => 'test-form', 'public_token' => 'fi_pub_test', 'field_schema' => ['email' => ['type' => 'email', 'required' => true]], 'field_mode' => 'schema']);
[$fields, $errors] = fi_normalize_submission_fields(['email' => 'person@example.com', '_form_token' => 'fi_pub_test'], $form);
ok($errors === [] && $fields['email'] === 'person@example.com', 'schema email validation accepts valid email');
[, $errors] = fi_normalize_submission_fields(['email' => 'bad'], $form);
ok(isset($errors['email']), 'schema email validation rejects invalid email');
ok(fi_csv_safe('=SUM(A1:A2)')[0] === "'", 'CSV formula values are prefixed');
[$score, $reasons] = fi_spam_score(['message' => 'HTTP://A HTTP://B HTTP://C HTTP://D'], $form);
ok($score >= 3 && in_array('many_links', $reasons, true), 'spam score counts excessive links');

exit($failures > 0 ? 1 : 0);
