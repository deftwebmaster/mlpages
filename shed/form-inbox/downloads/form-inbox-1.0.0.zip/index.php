<?php

declare(strict_types=1);

require_once __DIR__ . '/includes/bootstrap.php';
fi_redirect(fi_admin_url('index.php'));
