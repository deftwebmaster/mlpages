<?php

declare(strict_types=1);

function fi_admin_logged_in(): bool
{
    fi_boot_session();
    $loggedIn = !empty($_SESSION['admin_logged_in']);
    $lastSeen = (int) ($_SESSION['last_seen'] ?? 0);
    $timeout = max(1, (int) fi_config('session_timeout_minutes')) * 60;
    if ($loggedIn && $lastSeen > 0 && time() - $lastSeen <= $timeout) {
        $_SESSION['last_seen'] = time();
        return true;
    }
    fi_admin_logout(false);
    return false;
}

function fi_require_admin(): void
{
    if (!fi_admin_logged_in()) {
        fi_redirect(fi_admin_url('login.php'));
    }
}

function fi_admin_login(string $password): bool
{
    $hash = (string) fi_config('admin_password_hash');
    if ($hash === '' || str_starts_with($hash, 'REPLACE_')) {
        return false;
    }
    if (!fi_rate_limit_check('admin_login:' . fi_client_hash(), 5, 600)['allowed']) {
        return false;
    }
    if (!password_verify($password, $hash)) {
        fi_rate_limit_hit('admin_login:' . fi_client_hash(), 5, 600);
        fi_log('warning', 'Failed administrator login.');
        return false;
    }
    fi_boot_session();
    session_regenerate_id(true);
    $_SESSION['admin_logged_in'] = true;
    $_SESSION['last_seen'] = time();
    unset($_SESSION['csrf_token']);
    return true;
}

function fi_admin_logout(bool $destroy = true): void
{
    if (session_status() !== PHP_SESSION_ACTIVE) {
        return;
    }
    $_SESSION = [];
    if ($destroy) {
        session_destroy();
    }
}
