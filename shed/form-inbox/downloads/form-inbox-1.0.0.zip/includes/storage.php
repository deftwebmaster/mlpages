<?php

declare(strict_types=1);

function fi_storage_root(string $path = ''): string
{
    $root = rtrim((string) fi_config('storage_path'), '/');
    return $path === '' ? $root : $root . '/' . ltrim($path, '/');
}

function fi_attachment_root(string $path = ''): string
{
    $root = rtrim((string) fi_config('attachment_path'), '/');
    return $path === '' ? $root : $root . '/' . ltrim($path, '/');
}

function fi_storage_bootstrap(): void
{
    $dirs = [
        'data/submissions',
        'data/spam',
        'data/trash',
        'data/indexes',
        'attachments',
        'backups',
        'logs',
        'locks',
        'temporary',
    ];

    foreach ($dirs as $dir) {
        $path = $dir === 'attachments' ? fi_attachment_root() : fi_storage_root($dir);
        if (!is_dir($path)) {
            mkdir($path, 0775, true);
        }
    }

    fi_json_ensure('data/forms.json', []);
    fi_json_ensure('data/rate-limits.json', []);
    fi_json_ensure('data/rejected-events.json', []);
    fi_json_ensure('data/indexes/submission-index.json', []);
}

function fi_json_ensure(string $relativePath, mixed $default): void
{
    $path = fi_storage_root($relativePath);
    if (!is_file($path)) {
        fi_json_write_locked($relativePath, $default);
    }
}

function fi_lock_path(string $relativePath): string
{
    return fi_storage_root('locks/' . preg_replace('/[^a-zA-Z0-9_.-]+/', '_', $relativePath) . '.lock');
}

function fi_json_read(string $relativePath, mixed $default = []): mixed
{
    $path = fi_storage_root($relativePath);
    if (!is_file($path)) {
        return $default;
    }
    $raw = file_get_contents($path);
    if ($raw === false || trim($raw) === '') {
        return $default;
    }
    $decoded = json_decode($raw, true);
    if (json_last_error() !== JSON_ERROR_NONE) {
        fi_preserve_corrupt_json($path, json_last_error_msg());
        throw new RuntimeException('Stored JSON could not be decoded.');
    }
    return $decoded;
}

function fi_json_write_locked(string $relativePath, mixed $value): void
{
    $lockPath = fi_lock_path($relativePath);
    $lock = fopen($lockPath, 'c');
    if ($lock === false) {
        throw new RuntimeException('Could not open storage lock.');
    }
    try {
        if (!flock($lock, LOCK_EX)) {
            throw new RuntimeException('Could not lock storage file.');
        }
        fi_json_write_unlocked($relativePath, $value);
    } finally {
        flock($lock, LOCK_UN);
        fclose($lock);
    }
}

function fi_json_update_locked(string $relativePath, callable $callback, mixed $default = []): mixed
{
    $lockPath = fi_lock_path($relativePath);
    $lock = fopen($lockPath, 'c');
    if ($lock === false) {
        throw new RuntimeException('Could not open storage lock.');
    }
    try {
        if (!flock($lock, LOCK_EX)) {
            throw new RuntimeException('Could not lock storage file.');
        }
        $current = fi_json_read($relativePath, $default);
        $updated = $callback($current);
        fi_json_write_unlocked($relativePath, $updated);
        return $updated;
    } finally {
        flock($lock, LOCK_UN);
        fclose($lock);
    }
}

function fi_json_write_unlocked(string $relativePath, mixed $value): void
{
    $path = fi_storage_root($relativePath);
    $dir = dirname($path);
    if (!is_dir($dir)) {
        mkdir($dir, 0775, true);
    }

    $json = json_encode($value, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    if ($json === false) {
        throw new RuntimeException('Could not encode JSON.');
    }
    json_decode($json, true);
    if (json_last_error() !== JSON_ERROR_NONE) {
        throw new RuntimeException('Encoded JSON did not validate.');
    }

    $tmp = $path . '.tmp.' . bin2hex(random_bytes(4));
    $handle = fopen($tmp, 'wb');
    if ($handle === false) {
        throw new RuntimeException('Could not create temporary storage file.');
    }
    try {
        fwrite($handle, $json . "\n");
        fflush($handle);
    } finally {
        fclose($handle);
    }
    if (!rename($tmp, $path)) {
        @unlink($tmp);
        throw new RuntimeException('Could not replace storage file atomically.');
    }
}

function fi_preserve_corrupt_json(string $path, string $reason): void
{
    $copy = $path . '.corrupt-' . gmdate('YmdHis');
    @copy($path, $copy);
    fi_log('error', 'Corrupt JSON preserved: ' . basename($path) . ' (' . $reason . ')');
}

function fi_log(string $level, string $message): void
{
    $dir = fi_storage_root('logs');
    if (!is_dir($dir)) {
        @mkdir($dir, 0775, true);
    }
    $path = $dir . '/app.log';
    if (is_file($path) && filesize($path) > 1048576) {
        @rename($path, $dir . '/app-' . gmdate('YmdHis') . '.log');
    }
    $line = '[' . fi_now() . '] ' . strtoupper($level) . ' ' . preg_replace('/[\r\n]+/', ' ', $message) . PHP_EOL;
    @file_put_contents($path, $line, FILE_APPEND | LOCK_EX);
}
