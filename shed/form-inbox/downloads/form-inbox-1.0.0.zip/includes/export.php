<?php

declare(strict_types=1);

function fi_csv_export(array $submissions, array $forms): string
{
    $columns = ['Submission ID', 'Form', 'Status', 'Received', 'Sender Email', 'Attachments', 'Notification'];
    $dynamic = [];
    foreach ($submissions as $submission) {
        foreach (array_keys((array) ($submission['fields'] ?? [])) as $key) {
            $dynamic[$key] = true;
        }
    }
    $columns = array_merge($columns, array_keys($dynamic));
    $handle = fopen('php://temp', 'r+');
    fputcsv($handle, $columns);
    foreach ($submissions as $submission) {
        $form = $forms[(string) ($submission['form_id'] ?? '')] ?? [];
        $row = [
            $submission['id'] ?? '',
            $form['name'] ?? $submission['form_id'] ?? '',
            $submission['status'] ?? '',
            $submission['received_at'] ?? '',
            fi_submission_email($submission) ?? '',
            implode(', ', array_map(static fn(array $att): string => (string) ($att['original_filename'] ?? ''), (array) ($submission['attachments'] ?? []))),
            $submission['notification_status'] ?? '',
        ];
        foreach (array_keys($dynamic) as $key) {
            $value = $submission['fields'][$key] ?? '';
            $row[] = is_array($value) ? implode(', ', array_map('strval', $value)) : (string) $value;
        }
        fputcsv($handle, array_map('fi_csv_safe', $row));
    }
    rewind($handle);
    return (string) stream_get_contents($handle);
}

function fi_csv_safe(string $value): string
{
    $value = str_replace(["\r\n", "\r"], "\n", $value);
    return preg_match('/^[=+\-@]/', $value) ? "'" . $value : $value;
}

function fi_export_download(array $submissions, array $forms, string $filename): never
{
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . addslashes($filename) . '"');
    echo "\xEF\xBB\xBF" . fi_csv_export($submissions, $forms);
    exit;
}
