<?php

declare(strict_types=1);

function fi_spam_score(array $fields, array $form, array $signals = []): array
{
    $score = 0;
    $reasons = [];
    foreach ($signals as $reason => $points) {
        if ($points > 0) {
            $score += (int) $points;
            $reasons[] = (string) $reason;
        }
    }
    $combined = strtolower(json_encode($fields, JSON_UNESCAPED_UNICODE) ?: '');
    $linkCount = preg_match_all('/https?:\\/\\//i', $combined);
    if ($linkCount >= 4) {
        $score += 3;
        $reasons[] = 'many_links';
    }
    $letters = preg_replace('/[^a-z]/i', '', $combined) ?? '';
    if (strlen($letters) > 40) {
        $upper = preg_replace('/[^A-Z]/', '', $combined) ?? '';
        if (strlen($upper) / max(1, strlen($letters)) > 0.75) {
            $score += 2;
            $reasons[] = 'excessive_uppercase';
        }
    }
    if (count($fields) > max(20, (int) ($form['maximum_fields'] ?? 50) - 5)) {
        $score += 1;
        $reasons[] = 'suspicious_field_count';
    }
    return [$score, array_values(array_unique($reasons))];
}

function fi_duplicate_key(string $formId, array $fields, array $attachments): string
{
    $attachmentSummary = array_map(static fn(array $att): string => ($att['original_filename'] ?? '') . ':' . ($att['file_size'] ?? 0), $attachments);
    return hash('sha256', $formId . '|' . json_encode($fields) . '|' . implode('|', $attachmentSummary));
}

function fi_duplicate_seen(string $key, int $windowSeconds): bool
{
    if ($windowSeconds <= 0) {
        return false;
    }
    $now = time();
    $seen = false;
    fi_json_update_locked('data/duplicates.json', static function (array $items) use ($key, $windowSeconds, $now, &$seen): array {
        $items = array_filter($items, static fn(int $expires): bool => $expires > $now);
        if (isset($items[$key])) {
            $seen = true;
            return $items;
        }
        $items[$key] = $now + $windowSeconds;
        return $items;
    }, []);
    return $seen;
}
