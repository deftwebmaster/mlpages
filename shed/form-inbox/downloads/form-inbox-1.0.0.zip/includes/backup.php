<?php

declare(strict_types=1);

function fi_backup_create(string $reason = 'manual'): string
{
    $backupDir = fi_storage_root('backups');
    if (!is_dir($backupDir)) {
        mkdir($backupDir, 0775, true);
    }
    $name = 'form-inbox-' . gmdate('Ymd-His') . '-' . preg_replace('/[^a-z0-9-]+/i', '-', $reason) . '.zip';
    $path = $backupDir . '/' . $name;
    if (class_exists('ZipArchive')) {
        $zip = new ZipArchive();
        if ($zip->open($path, ZipArchive::CREATE) !== true) {
            throw new RuntimeException('Could not create backup archive.');
        }
        $root = fi_storage_root();
        foreach (new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root, FilesystemIterator::SKIP_DOTS)) as $file) {
            $filePath = (string) $file;
            if (str_contains($filePath, '/backups/')) {
                continue;
            }
            $zip->addFile($filePath, substr($filePath, strlen($root) + 1));
        }
        $zip->close();
    } else {
        $snapshot = [
            'created_at' => fi_now(),
            'reason' => $reason,
            'forms' => fi_forms_all(),
            'index' => fi_json_read('data/indexes/submission-index.json', []),
        ];
        $path = $backupDir . '/' . preg_replace('/\\.zip$/', '.json', $name);
        file_put_contents($path, json_encode($snapshot, JSON_PRETTY_PRINT));
    }
    fi_backup_prune();
    return $path;
}

function fi_backup_prune(): void
{
    $files = glob(fi_storage_root('backups/*')) ?: [];
    rsort($files);
    $keep = max(1, (int) fi_config('backup_retention'));
    foreach (array_slice($files, $keep) as $file) {
        @unlink($file);
    }
}

function fi_backup_list(): array
{
    $files = glob(fi_storage_root('backups/*')) ?: [];
    rsort($files);
    return array_map(static fn(string $path): array => [
        'name' => basename($path),
        'path' => $path,
        'size' => is_file($path) ? filesize($path) : 0,
        'created_at' => is_file($path) ? date('Y-m-d H:i:s', filemtime($path)) : '',
    ], $files);
}
