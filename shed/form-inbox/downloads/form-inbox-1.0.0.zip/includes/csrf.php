<?php

declare(strict_types=1);

function fi_csrf_token(): string
{
    fi_boot_session();
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return (string) $_SESSION['csrf_token'];
}

function fi_csrf_field(): string
{
    return '<input type="hidden" name="_csrf" value="' . fi_h(fi_csrf_token()) . '">';
}

function fi_require_csrf(): void
{
    fi_boot_session();
    $provided = (string) ($_POST['_csrf'] ?? $_GET['_csrf'] ?? '');
    $actual = (string) ($_SESSION['csrf_token'] ?? '');
    if ($actual === '' || $provided === '' || !hash_equals($actual, $provided)) {
        http_response_code(403);
        exit('Invalid security token.');
    }
}
