<?php

declare(strict_types=1);

function fi_handle_attachments(array $form, string $submissionId): array
{
    if (empty($form['attachments_enabled']) || empty($_FILES)) {
        return [[], []];
    }
    $files = fi_flatten_files($_FILES);
    $maxFiles = (int) ($form['maximum_attachments'] ?? 0);
    if ($maxFiles <= 0 || count($files) > $maxFiles) {
        return [[], ['attachments' => 'Too many files were uploaded.']];
    }
    $allowedExt = array_map('strtolower', (array) ($form['allowed_attachment_extensions'] ?? []));
    $allowedMime = (array) ($form['allowed_attachment_mime_types'] ?? []);
    $maxFile = (int) ($form['maximum_attachment_bytes'] ?? 0);
    $maxTotal = (int) ($form['maximum_total_attachment_bytes'] ?? 0);
    $total = 0;
    $attachments = [];
    $errors = [];
    $blocked = ['php','phtml','phar','cgi','pl','py','sh','htaccess','user.ini','exe','dll','js','html','htm','svg'];
    $finfo = function_exists('finfo_open') ? finfo_open(FILEINFO_MIME_TYPE) : null;

    foreach ($files as $file) {
        if (($file['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) {
            continue;
        }
        if (($file['error'] ?? UPLOAD_ERR_OK) !== UPLOAD_ERR_OK || !is_uploaded_file((string) $file['tmp_name'])) {
            $errors['attachments'] = 'An uploaded file could not be read.';
            continue;
        }
        $original = (string) $file['name'];
        if (preg_match('/[\\x00-\\x1F\\x7F\\/\\\\]/', $original)) {
            $errors['attachments'] = 'An uploaded filename is not allowed.';
            continue;
        }
        $ext = strtolower(pathinfo($original, PATHINFO_EXTENSION));
        $parts = array_map('strtolower', explode('.', $original));
        if ($ext === '' || in_array($ext, $blocked, true) || count(array_intersect($parts, $blocked)) > 0) {
            $errors['attachments'] = 'This file type is not allowed.';
            continue;
        }
        if ($allowedExt !== [] && !in_array($ext, $allowedExt, true)) {
            $errors['attachments'] = 'This file extension is not configured for upload.';
            continue;
        }
        $size = (int) $file['size'];
        $total += $size;
        if (($maxFile > 0 && $size > $maxFile) || ($maxTotal > 0 && $total > $maxTotal)) {
            $errors['attachments'] = 'An uploaded file is too large.';
            continue;
        }
        $mime = $finfo ? (string) finfo_file($finfo, (string) $file['tmp_name']) : 'application/octet-stream';
        if ($allowedMime !== [] && !in_array($mime, $allowedMime, true)) {
            $errors['attachments'] = 'This file MIME type is not configured for upload.';
            continue;
        }
        $id = fi_random_id('att');
        $stored = $id . '_' . bin2hex(random_bytes(6)) . '.' . $ext;
        $targetDir = fi_attachment_root((string) ($form['id'] ?? 'unknown') . '/' . $submissionId);
        if (!is_dir($targetDir)) {
            mkdir($targetDir, 0775, true);
        }
        $target = $targetDir . '/' . $stored;
        if (!move_uploaded_file((string) $file['tmp_name'], $target)) {
            $errors['attachments'] = 'An uploaded file could not be stored.';
            continue;
        }
        $attachments[] = [
            'id' => $id,
            'stored_filename' => $stored,
            'original_filename' => substr($original, 0, 180),
            'file_size' => $size,
            'mime_type' => $mime,
            'sha256' => hash_file('sha256', $target),
            'uploaded_at' => fi_now(),
        ];
    }
    if ($finfo) {
        finfo_close($finfo);
    }
    return [$attachments, $errors];
}

function fi_flatten_files(array $files): array
{
    $flat = [];
    foreach ($files as $file) {
        if (is_array($file['name'])) {
            foreach ($file['name'] as $index => $name) {
                $flat[] = [
                    'name' => $name,
                    'type' => $file['type'][$index] ?? '',
                    'tmp_name' => $file['tmp_name'][$index] ?? '',
                    'error' => $file['error'][$index] ?? UPLOAD_ERR_NO_FILE,
                    'size' => $file['size'][$index] ?? 0,
                ];
            }
        } else {
            $flat[] = $file;
        }
    }
    return $flat;
}

function fi_stream_attachment(string $submissionId, string $attachmentId): never
{
    fi_require_admin();
    $submission = fi_submission_find($submissionId);
    if (!$submission) {
        http_response_code(404);
        exit('Attachment not found.');
    }
    foreach ((array) ($submission['attachments'] ?? []) as $attachment) {
        if (($attachment['id'] ?? '') !== $attachmentId) {
            continue;
        }
        $formId = (string) $submission['form_id'];
        $path = fi_attachment_root($formId . '/' . $submissionId . '/' . (string) $attachment['stored_filename']);
        $root = realpath(fi_attachment_root());
        $real = realpath($path);
        if (!$root || !$real || !str_starts_with($real, $root) || !is_file($real)) {
            http_response_code(404);
            exit('Attachment not found.');
        }
        header('Content-Type: application/octet-stream');
        header('Content-Length: ' . filesize($real));
        header('Content-Disposition: attachment; filename="' . addslashes((string) $attachment['original_filename']) . '"');
        readfile($real);
        exit;
    }
    http_response_code(404);
    exit('Attachment not found.');
}
