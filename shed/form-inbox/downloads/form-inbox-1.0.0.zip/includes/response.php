<?php

declare(strict_types=1);

function fi_public_success(array $form, ?string $submissionId = null): never
{
    if (fi_request_wants_json() || ($form['success_mode'] ?? '') === 'json') {
        fi_json_response(['success' => true, 'submission_id' => $submissionId, 'message' => 'Your submission was received.']);
    }
    if (($form['success_mode'] ?? '') === 'redirect') {
        $url = fi_validate_redirect_url((string) ($form['success_redirect_url'] ?? ''), $form);
        if ($url) {
            fi_redirect($url, 303);
        }
    }
    fi_send_public_headers();
    $title = 'Your message was sent.';
    $message = 'Thank you. Your submission was received.';
    require fi_root_path('templates/public-success.php');
    exit;
}

function fi_public_error(string $message, int $status = 422, array $errors = [], ?array $form = null): never
{
    if (fi_request_wants_json()) {
        fi_json_response(['success' => false, 'message' => $message, 'errors' => $errors], $status);
    }
    if ($form && !empty($form['error_redirect_url'])) {
        $url = fi_validate_redirect_url((string) $form['error_redirect_url'], $form);
        if ($url) {
            fi_redirect($url, 303);
        }
    }
    http_response_code($status);
    fi_send_public_headers();
    $title = 'The form could not be sent.';
    require fi_root_path('templates/public-error.php');
    exit;
}

function fi_apply_cors(array $form): void
{
    $origin = fi_normalize_origin($_SERVER['HTTP_ORIGIN'] ?? null);
    $allowed = array_values(array_filter(array_map('fi_normalize_origin', (array) ($form['allowed_origins'] ?? []))));
    if ($origin && in_array($origin, $allowed, true)) {
        header('Access-Control-Allow-Origin: ' . $origin);
        header('Vary: Origin');
        header('Access-Control-Allow-Methods: POST, OPTIONS');
        header('Access-Control-Allow-Headers: Content-Type, Accept');
        header('Access-Control-Max-Age: 600');
    }
}
