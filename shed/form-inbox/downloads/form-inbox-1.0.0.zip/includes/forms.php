<?php

declare(strict_types=1);

function fi_forms_all(): array
{
    $forms = fi_json_read('data/forms.json', []);
    return is_array($forms) ? $forms : [];
}

function fi_forms_save(array $forms): void
{
    fi_json_write_locked('data/forms.json', array_values($forms));
}

function fi_form_find_by_slug(string $slug): ?array
{
    foreach (fi_forms_all() as $form) {
        if (($form['slug'] ?? '') === $slug) {
            return $form;
        }
    }
    return null;
}

function fi_form_find_by_id(string $id): ?array
{
    foreach (fi_forms_all() as $form) {
        if (($form['id'] ?? '') === $id) {
            return $form;
        }
    }
    return null;
}

function fi_form_defaults(array $data = []): array
{
    $now = fi_now();
    $name = trim((string) ($data['name'] ?? 'Untitled Form'));
    $slug = fi_slugify((string) ($data['slug'] ?? $name));
    return array_replace([
        'id' => fi_random_id('frm'),
        'slug' => $slug,
        'name' => $name,
        'description' => '',
        'public_token' => fi_public_token(),
        'status' => 'active',
        'allowed_origins' => [],
        'origin_validation_mode' => 'compatible',
        'notification_enabled' => false,
        'notification_recipients' => [],
        'notification_subject' => 'New submission: {form_name}',
        'reply_to_field' => 'email',
        'success_mode' => 'html',
        'success_redirect_url' => '',
        'error_redirect_url' => '',
        'json_response_enabled' => true,
        'store_submissions' => true,
        'field_mode' => 'flexible',
        'field_schema' => [],
        'maximum_fields' => (int) fi_config('maximum_fields'),
        'maximum_request_bytes' => (int) fi_config('maximum_request_bytes'),
        'attachments_enabled' => false,
        'maximum_attachments' => 0,
        'maximum_attachment_bytes' => 0,
        'maximum_total_attachment_bytes' => 0,
        'allowed_attachment_extensions' => [],
        'allowed_attachment_mime_types' => [],
        'honeypot_field' => '_website',
        'honeypot_behavior' => 'discard',
        'minimum_completion_seconds' => 3,
        'maximum_timestamp_age_seconds' => 86400,
        'rate_limit_requests' => (int) fi_config('rate_limit_requests'),
        'rate_limit_window_seconds' => (int) fi_config('rate_limit_window_seconds'),
        'duplicate_window_seconds' => (int) fi_config('duplicate_window_seconds'),
        'spam_threshold' => 5,
        'reject_threshold' => 10,
        'store_rejected_attempts' => true,
        'created_at' => $now,
        'updated_at' => $now,
    ], $data);
}

function fi_form_from_post(?array $existing = null): array
{
    $data = $existing ?? [];
    $data['name'] = trim((string) ($_POST['name'] ?? $data['name'] ?? ''));
    $data['slug'] = fi_slugify((string) ($_POST['slug'] ?? $data['slug'] ?? $data['name'] ?? 'form'));
    $data['description'] = trim((string) ($_POST['description'] ?? ''));
    $data['status'] = in_array(($_POST['status'] ?? 'active'), ['active', 'disabled', 'archived'], true) ? (string) $_POST['status'] : 'active';
    $data['allowed_origins'] = fi_parse_lines((string) ($_POST['allowed_origins'] ?? ''));
    $mode = (string) ($_POST['origin_validation_mode'] ?? 'compatible');
    $data['origin_validation_mode'] = in_array($mode, ['strict', 'compatible', 'disabled'], true) ? $mode : 'compatible';
    $data['notification_enabled'] = !empty($_POST['notification_enabled']);
    $data['notification_recipients'] = array_values(array_filter(array_map('fi_safe_mailbox', fi_parse_lines((string) ($_POST['notification_recipients'] ?? '')))));
    $data['notification_subject'] = trim((string) ($_POST['notification_subject'] ?? 'New submission: {form_name}'));
    $data['reply_to_field'] = trim((string) ($_POST['reply_to_field'] ?? 'email'));
    $successMode = (string) ($_POST['success_mode'] ?? 'html');
    $data['success_mode'] = in_array($successMode, ['html', 'redirect', 'json'], true) ? $successMode : 'html';
    $data['success_redirect_url'] = trim((string) ($_POST['success_redirect_url'] ?? ''));
    $data['error_redirect_url'] = trim((string) ($_POST['error_redirect_url'] ?? ''));
    $data['json_response_enabled'] = !empty($_POST['json_response_enabled']);
    $data['field_mode'] = ($_POST['field_mode'] ?? 'flexible') === 'schema' ? 'schema' : 'flexible';
    $data['field_schema'] = fi_parse_field_schema((string) ($_POST['field_schema'] ?? ''));
    $data['maximum_fields'] = max(1, min(200, (int) ($_POST['maximum_fields'] ?? fi_config('maximum_fields'))));
    $data['attachments_enabled'] = !empty($_POST['attachments_enabled']);
    $data['maximum_attachments'] = max(0, min(10, (int) ($_POST['maximum_attachments'] ?? 0)));
    $data['maximum_attachment_bytes'] = max(0, (int) ($_POST['maximum_attachment_bytes'] ?? 0));
    $data['maximum_total_attachment_bytes'] = max(0, (int) ($_POST['maximum_total_attachment_bytes'] ?? 0));
    $data['allowed_attachment_extensions'] = array_map('strtolower', fi_parse_csv((string) ($_POST['allowed_attachment_extensions'] ?? '')));
    $data['honeypot_field'] = trim((string) ($_POST['honeypot_field'] ?? '_website')) ?: '_website';
    $hp = (string) ($_POST['honeypot_behavior'] ?? 'discard');
    $data['honeypot_behavior'] = in_array($hp, ['discard', 'quarantine', 'reject'], true) ? $hp : 'discard';
    $data['minimum_completion_seconds'] = max(0, (int) ($_POST['minimum_completion_seconds'] ?? 3));
    $data['rate_limit_requests'] = max(1, (int) ($_POST['rate_limit_requests'] ?? fi_config('rate_limit_requests')));
    $data['rate_limit_window_seconds'] = max(60, (int) ($_POST['rate_limit_window_seconds'] ?? fi_config('rate_limit_window_seconds')));
    $data['duplicate_window_seconds'] = max(0, (int) ($_POST['duplicate_window_seconds'] ?? fi_config('duplicate_window_seconds')));
    $data['spam_threshold'] = max(1, (int) ($_POST['spam_threshold'] ?? 5));
    $data['reject_threshold'] = max($data['spam_threshold'], (int) ($_POST['reject_threshold'] ?? 10));
    $data['store_rejected_attempts'] = !empty($_POST['store_rejected_attempts']);
    $data['updated_at'] = fi_now();
    return fi_form_defaults($data);
}

function fi_form_create(array $form): array
{
    $forms = fi_forms_all();
    foreach ($forms as $existing) {
        if (($existing['slug'] ?? '') === $form['slug']) {
            throw new RuntimeException('A form with that slug already exists.');
        }
    }
    $forms[] = $form;
    fi_forms_save($forms);
    return $form;
}

function fi_form_update(string $id, array $form): array
{
    $forms = fi_forms_all();
    $found = false;
    foreach ($forms as $index => $existing) {
        if (($existing['id'] ?? '') === $id) {
            $form['id'] = $id;
            $form['created_at'] = $existing['created_at'] ?? fi_now();
            $forms[$index] = $form;
            $found = true;
            break;
        }
        if (($existing['slug'] ?? '') === ($form['slug'] ?? '') && ($existing['id'] ?? '') !== $id) {
            throw new RuntimeException('A form with that slug already exists.');
        }
    }
    if (!$found) {
        throw new RuntimeException('Form not found.');
    }
    fi_forms_save($forms);
    return $form;
}

function fi_form_rotate_token(string $id): void
{
    $forms = fi_forms_all();
    foreach ($forms as $index => $form) {
        if (($form['id'] ?? '') === $id) {
            $forms[$index]['public_token'] = fi_public_token();
            $forms[$index]['updated_at'] = fi_now();
            fi_forms_save($forms);
            return;
        }
    }
    throw new RuntimeException('Form not found.');
}

function fi_parse_lines(string $value): array
{
    $lines = preg_split('/\R+/', trim($value)) ?: [];
    return array_values(array_filter(array_map('trim', $lines), static fn(string $line): bool => $line !== ''));
}

function fi_parse_csv(string $value): array
{
    return array_values(array_filter(array_map('trim', preg_split('/[,\\s]+/', $value) ?: [])));
}

function fi_parse_field_schema(string $json): array
{
    $json = trim($json);
    if ($json === '') {
        return [];
    }
    $decoded = json_decode($json, true);
    return is_array($decoded) ? $decoded : [];
}

function fi_form_endpoint(array $form): string
{
    return fi_url('submit/' . rawurlencode((string) $form['slug']));
}
