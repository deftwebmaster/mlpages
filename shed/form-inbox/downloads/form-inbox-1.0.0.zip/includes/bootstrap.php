<?php

declare(strict_types=1);

require_once __DIR__ . '/helpers.php';
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/storage.php';
require_once __DIR__ . '/security.php';
require_once __DIR__ . '/csrf.php';
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/forms.php';
require_once __DIR__ . '/validation.php';
require_once __DIR__ . '/spam.php';
require_once __DIR__ . '/rate-limit.php';
require_once __DIR__ . '/attachments.php';
require_once __DIR__ . '/notifications.php';
require_once __DIR__ . '/submissions.php';
require_once __DIR__ . '/export.php';
require_once __DIR__ . '/backup.php';
require_once __DIR__ . '/response.php';

date_default_timezone_set((string) fi_config('timezone'));

set_exception_handler(static function (Throwable $exception): void {
    fi_log('error', 'Unhandled exception: ' . $exception->getMessage());
    if (fi_config('debug')) {
        http_response_code(500);
        echo '<pre>' . fi_h($exception->getMessage()) . '</pre>';
        return;
    }
    http_response_code(500);
    echo 'Form Inbox encountered a temporary problem.';
});

fi_storage_bootstrap();
