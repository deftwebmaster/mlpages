<?php

declare(strict_types=1);

function fi_rate_limit_check(string $bucket, int $limit, int $windowSeconds): array
{
    $now = time();
    $records = fi_json_read('data/rate-limits.json', []);
    $record = $records[$bucket] ?? null;
    if (!is_array($record) || (int) ($record['expires_at_unix'] ?? 0) <= $now) {
        return ['allowed' => true, 'retry_after' => 0, 'attempts' => 0];
    }
    $attempts = (int) ($record['attempts'] ?? 0);
    $allowed = $attempts < $limit;
    return [
        'allowed' => $allowed,
        'retry_after' => $allowed ? 0 : max(1, (int) $record['expires_at_unix'] - $now),
        'attempts' => $attempts,
    ];
}

function fi_rate_limit_hit(string $bucket, int $limit, int $windowSeconds): array
{
    $now = time();
    $result = ['allowed' => true, 'retry_after' => 0, 'attempts' => 1];
    fi_json_update_locked('data/rate-limits.json', static function (array $records) use ($bucket, $limit, $windowSeconds, $now, &$result): array {
        foreach ($records as $key => $record) {
            if ((int) ($record['expires_at_unix'] ?? 0) <= $now) {
                unset($records[$key]);
            }
        }
        $record = $records[$bucket] ?? [
            'hash' => $bucket,
            'attempts' => 0,
            'window_started_at' => fi_now(),
            'expires_at_unix' => $now + $windowSeconds,
            'expires_at' => gmdate('Y-m-d\TH:i:s\Z', $now + $windowSeconds),
        ];
        $record['attempts'] = (int) ($record['attempts'] ?? 0) + 1;
        $records[$bucket] = $record;
        $result = [
            'allowed' => $record['attempts'] <= $limit,
            'retry_after' => $record['attempts'] <= $limit ? 0 : max(1, (int) $record['expires_at_unix'] - $now),
            'attempts' => $record['attempts'],
        ];
        return $records;
    }, []);
    return $result;
}
