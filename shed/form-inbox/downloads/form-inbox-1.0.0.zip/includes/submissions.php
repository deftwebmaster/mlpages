<?php

declare(strict_types=1);

function fi_submission_file(string $formId, ?string $iso = null, string $bucket = 'submissions'): string
{
    $time = $iso ? strtotime($iso) : time();
    $month = gmdate('Y-m', $time ?: time());
    return 'data/' . $bucket . '/' . $formId . '/' . $month . '.json';
}

function fi_submission_store(array $submission, string $bucket = 'submissions'): void
{
    $file = fi_submission_file((string) $submission['form_id'], (string) $submission['received_at'], $bucket);
    fi_json_update_locked($file, static function (array $items) use ($submission): array {
        $items[] = $submission;
        return $items;
    }, []);
    fi_submission_index_add($submission, $file);
}

function fi_submission_index_add(array $submission, string $file): void
{
    fi_json_update_locked('data/indexes/submission-index.json', static function (array $index) use ($submission, $file): array {
        $id = (string) $submission['id'];
        $index[$id] = [
            'form_id' => (string) $submission['form_id'],
            'storage_file' => $file,
            'status' => (string) $submission['status'],
            'received_at' => (string) $submission['received_at'],
        ];
        return $index;
    }, []);
}

function fi_submission_find(string $id): ?array
{
    $index = fi_json_read('data/indexes/submission-index.json', []);
    $entry = $index[$id] ?? null;
    if (!is_array($entry)) {
        return null;
    }
    $items = fi_json_read((string) $entry['storage_file'], []);
    foreach ($items as $submission) {
        if (($submission['id'] ?? '') === $id) {
            return $submission;
        }
    }
    return null;
}

function fi_submission_update(string $id, callable $callback): ?array
{
    $index = fi_json_read('data/indexes/submission-index.json', []);
    $entry = $index[$id] ?? null;
    if (!is_array($entry)) {
        return null;
    }
    $file = (string) $entry['storage_file'];
    $updatedSubmission = null;
    fi_json_update_locked($file, static function (array $items) use ($id, $callback, &$updatedSubmission): array {
        foreach ($items as $i => $submission) {
            if (($submission['id'] ?? '') === $id) {
                $submission = $callback($submission);
                $submission['updated_at'] = fi_now();
                $items[$i] = $submission;
                $updatedSubmission = $submission;
                break;
            }
        }
        return $items;
    }, []);
    if ($updatedSubmission) {
        fi_submission_index_add($updatedSubmission, $file);
    }
    return $updatedSubmission;
}

function fi_submission_list(array $filters = [], int $page = 1, int $perPage = 25): array
{
    $index = fi_json_read('data/indexes/submission-index.json', []);
    uasort($index, static fn(array $a, array $b): int => strcmp((string) $b['received_at'], (string) $a['received_at']));
    $forms = [];
    foreach (fi_forms_all() as $form) {
        $forms[(string) $form['id']] = $form;
    }
    $query = strtolower(trim((string) ($filters['q'] ?? '')));
    $matches = [];
    foreach ($index as $id => $entry) {
        if (!empty($filters['form_id']) && ($entry['form_id'] ?? '') !== $filters['form_id']) {
            continue;
        }
        if (!empty($filters['status']) && ($entry['status'] ?? '') !== $filters['status']) {
            continue;
        }
        $submission = null;
        if ($query !== '' || !empty($filters['failed_notifications']) || !empty($filters['attachments'])) {
            $submission = fi_submission_find((string) $id);
            if (!$submission) {
                continue;
            }
            if (!empty($filters['failed_notifications']) && ($submission['notification_status'] ?? '') !== 'failed') {
                continue;
            }
            if (!empty($filters['attachments']) && empty($submission['attachments'])) {
                continue;
            }
            if ($query !== '' && !fi_submission_matches_query($submission, $forms[(string) $entry['form_id']] ?? [], $query)) {
                continue;
            }
        }
        $matches[] = ['id' => (string) $id, 'entry' => $entry, 'submission' => $submission];
    }
    $total = count($matches);
    $page = max(1, $page);
    $offset = ($page - 1) * $perPage;
    $slice = array_slice($matches, $offset, $perPage);
    foreach ($slice as $i => $row) {
        if (!$row['submission']) {
            $slice[$i]['submission'] = fi_submission_find($row['id']);
        }
    }
    return ['items' => $slice, 'total' => $total, 'page' => $page, 'per_page' => $perPage, 'forms' => $forms];
}

function fi_submission_matches_query(array $submission, array $form, string $query): bool
{
    $haystack = [
        (string) ($submission['id'] ?? ''),
        (string) ($form['name'] ?? ''),
        (string) ($submission['admin_notes'] ?? ''),
        json_encode($submission['fields'] ?? [], JSON_UNESCAPED_UNICODE) ?: '',
    ];
    return str_contains(strtolower(implode(' ', $haystack)), substr($query, 0, 120));
}

function fi_submission_status(string $id, string $status): void
{
    if (!in_array($status, ['new', 'read', 'replied', 'archived', 'spam', 'deleted'], true)) {
        throw new RuntimeException('Invalid submission status.');
    }
    fi_submission_update($id, static function (array $submission) use ($status): array {
        $submission['status'] = $status;
        return $submission;
    });
}

function fi_submission_counts(): array
{
    $counts = ['total' => 0, 'new' => 0, 'today' => 0, 'seven_days' => 0, 'spam' => 0, 'failed_notifications' => 0, 'attachment_bytes' => 0, 'most_active_form' => null];
    $byForm = [];
    $today = gmdate('Y-m-d');
    $weekAgo = time() - 7 * 86400;
    foreach (fi_json_read('data/indexes/submission-index.json', []) as $id => $entry) {
        $counts['total']++;
        $status = (string) ($entry['status'] ?? '');
        if ($status === 'new') {
            $counts['new']++;
        }
        if ($status === 'spam') {
            $counts['spam']++;
        }
        $received = (string) ($entry['received_at'] ?? '');
        if (str_starts_with($received, $today)) {
            $counts['today']++;
        }
        if ((strtotime($received) ?: 0) >= $weekAgo) {
            $counts['seven_days']++;
        }
        $formId = (string) ($entry['form_id'] ?? '');
        $byForm[$formId] = ($byForm[$formId] ?? 0) + 1;
        $submission = fi_submission_find((string) $id);
        if ($submission && ($submission['notification_status'] ?? '') === 'failed') {
            $counts['failed_notifications']++;
        }
        foreach ((array) ($submission['attachments'] ?? []) as $att) {
            $counts['attachment_bytes'] += (int) ($att['file_size'] ?? 0);
        }
    }
    arsort($byForm);
    $forms = [];
    foreach (fi_forms_all() as $form) {
        $forms[(string) $form['id']] = $form['name'];
    }
    $top = array_key_first($byForm);
    $counts['most_active_form'] = $top ? ($forms[$top] ?? $top) : 'None yet';
    return $counts;
}

function fi_submission_sender(array $submission): string
{
    $fields = (array) ($submission['fields'] ?? []);
    foreach (['name', 'full_name', 'email'] as $key) {
        if (!empty($fields[$key]) && !is_array($fields[$key])) {
            return (string) $fields[$key];
        }
    }
    return 'Unknown sender';
}

function fi_submission_email(array $submission): ?string
{
    foreach ((array) ($submission['fields'] ?? []) as $key => $value) {
        if (is_string($value) && str_contains((string) $key, 'email') && fi_safe_mailbox($value)) {
            return $value;
        }
    }
    return null;
}

function fi_submission_preview(array $submission): string
{
    foreach (['message', 'comments', 'comment', 'body'] as $key) {
        $value = $submission['fields'][$key] ?? null;
        if (is_string($value) && $value !== '') {
            return substr($value, 0, 140);
        }
    }
    $text = json_encode($submission['fields'] ?? [], JSON_UNESCAPED_UNICODE) ?: '';
    return substr($text, 0, 140);
}

function fi_submission_rebuild_index(): int
{
    $index = [];
    foreach (['submissions', 'spam', 'trash'] as $bucket) {
        foreach (glob(fi_storage_root('data/' . $bucket . '/*/*.json')) ?: [] as $path) {
            $relative = substr($path, strlen(fi_storage_root()) + 1);
            foreach (fi_json_read($relative, []) as $submission) {
                $index[(string) $submission['id']] = [
                    'form_id' => (string) $submission['form_id'],
                    'storage_file' => $relative,
                    'status' => (string) $submission['status'],
                    'received_at' => (string) $submission['received_at'],
                ];
            }
        }
    }
    fi_json_write_locked('data/indexes/submission-index.json', $index);
    return count($index);
}

function fi_rejected_event(array $event): void
{
    if (!fi_config('rejected_event_limit')) {
        return;
    }
    fi_json_update_locked('data/rejected-events.json', static function (array $events) use ($event): array {
        $events[] = array_replace(['id' => fi_random_id('rej'), 'created_at' => fi_now()], $event);
        $limit = (int) fi_config('rejected_event_limit');
        return array_slice($events, -$limit);
    }, []);
}
