<?php

declare(strict_types=1);

function fi_config(?string $key = null, mixed $default = null): mixed
{
    static $config = null;

    if ($config === null) {
        $example = require fi_root_path('config.example.php');
        $localPath = fi_root_path('config.php');
        $local = is_file($localPath) ? require $localPath : [];
        if (!is_array($local)) {
            $local = [];
        }
        $config = array_replace($example, $local);
        fi_validate_config($config);
    }

    if ($key === null) {
        return $config;
    }

    return array_key_exists($key, $config) ? $config[$key] : $default;
}

function fi_validate_config(array $config): void
{
    $required = ['app_name', 'base_url', 'timezone', 'storage_path', 'attachment_path'];
    foreach ($required as $key) {
        if (!isset($config[$key]) || trim((string) $config[$key]) === '') {
            throw new RuntimeException('Missing configuration value: ' . $key);
        }
    }
    if (!filter_var($config['base_url'], FILTER_VALIDATE_URL)) {
        throw new RuntimeException('The configured base_url is not a valid URL.');
    }
    if ((int) PHP_VERSION_ID < 80200) {
        throw new RuntimeException('Form Inbox requires PHP 8.2 or newer.');
    }
}
