<?php

declare(strict_types=1);

function fi_notify_submission(array $form, array $submission): array
{
    if (empty($form['notification_enabled'])) {
        return ['status' => 'disabled', 'message' => 'Notifications are disabled.'];
    }
    $recipients = (array) ($form['notification_recipients'] ?? []);
    if ($recipients === []) {
        $recipients = (array) fi_config('default_notification_recipients');
    }
    $recipients = array_values(array_filter(array_map('fi_safe_mailbox', $recipients)));
    if ($recipients === []) {
        return ['status' => 'failed', 'message' => 'No valid notification recipients are configured.'];
    }
    $subject = fi_notification_subject((string) ($form['notification_subject'] ?? 'New submission: {form_name}'), $form, $submission);
    $fromEmail = fi_safe_mailbox((string) fi_config('default_sender_email'));
    if (!$fromEmail) {
        return ['status' => 'failed', 'message' => 'Default sender email is invalid.'];
    }
    $fromName = str_replace(["\r", "\n"], '', (string) fi_config('default_sender_name'));
    $replyTo = null;
    $replyField = (string) ($form['reply_to_field'] ?? '');
    if ($replyField !== '' && isset($submission['fields'][$replyField]) && is_string($submission['fields'][$replyField])) {
        $replyTo = fi_safe_mailbox($submission['fields'][$replyField]);
    }
    $body = fi_notification_body($form, $submission);
    $headers = [
        'From: ' . fi_mail_header_phrase($fromName) . ' <' . $fromEmail . '>',
        'MIME-Version: 1.0',
        'Content-Type: text/plain; charset=UTF-8',
        'X-Form-Inbox: ' . (string) ($submission['id'] ?? ''),
    ];
    if ($replyTo) {
        $headers[] = 'Reply-To: ' . $replyTo;
    }
    $ok = false;
    if ((string) fi_config('mail_transport') === 'php_mail') {
        $ok = @mail(implode(',', $recipients), $subject, $body, implode("\r\n", $headers));
    }
    return [
        'status' => $ok ? 'sent' : 'failed',
        'message' => $ok ? 'Notification accepted by PHP mail().' : 'PHP mail() returned failure.',
    ];
}

function fi_notification_subject(string $template, array $form, array $submission): string
{
    $replace = [
        '{form_name}' => (string) ($form['name'] ?? 'Form'),
        '{submission_id}' => (string) ($submission['id'] ?? ''),
        '{date}' => date('Y-m-d'),
    ];
    foreach ((array) ($submission['fields'] ?? []) as $key => $value) {
        if (is_string($value)) {
            $replace['{' . $key . '}'] = substr(str_replace(["\r", "\n"], ' ', $value), 0, 80);
        }
    }
    $subject = strtr($template, $replace);
    $subject = trim(str_replace(["\r", "\n"], ' ', $subject));
    return substr($subject !== '' ? $subject : 'New form submission', 0, 180);
}

function fi_mail_header_phrase(string $value): string
{
    $value = trim(str_replace(["\r", "\n", '"'], ' ', $value));
    return $value !== '' ? '"' . addcslashes($value, '"\\') . '"' : '"Form Inbox"';
}

function fi_notification_body(array $form, array $submission): string
{
    $lines = [
        'New submission for ' . (string) ($form['name'] ?? 'Form'),
        '',
        'Submission ID: ' . (string) ($submission['id'] ?? ''),
        'Received: ' . (string) ($submission['received_at'] ?? ''),
        'Status: ' . (string) ($submission['status'] ?? ''),
        '',
        'Fields:',
    ];
    foreach ((array) ($submission['fields'] ?? []) as $key => $value) {
        $lines[] = (string) $key . ': ' . (is_array($value) ? implode(', ', array_map('strval', $value)) : (string) $value);
    }
    $lines[] = '';
    $lines[] = 'Attachments: ' . count((array) ($submission['attachments'] ?? []));
    $lines[] = 'Spam score: ' . (string) ($submission['spam_score'] ?? 0);
    $lines[] = 'View in Form Inbox: ' . fi_admin_url('submission.php?id=' . rawurlencode((string) ($submission['id'] ?? '')));
    return implode("\n", $lines);
}

function fi_retry_notification(string $submissionId): void
{
    $submission = fi_submission_find($submissionId);
    if (!$submission) {
        throw new RuntimeException('Submission not found.');
    }
    $form = fi_form_find_by_id((string) $submission['form_id']);
    if (!$form) {
        throw new RuntimeException('Form not found.');
    }
    $result = fi_notify_submission($form, $submission);
    fi_submission_update($submissionId, static function (array $item) use ($result): array {
        $item['notification_status'] = $result['status'] === 'sent' ? 'retried' : 'failed';
        $item['notification_attempted_at'] = fi_now();
        $item['notification_message'] = $result['message'];
        return $item;
    });
}
