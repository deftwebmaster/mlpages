# Changelog

## 1.0.0 - 2026-07-28

- Initial Form Inbox release.
- Added single-admin login, form endpoint management, public submission intake, JSON storage, spam controls, inbox management, CSV export, backups, diagnostics, and documentation.
