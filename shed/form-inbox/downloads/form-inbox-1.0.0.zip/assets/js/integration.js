export async function submitFormInboxForm(form, statusElement) {
    statusElement.textContent = "Sending...";
    const response = await fetch(form.action, {
        method: "POST",
        body: new FormData(form),
        headers: { "Accept": "application/json" }
    });
    const result = await response.json();
    if (!response.ok) {
        throw new Error(result.message || "The form could not be sent.");
    }
    form.reset();
    statusElement.textContent = "Your message was sent.";
    return result;
}
