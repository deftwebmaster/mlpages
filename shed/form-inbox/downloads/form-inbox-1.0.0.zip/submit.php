<?php

declare(strict_types=1);

require_once __DIR__ . '/includes/bootstrap.php';

$slug = fi_submission_slug();
$form = $slug ? fi_form_find_by_slug($slug) : null;

if (!$form) {
    if (fi_request_method() === 'OPTIONS') {
        http_response_code(404);
        exit;
    }
    fi_rejected_event(['reason' => 'invalid_endpoint', 'slug' => $slug]);
    fi_public_error('This form endpoint is not available.', 404);
}

fi_apply_cors($form);

if (fi_request_method() === 'OPTIONS') {
    http_response_code(204);
    exit;
}

if (fi_request_method() !== 'POST') {
    header('Allow: POST, OPTIONS');
    fi_public_error('This endpoint accepts form submissions only.', 405, [], $form);
}

if (($form['status'] ?? '') !== 'active') {
    fi_rejected_event(['reason' => 'inactive_form', 'form_id' => $form['id']]);
    fi_public_error('This form is not accepting submissions right now.', 422, [], $form);
}

$contentLength = (int) ($_SERVER['CONTENT_LENGTH'] ?? 0);
$maxRequest = min((int) fi_config('maximum_request_bytes'), (int) ($form['maximum_request_bytes'] ?? fi_config('maximum_request_bytes')));
if ($contentLength > $maxRequest) {
    fi_rejected_event(['reason' => 'payload_too_large', 'form_id' => $form['id']]);
    fi_public_error('The submitted form is too large.', 413, [], $form);
}

$input = fi_public_input();
$token = (string) ($input['_form_token'] ?? '');
if ($token === '' || !hash_equals((string) $form['public_token'], $token)) {
    fi_rate_limit_hit('invalid_token:' . (string) $form['id'] . ':' . fi_client_hash(), 10, 600);
    fi_rejected_event(['reason' => 'invalid_token', 'form_id' => $form['id']]);
    fi_public_error('The form could not be verified.', 422, [], $form);
}

[$originOk, $originWarning] = fi_validate_origin($form);
if (!$originOk) {
    fi_rejected_event(['reason' => 'disallowed_origin', 'form_id' => $form['id']]);
    fi_public_error('This website is not allowed to submit this form.', 422, [], $form);
}

$rate = fi_rate_limit_hit('submit:' . (string) $form['id'] . ':' . fi_client_hash(), (int) $form['rate_limit_requests'], (int) $form['rate_limit_window_seconds']);
if (!$rate['allowed']) {
    header('Retry-After: ' . (int) $rate['retry_after']);
    fi_rejected_event(['reason' => 'rate_limited', 'form_id' => $form['id']]);
    fi_public_error('Too many submissions were received. Please try again later.', 429, [], $form);
}

$signals = [];
$honeypot = (string) ($form['honeypot_field'] ?? '_website');
if ($honeypot !== '' && trim((string) ($input[$honeypot] ?? '')) !== '') {
    $signals['honeypot_filled'] = 10;
    if (($form['honeypot_behavior'] ?? 'discard') === 'discard') {
        fi_rejected_event(['reason' => 'honeypot_discarded', 'form_id' => $form['id']]);
        fi_public_success($form, null);
    }
    if (($form['honeypot_behavior'] ?? 'discard') === 'reject') {
        fi_rejected_event(['reason' => 'honeypot_rejected', 'form_id' => $form['id']]);
        fi_public_error('The form could not be sent.', 422, [], $form);
    }
}

$loadedAt = (int) ($input['_form_loaded_at'] ?? $input['_form_timestamp'] ?? 0);
if ($loadedAt > 0) {
    $age = time() - $loadedAt;
    if ($age < (int) ($form['minimum_completion_seconds'] ?? 3)) {
        $signals['completed_too_quickly'] = 3;
    }
    if ($age > (int) ($form['maximum_timestamp_age_seconds'] ?? 86400)) {
        $signals['stale_timestamp'] = 1;
    }
}
if ($originWarning) {
    $signals['weak_origin_signal'] = 1;
}

[$fields, $errors] = fi_normalize_submission_fields($input, $form);
if ($errors !== []) {
    fi_rejected_event(['reason' => 'validation_failed', 'form_id' => $form['id']]);
    fi_public_error('Please review the submitted fields.', 422, $errors, $form);
}

[$spamScore, $spamReasons] = fi_spam_score($fields, $form, $signals);
if ($spamScore >= (int) ($form['reject_threshold'] ?? 10) && ($form['honeypot_behavior'] ?? '') !== 'quarantine') {
    fi_rejected_event(['reason' => 'spam_rejected', 'form_id' => $form['id'], 'spam_score' => $spamScore]);
    fi_public_success($form, null);
}

$submissionId = fi_random_id('sub');
[$attachments, $attachmentErrors] = fi_handle_attachments($form, $submissionId);
if ($attachmentErrors !== []) {
    fi_rejected_event(['reason' => 'attachment_failed', 'form_id' => $form['id']]);
    fi_public_error('One or more attachments could not be accepted.', 422, $attachmentErrors, $form);
}

$duplicateKey = fi_duplicate_key((string) $form['id'], $fields, $attachments);
if (fi_duplicate_seen($duplicateKey, (int) ($form['duplicate_window_seconds'] ?? 60))) {
    fi_rejected_event(['reason' => 'duplicate_suppressed', 'form_id' => $form['id']]);
    fi_public_success($form, null);
}

$status = $spamScore >= (int) ($form['spam_threshold'] ?? 5) ? 'spam' : 'new';
$now = fi_now();
$submission = [
    'id' => $submissionId,
    'form_id' => (string) $form['id'],
    'status' => $status,
    'received_at' => $now,
    'updated_at' => $now,
    'fields' => $fields,
    'attachments' => $attachments,
    'referrer_url' => fi_strip_referrer($_SERVER['HTTP_REFERER'] ?? null),
    'origin' => fi_normalize_origin($_SERVER['HTTP_ORIGIN'] ?? null),
    'user_agent_category' => fi_device_category($_SERVER['HTTP_USER_AGENT'] ?? null),
    'visitor_hash' => fi_client_hash(),
    'spam_score' => $spamScore,
    'spam_reasons' => $spamReasons,
    'notification_status' => $status === 'spam' ? 'disabled' : 'pending',
    'notification_attempted_at' => null,
    'notification_message' => '',
    'admin_notes' => '',
];

fi_submission_store($submission, $status === 'spam' ? 'spam' : 'submissions');

if ($status !== 'spam') {
    $mail = fi_notify_submission($form, $submission);
    fi_submission_update($submissionId, static function (array $item) use ($mail): array {
        $item['notification_status'] = $mail['status'];
        $item['notification_attempted_at'] = fi_now();
        $item['notification_message'] = $mail['message'];
        return $item;
    });
}

fi_public_success($form, $submissionId);

function fi_submission_slug(): ?string
{
    if (!empty($_GET['form'])) {
        return fi_slugify((string) $_GET['form']);
    }
    $path = parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH);
    if (is_string($path) && preg_match('~/submit/([a-zA-Z0-9-]+)~', $path, $m)) {
        return fi_slugify($m[1]);
    }
    if (!empty($_SERVER['PATH_INFO'])) {
        return fi_slugify(trim((string) $_SERVER['PATH_INFO'], '/'));
    }
    return null;
}

function fi_public_input(): array
{
    $contentType = strtolower((string) ($_SERVER['CONTENT_TYPE'] ?? ''));
    if (str_contains($contentType, 'application/json')) {
        $raw = file_get_contents('php://input');
        $decoded = json_decode((string) $raw, true);
        if (!is_array($decoded)) {
            fi_public_error('The submitted JSON could not be read.', 415);
        }
        return $decoded;
    }
    if ($contentType === '' || str_contains($contentType, 'application/x-www-form-urlencoded') || str_contains($contentType, 'multipart/form-data')) {
        return $_POST;
    }
    fi_public_error('This content type is not supported.', 415);
}
