<?php
$endpoint = fi_form_endpoint($form);
$token = (string) $form['public_token'];
$honeypot = (string) ($form['honeypot_field'] ?? '_website');
$htmlExample = '<form action="' . $endpoint . '" method="post"' . (!empty($form['attachments_enabled']) ? ' enctype="multipart/form-data"' : '') . '>
    <input type="hidden" name="_form_token" value="' . $token . '">
    <input type="hidden" name="_form_loaded_at" value="UNIX_TIMESTAMP">

    <label>
        Name
        <input type="text" name="name" required>
    </label>

    <label>
        Email
        <input type="email" name="email" required>
    </label>

    <label>
        Message
        <textarea name="message" required></textarea>
    </label>

    <div style="position:absolute; left:-10000px; width:1px; height:1px; overflow:hidden;" aria-hidden="true">
        <label>
            Website
            <input type="text" name="' . $honeypot . '" tabindex="-1" autocomplete="off">
        </label>
    </div>

    <button type="submit">Send</button>
</form>';
$jsExample = 'const form = document.querySelector("#contact-form");
const status = document.querySelector("#form-status");

form.addEventListener("submit", async (event) => {
    event.preventDefault();
    status.textContent = "Sending...";

    try {
        const response = await fetch(form.action, {
            method: "POST",
            body: new FormData(form),
            headers: { "Accept": "application/json" }
        });
        const result = await response.json();
        if (!response.ok) throw new Error(result.message || "The form could not be sent.");
        form.reset();
        status.textContent = "Your message was sent.";
    } catch (error) {
        status.textContent = error.message;
    }
});';
?>
<section class="panel" style="margin-top:16px">
    <h2>Integration Guide</h2>
    <p><strong>Endpoint:</strong> <code><?= fi_h($endpoint) ?></code></p>
    <p><strong>Public token:</strong> <code><?= fi_h($token) ?></code></p>
    <p class="muted">For cross-origin JavaScript submissions, the page origin must exactly match one configured allowed origin.</p>
    <button class="ghost" type="button" data-copy="#plain-html">Copy HTML</button>
    <pre id="plain-html" class="codebox"><?= fi_h($htmlExample) ?></pre>
    <button class="ghost" type="button" data-copy="#fetch-js">Copy JavaScript</button>
    <pre id="fetch-js" class="codebox"><?= fi_h($jsExample) ?></pre>
</section>
