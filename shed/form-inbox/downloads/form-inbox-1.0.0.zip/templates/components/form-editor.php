<form method="post" action="<?= fi_h($action) ?>" class="panel">
    <?= fi_csrf_field() ?>
    <?php if (!empty($form['id'])): ?><input type="hidden" name="id" value="<?= fi_h($form['id']) ?>"><?php endif; ?>
    <div class="form-grid">
        <label>Form name <input name="name" required value="<?= fi_h($form['name'] ?? '') ?>"></label>
        <label>Public slug <input name="slug" required pattern="[a-z0-9-]+" value="<?= fi_h($form['slug'] ?? '') ?>"></label>
        <label>Status <select name="status"><?php foreach (['active','disabled','archived'] as $status): ?><option value="<?= $status ?>" <?= ($form['status'] ?? '') === $status ? 'selected' : '' ?>><?= ucfirst($status) ?></option><?php endforeach; ?></select></label>
        <label>Origin validation <select name="origin_validation_mode"><?php foreach (['compatible','strict','disabled'] as $mode): ?><option value="<?= $mode ?>" <?= ($form['origin_validation_mode'] ?? '') === $mode ? 'selected' : '' ?>><?= ucfirst($mode) ?></option><?php endforeach; ?></select></label>
        <label class="span-2">Description <textarea name="description"><?= fi_h($form['description'] ?? '') ?></textarea></label>
        <label class="span-2">Allowed origins <textarea name="allowed_origins" placeholder="https://example.com"><?= fi_h(implode("\n", (array) ($form['allowed_origins'] ?? []))) ?></textarea></label>

        <label><input type="checkbox" name="notification_enabled" value="1" <?= !empty($form['notification_enabled']) ? 'checked' : '' ?>> Email notifications enabled</label>
        <label>Reply-To field <input name="reply_to_field" value="<?= fi_h($form['reply_to_field'] ?? 'email') ?>"></label>
        <label class="span-2">Notification recipients <textarea name="notification_recipients" placeholder="owner@example.com"><?= fi_h(implode("\n", (array) ($form['notification_recipients'] ?? []))) ?></textarea></label>
        <label class="span-2">Notification subject <input name="notification_subject" value="<?= fi_h($form['notification_subject'] ?? 'New submission: {form_name}') ?>"></label>

        <label>Success mode <select name="success_mode"><?php foreach (['html','redirect','json'] as $mode): ?><option value="<?= $mode ?>" <?= ($form['success_mode'] ?? '') === $mode ? 'selected' : '' ?>><?= ucfirst($mode) ?></option><?php endforeach; ?></select></label>
        <label><input type="checkbox" name="json_response_enabled" value="1" <?= !empty($form['json_response_enabled']) ? 'checked' : '' ?>> JSON responses enabled</label>
        <label>Success redirect URL <input type="url" name="success_redirect_url" value="<?= fi_h($form['success_redirect_url'] ?? '') ?>"></label>
        <label>Error redirect URL <input type="url" name="error_redirect_url" value="<?= fi_h($form['error_redirect_url'] ?? '') ?>"></label>

        <label>Field mode <select name="field_mode"><option value="flexible" <?= ($form['field_mode'] ?? '') === 'flexible' ? 'selected' : '' ?>>Flexible</option><option value="schema" <?= ($form['field_mode'] ?? '') === 'schema' ? 'selected' : '' ?>>Schema</option></select></label>
        <label>Maximum fields <input type="number" min="1" max="200" name="maximum_fields" value="<?= (int) ($form['maximum_fields'] ?? fi_config('maximum_fields')) ?>"></label>
        <label class="span-2">Field schema JSON <textarea name="field_schema" spellcheck="false"><?= fi_h(json_encode($form['field_schema'] ?? [], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES)) ?></textarea></label>

        <label>Honeypot field <input name="honeypot_field" value="<?= fi_h($form['honeypot_field'] ?? '_website') ?>"></label>
        <label>Honeypot behavior <select name="honeypot_behavior"><?php foreach (['discard','quarantine','reject'] as $mode): ?><option value="<?= $mode ?>" <?= ($form['honeypot_behavior'] ?? '') === $mode ? 'selected' : '' ?>><?= ucfirst($mode) ?></option><?php endforeach; ?></select></label>
        <label>Minimum seconds <input type="number" min="0" name="minimum_completion_seconds" value="<?= (int) ($form['minimum_completion_seconds'] ?? 3) ?>"></label>
        <label>Rate limit requests <input type="number" min="1" name="rate_limit_requests" value="<?= (int) ($form['rate_limit_requests'] ?? fi_config('rate_limit_requests')) ?>"></label>
        <label>Rate window seconds <input type="number" min="60" name="rate_limit_window_seconds" value="<?= (int) ($form['rate_limit_window_seconds'] ?? fi_config('rate_limit_window_seconds')) ?>"></label>
        <label>Duplicate window seconds <input type="number" min="0" name="duplicate_window_seconds" value="<?= (int) ($form['duplicate_window_seconds'] ?? fi_config('duplicate_window_seconds')) ?>"></label>
        <label>Spam threshold <input type="number" min="1" name="spam_threshold" value="<?= (int) ($form['spam_threshold'] ?? 5) ?>"></label>
        <label>Reject threshold <input type="number" min="1" name="reject_threshold" value="<?= (int) ($form['reject_threshold'] ?? 10) ?>"></label>
        <label><input type="checkbox" name="store_rejected_attempts" value="1" <?= !empty($form['store_rejected_attempts']) ? 'checked' : '' ?>> Store rejected events</label>

        <label><input type="checkbox" name="attachments_enabled" value="1" <?= !empty($form['attachments_enabled']) ? 'checked' : '' ?>> Attachments enabled</label>
        <label>Maximum attachments <input type="number" min="0" max="10" name="maximum_attachments" value="<?= (int) ($form['maximum_attachments'] ?? 0) ?>"></label>
        <label>Maximum file bytes <input type="number" min="0" name="maximum_attachment_bytes" value="<?= (int) ($form['maximum_attachment_bytes'] ?? 0) ?>"></label>
        <label>Maximum total bytes <input type="number" min="0" name="maximum_total_attachment_bytes" value="<?= (int) ($form['maximum_total_attachment_bytes'] ?? 0) ?>"></label>
        <label class="span-2">Allowed extensions <input name="allowed_attachment_extensions" value="<?= fi_h(implode(', ', (array) ($form['allowed_attachment_extensions'] ?? []))) ?>" placeholder="pdf, docx, jpg, png"></label>
    </div>
    <p><button type="submit">Save form</button> <a class="button ghost" href="forms.php">Cancel</a></p>
</form>
<?php if (!empty($form['id'])): ?>
<form method="post" action="actions/form-rotate-token.php" class="panel" style="margin-top:16px">
    <?= fi_csrf_field() ?><input type="hidden" name="id" value="<?= fi_h($form['id']) ?>">
    <p><strong>Public token:</strong> <code><?= fi_h($form['public_token']) ?></code></p>
    <p class="muted">Rotating this token requires updating the hidden field on your website.</p>
    <button class="ghost" type="submit">Rotate token</button>
</form>
<form method="post" action="actions/form-delete.php" class="panel" style="margin-top:16px">
    <?= fi_csrf_field() ?><input type="hidden" name="id" value="<?= fi_h($form['id']) ?>">
    <h2>Archive or Delete</h2>
    <p class="muted">A backup is created first. Version 1 keeps submissions and attachments unless you delete them separately from retention maintenance.</p>
    <label>Action <select name="mode"><option value="archive">Archive form and retain submissions</option><option value="delete_config">Delete form configuration and retain submissions</option></select></label>
    <p><button class="danger" type="submit">Apply destructive action</button></p>
</form>
<?php endif; ?>
