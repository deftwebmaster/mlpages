<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= fi_h($title) ?></title>
    <link rel="stylesheet" href="<?= fi_h(fi_url('assets/css/public.css')) ?>">
</head>
<body>
    <main class="public-card">
        <p class="eyebrow"><?= fi_h(fi_config('app_name')) ?></p>
        <h1><?= fi_h($title) ?></h1>
        <p><?= fi_h($message) ?></p>
    </main>
</body>
</html>
