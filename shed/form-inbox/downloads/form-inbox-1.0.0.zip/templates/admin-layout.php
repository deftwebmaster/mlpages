<?php

declare(strict_types=1);

$flash = fi_admin_flash();
$current = basename($_SERVER['SCRIPT_NAME'] ?? '');
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= fi_h($pageTitle ?? fi_config('app_name')) ?></title>
    <link rel="stylesheet" href="../assets/css/admin.css">
    <style>:root{--accent:<?= fi_h((string) fi_config('accent_color')) ?>}</style>
</head>
<body>
<div class="app-shell">
    <aside class="sidebar">
        <a class="brand" href="index.php">
            <span class="brand-mark">FI</span>
            <span><strong><?= fi_h(fi_config('app_name')) ?></strong><small><?= fi_h(fi_config('tagline')) ?></small></span>
        </a>
        <nav aria-label="Admin navigation">
            <?php foreach ([
                'index.php' => 'Dashboard',
                'inbox.php' => 'Inbox',
                'forms.php' => 'Forms',
                'spam.php' => 'Spam',
                'trash.php' => 'Trash',
                'exports.php' => 'Exports',
                'backups.php' => 'Backups',
                'diagnostics.php' => 'Diagnostics',
                'settings.php' => 'Settings',
            ] as $href => $label): ?>
                <a class="<?= $current === $href ? 'active' : '' ?>" href="<?= fi_h($href) ?>"><?= fi_h($label) ?></a>
            <?php endforeach; ?>
        </nav>
        <form method="post" action="actions/logout.php">
            <?= fi_csrf_field() ?>
            <button class="ghost full" type="submit">Log out</button>
        </form>
    </aside>
    <main class="main">
        <header class="topbar">
            <div>
                <p class="eyebrow">Script Shed</p>
                <h1><?= fi_h($pageTitle ?? fi_config('app_name')) ?></h1>
            </div>
            <?php if (!empty($pageAction)): ?>
                <div><?= $pageAction ?></div>
            <?php endif; ?>
        </header>
        <?php if ($flash): ?>
            <div class="notice <?= fi_h($flash['type']) ?>" role="status"><?= fi_h($flash['message']) ?></div>
        <?php endif; ?>
        <?= $content ?>
        <footer class="footer"><?= fi_h(fi_config('admin_footer')) ?></footer>
    </main>
</div>
<script src="../assets/js/admin.js"></script>
</body>
</html>
