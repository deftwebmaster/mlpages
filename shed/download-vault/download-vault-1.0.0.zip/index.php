<?php
declare(strict_types=1);

require_once __DIR__ . '/includes/bootstrap.php';
dv_redirect(dv_url('admin/'));
