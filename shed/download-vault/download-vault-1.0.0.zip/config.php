<?php
declare(strict_types=1);

return [
    'app_name' => 'Download Vault',
    'tagline' => 'Protected file delivery without the platform.',
    'base_url' => '',
    'timezone' => 'America/Chicago',

    'admin_password_hash' => 'REPLACE_WITH_PASSWORD_HASH',
    'privacy_salt' => 'change-this-to-a-long-random-secret-before-launch',
    'session_timeout_minutes' => 30,

    'storage_path' => __DIR__ . '/storage',
    'files_path' => __DIR__ . '/private-files',
    'import_path' => __DIR__ . '/import',

    'max_upload_bytes' => 104857600,
    'backup_retention' => 10,
    'history_limit' => 1000,

    'allowed_extensions' => [
        'pdf', 'zip', 'txt', 'csv', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx',
        'jpg', 'jpeg', 'png', 'gif', 'webp', 'svg', 'mp3', 'mp4', 'json', 'xml',
    ],
    'blocked_extensions' => [
        'php', 'php3', 'php4', 'php5', 'php7', 'php8', 'phtml', 'phar', 'cgi',
        'pl', 'py', 'sh', 'htaccess', 'user.ini',
    ],
    'inline_extensions' => ['pdf', 'jpg', 'jpeg', 'png', 'gif', 'webp', 'txt'],

    'show_powered_by' => true,
    'public_footer' => 'Powered by Download Vault',
    'homepage_url' => '',
    'support_url' => '',
    'accent_color' => '#2563eb',

    'track_referrer_domains' => true,
    'track_device_types' => true,
    'estimate_unique_downloads' => false,
    'unique_window_hours' => 168,
    'store_blocked_history' => true,

    'routing_mode' => 'rewrite',
    'debug' => false,
];
