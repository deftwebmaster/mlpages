<?php
declare(strict_types=1);

$hash = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $password = (string) ($_POST['password'] ?? '');
    if ($password !== '') {
        $hash = password_hash($password, PASSWORD_DEFAULT);
    }
}

if (PHP_SAPI === 'cli') {
    $password = $argv[1] ?? '';
    if ($password === '') {
        fwrite(STDERR, "Usage: php tools/generate-password.php 'your password'\n");
        exit(1);
    }
    echo password_hash($password, PASSWORD_DEFAULT) . PHP_EOL;
    exit;
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Generate Download Vault Password Hash</title>
    <style>
        body { margin: 0; min-height: 100vh; display: grid; place-items: center; padding: 1rem; font: 16px/1.5 system-ui, sans-serif; background: #f6f7f9; color: #172033; }
        main { width: min(680px, 100%); background: white; border: 1px solid #dfe4ec; border-radius: 8px; padding: 1.5rem; }
        input, textarea, button { width: 100%; border: 1px solid #dfe4ec; border-radius: 8px; padding: 0.75rem; font: inherit; }
        button { background: #2563eb; color: white; border-color: #2563eb; margin-top: 0.75rem; cursor: pointer; }
        .warning { border: 1px solid #e0a800; color: #7a4b00; padding: 0.75rem; border-radius: 8px; }
        textarea { min-height: 120px; }
    </style>
</head>
<body>
<main>
    <h1>Password Hash Helper</h1>
    <p class="warning">Generate the hash, paste it into config.php, then delete this file from your server.</p>
    <form method="post">
        <label for="password">Administrator password</label>
        <input id="password" name="password" type="password" required autofocus autocomplete="new-password">
        <button type="submit">Generate Hash</button>
    </form>
    <?php if ($hash): ?>
        <h2>Hash</h2>
        <textarea readonly><?php echo htmlspecialchars($hash, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); ?></textarea>
    <?php endif; ?>
</main>
</body>
</html>
