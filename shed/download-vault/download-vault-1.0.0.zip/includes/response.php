<?php
declare(strict_types=1);

function dv_render_admin(string $title, string $view, array $vars = []): void
{
    dv_security_headers('admin');
    extract($vars, EXTR_SKIP);
    $contentView = $view;
    include DV_ROOT . '/templates/admin-layout.php';
}

function dv_public_error(string $message, int $status = 404, string $title = 'Download unavailable'): never
{
    http_response_code($status);
    dv_security_headers('public');
    include DV_ROOT . '/templates/public-error.php';
    exit;
}
