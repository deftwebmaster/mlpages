<?php
declare(strict_types=1);

function dv_storage_file(string $name): string
{
    $allowed = ['downloads', 'history', 'daily-stats', 'rate-limits'];
    if (!in_array($name, $allowed, true)) {
        throw new InvalidArgumentException('Unknown data store.');
    }
    return rtrim((string) dv_config('storage_path'), '/\\') . '/' . $name . '.json';
}

function dv_storage_default(string $name): array
{
    return match ($name) {
        'downloads' => ['schema_version' => 1, 'downloads' => []],
        'history' => ['schema_version' => 1, 'events' => []],
        'daily-stats' => ['schema_version' => 1, 'days' => []],
        'rate-limits' => ['schema_version' => 1, 'buckets' => []],
        default => ['schema_version' => 1],
    };
}

function dv_storage_read(string $name): array
{
    $path = dv_storage_file($name);
    if (!is_file($path)) {
        return dv_storage_default($name);
    }
    $json = file_get_contents($path);
    if ($json === false) {
        throw new RuntimeException('Unable to read data store.');
    }
    $data = json_decode($json, true);
    if (!is_array($data) || json_last_error() !== JSON_ERROR_NONE) {
        dv_preserve_corrupt_file($path);
        throw new RuntimeException('Data store contains malformed JSON: ' . basename($path));
    }
    return $data;
}

function dv_storage_update(string $name, callable $mutator, bool $makeBackup = false): array
{
    $path = dv_storage_file($name);
    $dir = dirname($path);
    if (!is_dir($dir)) {
        mkdir($dir, 0755, true);
    }
    $lockPath = rtrim((string) dv_config('storage_path'), '/\\') . '/locks/' . $name . '.lock';
    $lock = fopen($lockPath, 'c+');
    if (!$lock) {
        throw new RuntimeException('Unable to open data lock.');
    }
    try {
        if (!flock($lock, LOCK_EX)) {
            throw new RuntimeException('Unable to lock data store.');
        }
        $data = dv_storage_read($name);
        if ($makeBackup && is_file($path)) {
            dv_backup_raw($name, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES) . PHP_EOL);
        }
        $updated = $mutator($data);
        if (!is_array($updated)) {
            throw new RuntimeException('Storage mutator did not return data.');
        }
        dv_storage_write_locked($path, $updated);
        flock($lock, LOCK_UN);
        return $updated;
    } finally {
        fclose($lock);
    }
}

function dv_storage_write_locked(string $path, array $data): void
{
    $json = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
    if ($json === false) {
        throw new RuntimeException('Data could not be encoded as JSON.');
    }
    json_decode($json, true);
    if (json_last_error() !== JSON_ERROR_NONE) {
        throw new RuntimeException('Encoded data failed JSON validation.');
    }
    $tmp = tempnam(dirname($path), '.tmp-' . basename($path) . '-');
    if ($tmp === false) {
        throw new RuntimeException('Unable to create temporary data file.');
    }
    try {
        $handle = fopen($tmp, 'wb');
        if (!$handle) {
            throw new RuntimeException('Unable to open temporary data file.');
        }
        fwrite($handle, $json . PHP_EOL);
        fflush($handle);
        fclose($handle);
        json_decode((string) file_get_contents($tmp), true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            throw new RuntimeException('Temporary JSON failed validation.');
        }
        if (!rename($tmp, $path)) {
            throw new RuntimeException('Unable to replace data store atomically.');
        }
        @chmod($path, 0640);
    } finally {
        if (is_file($tmp)) {
            @unlink($tmp);
        }
    }
}

function dv_preserve_corrupt_file(string $path): void
{
    $target = $path . '.corrupt-' . gmdate('YmdHis');
    @copy($path, $target);
    dv_log_error('Malformed JSON preserved.', ['file' => basename($path)]);
}
