<?php
declare(strict_types=1);

function dv_backup_raw(string $name, string $json): string
{
    $dir = rtrim((string) dv_config('storage_path'), '/\\') . '/backups';
    if (!is_dir($dir)) {
        mkdir($dir, 0755, true);
    }
    $file = $dir . '/' . $name . '-' . gmdate('Y-m-d-His') . '.json';
    if (file_put_contents($file, $json, LOCK_EX) === false) {
        throw new RuntimeException('Backup could not be written.');
    }
    dv_prune_backups($name);
    return $file;
}

function dv_create_backup(string $name = 'downloads'): string
{
    $data = dv_storage_read($name);
    $json = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
    if ($json === false) {
        throw new RuntimeException('Backup data could not be encoded.');
    }
    return dv_backup_raw($name, $json . PHP_EOL);
}

function dv_prune_backups(string $name): void
{
    $retention = max(1, (int) dv_config('backup_retention', 10));
    $files = dv_list_backups($name);
    if (count($files) <= $retention) {
        return;
    }
    $remove = array_slice($files, $retention);
    foreach ($remove as $file) {
        @unlink($file['path']);
    }
}

function dv_list_backups(?string $name = null): array
{
    $dir = rtrim((string) dv_config('storage_path'), '/\\') . '/backups';
    $pattern = $dir . '/' . ($name ? $name . '-' : '*') . '*.json';
    $paths = glob($pattern) ?: [];
    usort($paths, static fn ($a, $b) => filemtime($b) <=> filemtime($a));
    return array_map(static fn ($path) => [
        'name' => basename($path),
        'path' => $path,
        'size' => is_file($path) ? filesize($path) : 0,
        'created' => is_file($path) ? filemtime($path) : 0,
    ], $paths);
}

function dv_restore_backup(string $backupName): void
{
    $safe = basename($backupName);
    $path = rtrim((string) dv_config('storage_path'), '/\\') . '/backups/' . $safe;
    if (!is_file($path)) {
        throw new RuntimeException('Backup file was not found.');
    }
    $json = file_get_contents($path);
    $data = json_decode((string) $json, true);
    if (!is_array($data) || json_last_error() !== JSON_ERROR_NONE || !isset($data['schema_version'])) {
        throw new RuntimeException('Backup file is not valid Download Vault JSON.');
    }
    $store = str_starts_with($safe, 'history-') ? 'history' : (str_starts_with($safe, 'daily-stats-') ? 'daily-stats' : 'downloads');
    dv_storage_update($store, static fn (array $current): array => $data, true);
}
