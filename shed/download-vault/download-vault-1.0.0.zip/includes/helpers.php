<?php
declare(strict_types=1);

$GLOBALS['DV_CONFIG'] = [];

function dv_configure(array $config): void
{
    $GLOBALS['DV_CONFIG'] = $config;
    $timezone = (string) dv_config('timezone', 'UTC');
    date_default_timezone_set($timezone ?: 'UTC');
}

function dv_config(?string $key = null, mixed $default = null): mixed
{
    if ($key === null) {
        return $GLOBALS['DV_CONFIG'];
    }
    return $GLOBALS['DV_CONFIG'][$key] ?? $default;
}

function dv_e(mixed $value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function dv_now(): string
{
    return gmdate('Y-m-d\TH:i:s\Z');
}

function dv_local_time(?string $iso, string $fallback = 'Never'): string
{
    if (!$iso) {
        return $fallback;
    }
    try {
        $date = new DateTimeImmutable($iso);
        return $date->setTimezone(new DateTimeZone((string) dv_config('timezone', 'UTC')))->format('M j, Y g:i A');
    } catch (Throwable) {
        return $fallback;
    }
}

function dv_date_input(?string $iso): string
{
    if (!$iso) {
        return '';
    }
    try {
        $date = new DateTimeImmutable($iso);
        return $date->setTimezone(new DateTimeZone((string) dv_config('timezone', 'UTC')))->format('Y-m-d\TH:i');
    } catch (Throwable) {
        return '';
    }
}

function dv_input_to_utc(?string $value): ?string
{
    $value = trim((string) $value);
    if ($value === '') {
        return null;
    }
    $date = new DateTimeImmutable($value, new DateTimeZone((string) dv_config('timezone', 'UTC')));
    return $date->setTimezone(new DateTimeZone('UTC'))->format('Y-m-d\TH:i:s\Z');
}

function dv_format_bytes(int|float $bytes): string
{
    $units = ['B', 'KB', 'MB', 'GB', 'TB'];
    $size = max(0, (float) $bytes);
    $unit = 0;
    while ($size >= 1024 && $unit < count($units) - 1) {
        $size /= 1024;
        $unit++;
    }
    return ($unit === 0 ? (string) (int) $size : number_format($size, 1)) . ' ' . $units[$unit];
}

function dv_id(string $prefix): string
{
    return $prefix . '_' . gmdate('YmdHis') . '_' . bin2hex(random_bytes(5));
}

function dv_base_url(): string
{
    $configured = rtrim((string) dv_config('base_url', ''), '/');
    if ($configured !== '') {
        return $configured;
    }
    if (PHP_SAPI === 'cli') {
        return '';
    }
    $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || ((int) ($_SERVER['SERVER_PORT'] ?? 80) === 443);
    $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
    $scriptDir = str_replace('\\', '/', dirname((string) ($_SERVER['SCRIPT_NAME'] ?? '')));
    $scriptDir = preg_replace('#/(admin|tools)$#', '', $scriptDir) ?: '';
    return ($https ? 'https://' : 'http://') . $host . rtrim($scriptDir, '/');
}

function dv_url(string $path = ''): string
{
    return rtrim(dv_base_url(), '/') . '/' . ltrim($path, '/');
}

function dv_public_download_url(string $slug): string
{
    if (dv_config('routing_mode', 'rewrite') === 'fallback') {
        return dv_url('download.php?slug=' . rawurlencode($slug));
    }
    return dv_url('d/' . rawurlencode($slug));
}

function dv_redirect(string $url): never
{
    header('Location: ' . $url, true, 303);
    exit;
}

function dv_post(string $key, mixed $default = ''): mixed
{
    return $_POST[$key] ?? $default;
}

function dv_get(string $key, mixed $default = ''): mixed
{
    return $_GET[$key] ?? $default;
}

function dv_bool_from_post(string $key): bool
{
    return isset($_POST[$key]) && in_array((string) $_POST[$key], ['1', 'on', 'yes', 'true'], true);
}

function dv_slugify(string $value): string
{
    $value = strtolower(trim($value));
    $value = preg_replace('/[^a-z0-9_-]+/', '-', $value) ?? '';
    $value = trim(preg_replace('/-+/', '-', $value) ?? '', '-_');
    return $value;
}

function dv_flash(?string $message = null, string $type = 'success'): ?array
{
    if ($message !== null) {
        $_SESSION['flash'] = ['message' => $message, 'type' => $type];
        return null;
    }
    $flash = $_SESSION['flash'] ?? null;
    unset($_SESSION['flash']);
    return is_array($flash) ? $flash : null;
}

function dv_log_error(string $message, array $context = []): void
{
    $path = $GLOBALS['DV_CONFIG']['storage_path'] ?? (defined('DV_ROOT') ? DV_ROOT . '/storage' : sys_get_temp_dir());
    $logDir = rtrim((string) $path, '/\\') . '/logs';
    if (!is_dir($logDir)) {
        @mkdir($logDir, 0755, true);
    }
    $line = dv_now() . ' ' . $message;
    if ($context !== []) {
        $line .= ' ' . json_encode($context, JSON_UNESCAPED_SLASHES);
    }
    $file = $logDir . '/app.log';
    if (@is_file($file) && @filesize($file) > 1048576) {
        @rename($file, $logDir . '/app-' . gmdate('YmdHis') . '.log');
    }
    @file_put_contents($file, $line . PHP_EOL, FILE_APPEND | LOCK_EX);
}

function dv_validate_config(): void
{
    foreach (['storage_path', 'files_path', 'import_path'] as $key) {
        $path = (string) dv_config($key, '');
        if ($path === '') {
            throw new RuntimeException('Configuration value ' . $key . ' is required.');
        }
        if (!is_dir($path) && !mkdir($path, 0755, true)) {
            throw new RuntimeException('Directory could not be created: ' . $key);
        }
    }
    foreach (['backups', 'locks', 'logs'] as $dir) {
        $path = rtrim((string) dv_config('storage_path'), '/\\') . '/' . $dir;
        if (!is_dir($path)) {
            @mkdir($path, 0755, true);
        }
    }
}
