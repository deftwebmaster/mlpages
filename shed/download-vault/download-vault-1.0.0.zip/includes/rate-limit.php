<?php
declare(strict_types=1);

function dv_rate_limit_check(string $bucket, string $identifier, int $limit, int $windowSeconds, bool $increment = true): bool
{
    $now = time();
    $ok = true;
    try {
        dv_storage_update('rate-limits', static function (array $data) use ($bucket, $identifier, $limit, $windowSeconds, $increment, $now, &$ok): array {
            $data['buckets'] ??= [];
            $data['buckets'][$bucket] ??= [];
            $records = $data['buckets'][$bucket][$identifier] ?? [];
            $records = array_values(array_filter($records, static fn ($ts) => is_int($ts) && $ts > ($now - $windowSeconds)));
            if (count($records) >= $limit) {
                $ok = false;
            } elseif ($increment) {
                $records[] = $now;
            }
            $data['buckets'][$bucket][$identifier] = $records;
            foreach ($data['buckets'] as $b => $ids) {
                foreach ($ids as $id => $timestamps) {
                    $fresh = array_values(array_filter((array) $timestamps, static fn ($ts) => is_int($ts) && $ts > ($now - 86400)));
                    if ($fresh === []) {
                        unset($data['buckets'][$b][$id]);
                    } else {
                        $data['buckets'][$b][$id] = $fresh;
                    }
                }
            }
            return $data;
        });
    } catch (Throwable $e) {
        dv_log_error('Rate limit storage failed: ' . $e->getMessage());
        return true;
    }
    return $ok;
}
