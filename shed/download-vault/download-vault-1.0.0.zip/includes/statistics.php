<?php
declare(strict_types=1);

function dv_stats_increment(string $downloadId): void
{
    $day = gmdate('Y-m-d');
    dv_storage_update('daily-stats', static function (array $data) use ($downloadId, $day): array {
        $data['days'] ??= [];
        $data['days'][$downloadId] ??= [];
        $data['days'][$downloadId][$day] = (int) ($data['days'][$downloadId][$day] ?? 0) + 1;
        return $data;
    });
}

function dv_stats_for_download(string $downloadId): array
{
    $data = dv_storage_read('daily-stats');
    $days = (array) (($data['days'] ?? [])[$downloadId] ?? []);
    ksort($days);
    $today = gmdate('Y-m-d');
    $last7 = 0;
    $last30 = 0;
    $highestDay = null;
    $highestCount = 0;
    foreach ($days as $day => $count) {
        $count = (int) $count;
        if ($day >= gmdate('Y-m-d', strtotime('-6 days'))) {
            $last7 += $count;
        }
        if ($day >= gmdate('Y-m-d', strtotime('-29 days'))) {
            $last30 += $count;
        }
        if ($count > $highestCount) {
            $highestCount = $count;
            $highestDay = $day;
        }
    }
    return [
        'today' => (int) ($days[$today] ?? 0),
        'last7' => $last7,
        'last30' => $last30,
        'highest_day' => $highestDay,
        'highest_count' => $highestCount,
        'days' => $days,
    ];
}

function dv_dashboard_summary(): array
{
    $downloads = dv_download_all();
    $active = 0;
    $expired = 0;
    $missing = 0;
    $nearLimit = 0;
    $total = 0;
    $most = null;
    foreach ($downloads as $download) {
        $status = dv_download_status($download);
        if ($status['code'] === 'active') {
            $active++;
        }
        if ($status['code'] === 'expired') {
            $expired++;
        }
        if ($status['code'] === 'missing_file') {
            $missing++;
        }
        $count = (int) ($download['download_count'] ?? 0);
        $total += $count;
        $max = $download['maximum_downloads'] ?? null;
        if ($max !== null && (int) $max > 0 && $count >= ((int) $max * 0.8)) {
            $nearLimit++;
        }
        if (!$most || $count > (int) ($most['download_count'] ?? 0)) {
            $most = $download;
        }
    }
    $stats = dv_storage_read('daily-stats');
    $today = gmdate('Y-m-d');
    $todayCount = 0;
    $last7 = 0;
    foreach ((array) ($stats['days'] ?? []) as $days) {
        foreach ((array) $days as $day => $count) {
            if ($day === $today) {
                $todayCount += (int) $count;
            }
            if ($day >= gmdate('Y-m-d', strtotime('-6 days'))) {
                $last7 += (int) $count;
            }
        }
    }
    return [
        'active' => $active,
        'total_downloads' => $total,
        'today' => $todayCount,
        'last7' => $last7,
        'expired' => $expired,
        'near_limit' => $nearLimit,
        'missing' => $missing,
        'most' => $most,
    ];
}
