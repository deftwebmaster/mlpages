<?php
declare(strict_types=1);

function dv_private_file_path(string $storedFilename): string
{
    return rtrim((string) dv_config('files_path'), '/\\') . '/' . basename($storedFilename);
}

function dv_import_files(): array
{
    $dir = rtrim((string) dv_config('import_path'), '/\\');
    $paths = glob($dir . '/*') ?: [];
    $files = [];
    foreach ($paths as $path) {
        if (!is_file($path)) {
            continue;
        }
        $name = basename($path);
        $errors = dv_validate_filename($name);
        $files[] = [
            'name' => $name,
            'size' => filesize($path) ?: 0,
            'valid' => $errors === [],
            'errors' => $errors,
        ];
    }
    return $files;
}

function dv_file_metadata(string $path, string $originalFilename): array
{
    if (!is_file($path) || !is_readable($path)) {
        throw new RuntimeException('The file could not be read.');
    }
    $finfo = new finfo(FILEINFO_MIME_TYPE);
    return [
        'original_filename' => dv_safe_filename($originalFilename),
        'file_size' => filesize($path) ?: 0,
        'mime_type' => $finfo->file($path) ?: 'application/octet-stream',
        'file_hash' => hash_file('sha256', $path) ?: '',
    ];
}

function dv_store_uploaded_file(array $upload): array
{
    if (($upload['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
        throw new RuntimeException('The upload did not complete.');
    }
    $original = (string) ($upload['name'] ?? 'download');
    $errors = dv_validate_filename($original);
    if ($errors !== []) {
        throw new RuntimeException(implode(' ', $errors));
    }
    $size = (int) ($upload['size'] ?? 0);
    if ($size <= 0 || $size > (int) dv_config('max_upload_bytes', 104857600)) {
        throw new RuntimeException('The file is larger than the configured upload limit.');
    }
    $tmp = (string) ($upload['tmp_name'] ?? '');
    if (!is_uploaded_file($tmp)) {
        throw new RuntimeException('The uploaded file was not accepted.');
    }
    $ext = dv_extension($original);
    $stored = 'f_' . gmdate('YmdHis') . '_' . bin2hex(random_bytes(8)) . '.' . $ext;
    $target = dv_private_file_path($stored);
    if (!move_uploaded_file($tmp, $target)) {
        throw new RuntimeException('The uploaded file could not be moved into protected storage.');
    }
    @chmod($target, 0640);
    return ['stored_filename' => $stored] + dv_file_metadata($target, $original);
}

function dv_store_import_file(string $name): array
{
    $safe = basename($name);
    if ($safe !== $name) {
        throw new RuntimeException('The import filename was not accepted.');
    }
    $errors = dv_validate_filename($safe);
    if ($errors !== []) {
        throw new RuntimeException(implode(' ', $errors));
    }
    $sourceBase = realpath((string) dv_config('import_path'));
    $source = realpath(rtrim((string) dv_config('import_path'), '/\\') . '/' . $safe);
    if (!$sourceBase || !$source || !str_starts_with($source, $sourceBase . DIRECTORY_SEPARATOR) || !is_file($source)) {
        throw new RuntimeException('The import file was not found.');
    }
    $ext = dv_extension($safe);
    $stored = 'f_' . gmdate('YmdHis') . '_' . bin2hex(random_bytes(8)) . '.' . $ext;
    $target = dv_private_file_path($stored);
    if (!rename($source, $target)) {
        throw new RuntimeException('The import file could not be moved into protected storage.');
    }
    @chmod($target, 0640);
    return ['stored_filename' => $stored] + dv_file_metadata($target, $safe);
}

function dv_stream_file(array $download): never
{
    $filesBase = realpath((string) dv_config('files_path'));
    $path = realpath(dv_private_file_path((string) $download['stored_filename']));
    if (!$filesBase || !$path || !str_starts_with($path, $filesBase . DIRECTORY_SEPARATOR) || !is_file($path) || !is_readable($path)) {
        dv_history_add((string) $download['id'], 'missing_file');
        http_response_code(404);
        $message = 'This download is temporarily unavailable.';
        include DV_ROOT . '/templates/public-error.php';
        exit;
    }
    $filename = (string) ($download['custom_filename'] ?: $download['original_filename']);
    $mode = !empty($download['force_download']) ? 'attachment' : 'inline';
    header('X-Content-Type-Options: nosniff');
    header('Cache-Control: private, no-store');
    header('Pragma: no-cache');
    header('Expires: 0');
    header('Content-Type: ' . ((string) ($download['mime_type'] ?? 'application/octet-stream')));
    header('Content-Length: ' . filesize($path));
    header('Content-Disposition: ' . dv_content_disposition($mode, $filename));
    while (ob_get_level() > 0) {
        ob_end_clean();
    }
    $handle = fopen($path, 'rb');
    if (!$handle) {
        exit;
    }
    $chunk = 1024 * 1024;
    while (!feof($handle)) {
        echo fread($handle, $chunk);
        flush();
    }
    fclose($handle);
    exit;
}
