<?php
declare(strict_types=1);

function dv_validate_slug(string $slug, ?string $existingId = null): array
{
    $slug = dv_slugify($slug);
    $errors = [];
    $reserved = ['admin', 'login', 'logout', 'assets', 'storage', 'download', 'api', 'config', 'index', 'tools', 'd'];
    if ($slug === '') {
        $errors[] = 'Enter a slug or generate a random link.';
    }
    if (strlen($slug) < 3 || strlen($slug) > 80) {
        $errors[] = 'Slug must be between 3 and 80 characters.';
    }
    if (!preg_match('/^[a-z0-9][a-z0-9_-]*[a-z0-9]$/', $slug)) {
        $errors[] = 'Slug may contain lowercase letters, numbers, hyphens, and underscores.';
    }
    if (in_array($slug, $reserved, true)) {
        $errors[] = 'That slug is reserved.';
    }
    $existing = dv_download_find_by_slug($slug);
    if ($existing && (!$existingId || $existing['id'] !== $existingId)) {
        $errors[] = 'That slug is already in use.';
    }
    return [$slug, $errors];
}

function dv_random_slug(int $length = 8): string
{
    $alphabet = 'abcdefghjkmnpqrstuvwxyz23456789';
    do {
        $slug = '';
        for ($i = 0; $i < $length; $i++) {
            $slug .= $alphabet[random_int(0, strlen($alphabet) - 1)];
        }
    } while (dv_download_find_by_slug($slug));
    return $slug;
}

function dv_extension(string $filename): string
{
    return strtolower(pathinfo($filename, PATHINFO_EXTENSION));
}

function dv_validate_filename(string $filename): array
{
    $errors = [];
    if (preg_match('/[\x00-\x1F\x7F]/', $filename)) {
        $errors[] = 'Filename contains unsupported control characters.';
    }
    $parts = array_filter(explode('.', strtolower($filename)), static fn ($part) => $part !== '');
    $blocked = (array) dv_config('blocked_extensions', []);
    foreach ($parts as $part) {
        if (in_array($part, $blocked, true)) {
            $errors[] = 'This file type is blocked for safety.';
            break;
        }
    }
    $ext = dv_extension($filename);
    if ($ext === '' || !in_array($ext, (array) dv_config('allowed_extensions', []), true)) {
        $errors[] = 'This file extension is not allowed.';
    }
    return $errors;
}
