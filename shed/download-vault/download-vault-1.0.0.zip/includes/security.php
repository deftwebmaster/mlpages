<?php
declare(strict_types=1);

function dv_security_headers(string $context = 'public'): void
{
    if (headers_sent()) {
        return;
    }
    header('X-Content-Type-Options: nosniff');
    header('Permissions-Policy: geolocation=(), microphone=(), camera=()');
    if ($context === 'admin') {
        header('X-Frame-Options: DENY');
        header('Referrer-Policy: no-referrer');
        header('Cache-Control: no-store');
        header("Content-Security-Policy: default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; script-src 'self'; base-uri 'self'; form-action 'self'; frame-ancestors 'none'");
        return;
    }
    header('X-Frame-Options: SAMEORIGIN');
    header('Referrer-Policy: strict-origin-when-cross-origin');
    header("Content-Security-Policy: default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; script-src 'self'; base-uri 'self'; form-action 'self'");
}

function dv_start_session(): void
{
    if (session_status() === PHP_SESSION_ACTIVE || headers_sent()) {
        return;
    }
    $secure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
    session_name('download_vault');
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'domain' => '',
        'secure' => $secure,
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_start();
}

function dv_request_id(string $scope = 'default'): string
{
    $ip = (string) ($_SERVER['REMOTE_ADDR'] ?? 'cli');
    $prefix = preg_replace('/\.\d+$/', '.0', $ip) ?? $ip;
    $ua = strtolower((string) ($_SERVER['HTTP_USER_AGENT'] ?? ''));
    if (str_contains($ua, 'mobile')) {
        $device = 'mobile';
    } elseif (str_contains($ua, 'tablet') || str_contains($ua, 'ipad')) {
        $device = 'tablet';
    } else {
        $device = 'desktop';
    }
    return hash('sha256', (string) dv_config('privacy_salt', 'download-vault') . '|' . $scope . '|' . $prefix . '|' . $device);
}

function dv_referrer_domain(): ?string
{
    if (!dv_config('track_referrer_domains', true)) {
        return null;
    }
    $ref = (string) ($_SERVER['HTTP_REFERER'] ?? '');
    if ($ref === '') {
        return null;
    }
    $host = parse_url($ref, PHP_URL_HOST);
    return is_string($host) ? strtolower($host) : null;
}

function dv_device_type(): ?string
{
    if (!dv_config('track_device_types', true)) {
        return null;
    }
    $ua = strtolower((string) ($_SERVER['HTTP_USER_AGENT'] ?? ''));
    if (str_contains($ua, 'mobile')) {
        return 'mobile';
    }
    if (str_contains($ua, 'tablet') || str_contains($ua, 'ipad')) {
        return 'tablet';
    }
    return 'desktop';
}

function dv_safe_filename(string $filename): string
{
    $filename = preg_replace('/[\x00-\x1F\x7F\/\\\\]+/', '-', $filename) ?? 'download';
    $filename = trim($filename, ". \t\n\r\0\x0B-");
    return $filename !== '' ? $filename : 'download';
}

function dv_content_disposition(string $mode, string $filename): string
{
    $safe = dv_safe_filename($filename);
    $ascii = preg_replace('/[^A-Za-z0-9._ -]/', '_', $safe) ?: 'download';
    return $mode . '; filename="' . addcslashes($ascii, "\\\"") . '"; filename*=UTF-8\'\'' . rawurlencode($safe);
}
