<?php
declare(strict_types=1);

function dv_download_all(): array
{
    $data = dv_storage_read('downloads');
    $downloads = (array) ($data['downloads'] ?? []);
    usort($downloads, static fn ($a, $b) => strcmp((string) ($b['created_at'] ?? ''), (string) ($a['created_at'] ?? '')));
    return $downloads;
}

function dv_download_find(string $id): ?array
{
    foreach (dv_download_all() as $download) {
        if (($download['id'] ?? '') === $id) {
            return $download;
        }
    }
    return null;
}

function dv_download_find_by_slug(string $slug): ?array
{
    $slug = dv_slugify($slug);
    foreach (dv_download_all() as $download) {
        if (($download['slug'] ?? '') === $slug) {
            return $download;
        }
    }
    return null;
}

function dv_download_status(array $download): array
{
    if (($download['status'] ?? 'active') === 'archived') {
        return ['code' => 'archived', 'label' => 'Archived'];
    }
    if (($download['status'] ?? 'active') === 'disabled') {
        return ['code' => 'disabled', 'label' => 'Disabled'];
    }
    $path = dv_private_file_path((string) ($download['stored_filename'] ?? ''));
    if (!is_file($path)) {
        return ['code' => 'missing_file', 'label' => 'Missing file'];
    }
    $expires = $download['expires_at'] ?? null;
    if ($expires && strtotime((string) $expires) <= time()) {
        return ['code' => 'expired', 'label' => 'Expired'];
    }
    $max = $download['maximum_downloads'] ?? null;
    if ($max !== null && (int) $max > 0 && (int) ($download['download_count'] ?? 0) >= (int) $max) {
        return ['code' => 'limit_reached', 'label' => 'Limit reached'];
    }
    return ['code' => 'active', 'label' => 'Active'];
}

function dv_download_save(array $record, bool $isNew = true): array
{
    $now = dv_now();
    if ($isNew) {
        $record['id'] = dv_id('dl');
        $record['created_at'] = $now;
        $record['download_count'] = 0;
        $record['unique_download_count'] = 0;
        $record['last_downloaded_at'] = null;
    }
    $record['updated_at'] = $now;
    $record += [
        'description' => '',
        'custom_filename' => '',
        'status' => 'active',
        'password_hash' => null,
        'expires_at' => null,
        'maximum_downloads' => null,
        'landing_page_enabled' => true,
        'force_download' => true,
        'show_file_size' => true,
        'show_expiration' => true,
        'show_remaining' => false,
        'admin_notes' => '',
    ];
    dv_storage_update('downloads', static function (array $data) use ($record, $isNew): array {
        $data['downloads'] ??= [];
        if ($isNew) {
            $data['downloads'][] = $record;
            return $data;
        }
        foreach ($data['downloads'] as $i => $existing) {
            if (($existing['id'] ?? '') === $record['id']) {
                $data['downloads'][$i] = array_merge($existing, $record);
                return $data;
            }
        }
        throw new RuntimeException('Download record was not found.');
    }, !$isNew);
    return $record;
}

function dv_download_delete(string $id, string $mode): void
{
    dv_storage_update('downloads', static function (array $data) use ($id, $mode): array {
        $data['downloads'] ??= [];
        foreach ($data['downloads'] as $i => $download) {
            if (($download['id'] ?? '') !== $id) {
                continue;
            }
            if ($mode === 'archive') {
                $data['downloads'][$i]['status'] = 'archived';
                $data['downloads'][$i]['updated_at'] = dv_now();
                return $data;
            }
            if ($mode === 'delete_file') {
                @unlink(dv_private_file_path((string) $download['stored_filename']));
            }
            array_splice($data['downloads'], $i, 1);
            return $data;
        }
        throw new RuntimeException('Download record was not found.');
    }, true);
}

function dv_download_duplicate(string $id): array
{
    $source = dv_download_find($id);
    if (!$source) {
        throw new RuntimeException('Download record was not found.');
    }
    $oldPath = dv_private_file_path((string) $source['stored_filename']);
    if (!is_file($oldPath)) {
        throw new RuntimeException('The stored file could not be duplicated because it is missing.');
    }
    $ext = dv_extension((string) $source['stored_filename']);
    $stored = 'f_' . gmdate('YmdHis') . '_' . bin2hex(random_bytes(8)) . '.' . $ext;
    if (!copy($oldPath, dv_private_file_path($stored))) {
        throw new RuntimeException('The stored file could not be duplicated.');
    }
    $copy = $source;
    unset($copy['id'], $copy['created_at'], $copy['updated_at']);
    $copy['title'] = (string) $source['title'] . ' Copy';
    $copy['slug'] = dv_random_slug();
    $copy['stored_filename'] = $stored;
    $copy['download_count'] = 0;
    $copy['unique_download_count'] = 0;
    $copy['last_downloaded_at'] = null;
    return dv_download_save($copy, true);
}

function dv_download_reset_count(string $id): void
{
    dv_storage_update('downloads', static function (array $data) use ($id): array {
        foreach ($data['downloads'] as $i => $download) {
            if (($download['id'] ?? '') === $id) {
                $data['downloads'][$i]['download_count'] = 0;
                $data['downloads'][$i]['unique_download_count'] = 0;
                $data['downloads'][$i]['last_downloaded_at'] = null;
                $data['downloads'][$i]['updated_at'] = dv_now();
                return $data;
            }
        }
        throw new RuntimeException('Download record was not found.');
    }, true);
}

function dv_download_toggle(string $id): void
{
    dv_storage_update('downloads', static function (array $data) use ($id): array {
        foreach ($data['downloads'] as $i => $download) {
            if (($download['id'] ?? '') === $id) {
                $data['downloads'][$i]['status'] = ($download['status'] ?? 'active') === 'disabled' ? 'active' : 'disabled';
                $data['downloads'][$i]['updated_at'] = dv_now();
                return $data;
            }
        }
        throw new RuntimeException('Download record was not found.');
    }, true);
}

function dv_download_authorized(array $download): bool
{
    $auth = $_SESSION['download_auth'][$download['id']] ?? null;
    return is_array($auth) && (int) ($auth['expires'] ?? 0) > time();
}

function dv_download_grant(array $download): void
{
    $_SESSION['download_auth'][$download['id']] = ['expires' => time() + 600];
}

function dv_download_reserve_start(string $id): array
{
    $reserved = null;
    dv_storage_update('downloads', static function (array $data) use ($id, &$reserved): array {
        foreach ($data['downloads'] as $i => $download) {
            if (($download['id'] ?? '') !== $id) {
                continue;
            }
            $status = dv_download_status($download);
            if ($status['code'] !== 'active') {
                throw new RuntimeException($status['label']);
            }
            $download['download_count'] = (int) ($download['download_count'] ?? 0) + 1;
            $download['last_downloaded_at'] = dv_now();
            $download['updated_at'] = dv_now();
            $data['downloads'][$i] = $download;
            $reserved = $download;
            return $data;
        }
        throw new RuntimeException('Download record was not found.');
    });
    if (!$reserved) {
        throw new RuntimeException('Download could not be reserved.');
    }
    try {
        dv_stats_increment($id);
    } catch (Throwable $e) {
        dv_log_error('Daily stats write failed: ' . $e->getMessage());
    }
    dv_history_add($id, 'success', dv_config('estimate_unique_downloads') ? dv_request_id('unique-' . $id) : null);
    return $reserved;
}

function dv_download_from_form(?array $existing = null): array
{
    $title = trim((string) dv_post('title'));
    $slugInput = trim((string) dv_post('slug'));
    if ($slugInput === '' && $title !== '') {
        $slugInput = $title;
    }
    [$slug, $slugErrors] = dv_validate_slug($slugInput, $existing['id'] ?? null);
    $errors = $slugErrors;
    if ($title === '') {
        $errors[] = 'Title is required.';
    }
    $max = trim((string) dv_post('maximum_downloads'));
    $maximum = $max === '' ? null : max(1, (int) $max);
    $password = (string) dv_post('password');
    $record = [
        'title' => $title,
        'slug' => $slug,
        'description' => trim((string) dv_post('description')),
        'custom_filename' => trim((string) dv_post('custom_filename')),
        'status' => in_array((string) dv_post('status'), ['active', 'disabled', 'archived'], true) ? (string) dv_post('status') : 'active',
        'expires_at' => dv_input_to_utc((string) dv_post('expires_at')),
        'maximum_downloads' => $maximum,
        'landing_page_enabled' => dv_bool_from_post('landing_page_enabled'),
        'force_download' => dv_bool_from_post('force_download'),
        'show_file_size' => dv_bool_from_post('show_file_size'),
        'show_expiration' => dv_bool_from_post('show_expiration'),
        'show_remaining' => dv_bool_from_post('show_remaining'),
        'admin_notes' => trim((string) dv_post('admin_notes')),
    ];
    if ($existing) {
        $record += $existing;
    }
    if ($password !== '') {
        $record['password_hash'] = password_hash($password, PASSWORD_DEFAULT);
    } elseif (dv_bool_from_post('remove_password')) {
        $record['password_hash'] = null;
    } elseif ($existing) {
        $record['password_hash'] = $existing['password_hash'] ?? null;
    } else {
        $record['password_hash'] = null;
    }
    if ($errors !== []) {
        throw new InvalidArgumentException(implode(' ', $errors));
    }
    return $record;
}
