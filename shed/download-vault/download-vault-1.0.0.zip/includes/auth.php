<?php
declare(strict_types=1);

function dv_admin_logged_in(): bool
{
    $loggedIn = !empty($_SESSION['admin_authenticated']);
    if (!$loggedIn) {
        return false;
    }
    $timeout = max(1, (int) dv_config('session_timeout_minutes', 30)) * 60;
    $last = (int) ($_SESSION['admin_last_seen'] ?? 0);
    if ($last > 0 && time() - $last > $timeout) {
        dv_admin_logout();
        return false;
    }
    $_SESSION['admin_last_seen'] = time();
    return true;
}

function dv_admin_login(string $password): bool
{
    $identifier = dv_request_id('admin-login');
    if (!dv_rate_limit_check('admin-login', $identifier, 5, 900)) {
        return false;
    }
    $hash = (string) dv_config('admin_password_hash', '');
    if ($hash === '' || $hash === 'REPLACE_WITH_PASSWORD_HASH') {
        return false;
    }
    if (!password_verify($password, $hash)) {
        return false;
    }
    session_regenerate_id(true);
    $_SESSION['admin_authenticated'] = true;
    $_SESSION['admin_last_seen'] = time();
    return true;
}

function dv_admin_logout(): void
{
    unset($_SESSION['admin_authenticated'], $_SESSION['admin_last_seen']);
}

function dv_require_admin(): void
{
    if (!dv_admin_logged_in()) {
        dv_redirect(dv_url('admin/login.php'));
    }
}
