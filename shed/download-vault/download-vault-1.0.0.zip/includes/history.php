<?php
declare(strict_types=1);

function dv_history_add(string $downloadId, string $result, ?string $visitorHash = null): void
{
    if ($result !== 'success' && !dv_config('store_blocked_history', true)) {
        return;
    }
    $event = [
        'download_id' => $downloadId,
        'timestamp' => dv_now(),
        'result' => $result,
        'referrer_domain' => dv_referrer_domain(),
        'device_type' => dv_device_type(),
        'visitor_hash' => $visitorHash,
    ];
    try {
        dv_storage_update('history', static function (array $data) use ($event): array {
            $data['events'] ??= [];
            $data['events'][] = $event;
            $limit = max(100, (int) dv_config('history_limit', 1000));
            if (count($data['events']) > $limit) {
                $data['events'] = array_slice($data['events'], -$limit);
            }
            return $data;
        });
    } catch (Throwable $e) {
        dv_log_error('History write failed: ' . $e->getMessage());
    }
}

function dv_history_recent(?string $downloadId = null, int $limit = 25): array
{
    $data = dv_storage_read('history');
    $events = array_reverse((array) ($data['events'] ?? []));
    if ($downloadId !== null) {
        $events = array_values(array_filter($events, static fn ($event) => ($event['download_id'] ?? '') === $downloadId));
    }
    return array_slice($events, 0, $limit);
}
