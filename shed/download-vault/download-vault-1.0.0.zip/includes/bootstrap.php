<?php
declare(strict_types=1);

define('DV_ROOT', dirname(__DIR__));
define('DV_VERSION', trim((string) @file_get_contents(DV_ROOT . '/VERSION')) ?: '1.0.0');

require_once DV_ROOT . '/includes/helpers.php';
require_once DV_ROOT . '/includes/security.php';
require_once DV_ROOT . '/includes/storage.php';
require_once DV_ROOT . '/includes/csrf.php';
require_once DV_ROOT . '/includes/rate-limit.php';
require_once DV_ROOT . '/includes/auth.php';
require_once DV_ROOT . '/includes/validation.php';
require_once DV_ROOT . '/includes/backup.php';
require_once DV_ROOT . '/includes/history.php';
require_once DV_ROOT . '/includes/statistics.php';
require_once DV_ROOT . '/includes/files.php';
require_once DV_ROOT . '/includes/downloads.php';
require_once DV_ROOT . '/includes/response.php';

set_error_handler(static function (int $severity, string $message, string $file, int $line): bool {
    if (!(error_reporting() & $severity)) {
        return false;
    }
    throw new ErrorException($message, 0, $severity, $file, $line);
});

set_exception_handler(static function (Throwable $exception): void {
    dv_log_error('Unhandled exception: ' . $exception->getMessage(), ['file' => $exception->getFile(), 'line' => $exception->getLine()]);
    if (PHP_SAPI === 'cli') {
        fwrite(STDERR, $exception->getMessage() . PHP_EOL);
        exit(1);
    }
    if (!headers_sent()) {
        http_response_code(500);
        dv_security_headers('public');
    }
    $message = dv_config('debug') ? $exception->getMessage() : 'Something went wrong while handling this request.';
    include DV_ROOT . '/templates/public-error.php';
    exit;
});

$config = require DV_ROOT . '/config.php';
dv_configure($config);
dv_validate_config();
dv_start_session();
