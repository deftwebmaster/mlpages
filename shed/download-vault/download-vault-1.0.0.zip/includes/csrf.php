<?php
declare(strict_types=1);

function dv_csrf_token(): string
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return (string) $_SESSION['csrf_token'];
}

function dv_csrf_field(): string
{
    return '<input type="hidden" name="csrf_token" value="' . dv_e(dv_csrf_token()) . '">';
}

function dv_verify_csrf(): void
{
    $posted = (string) ($_POST['csrf_token'] ?? '');
    $token = (string) ($_SESSION['csrf_token'] ?? '');
    if ($posted === '' || $token === '' || !hash_equals($token, $posted)) {
        http_response_code(403);
        throw new RuntimeException('Security token was not accepted. Please reload the page and try again.');
    }
}
