// Download Vault renders accessible chart summaries server-side in version 1.
