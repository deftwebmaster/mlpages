(function () {
    function randomSlug() {
        var alphabet = 'abcdefghjkmnpqrstuvwxyz23456789';
        var slug = '';
        for (var i = 0; i < 8; i += 1) {
            slug += alphabet[Math.floor(Math.random() * alphabet.length)];
        }
        return slug;
    }

    document.addEventListener('click', function (event) {
        var randomButton = event.target.closest('[data-random-slug]');
        if (randomButton) {
            var input = document.querySelector('#slug');
            if (input) {
                input.value = randomSlug();
                input.focus();
            }
        }

        var copyButton = event.target.closest('[data-copy]');
        if (copyButton) {
            var text = copyButton.getAttribute('data-copy');
            navigator.clipboard.writeText(text).then(function () {
                var original = copyButton.textContent;
                copyButton.textContent = 'Copied';
                window.setTimeout(function () { copyButton.textContent = original; }, 1200);
            });
        }
    });

    document.addEventListener('submit', function (event) {
        var form = event.target;
        var message = form.getAttribute('data-confirm');
        if (message && !window.confirm(message)) {
            event.preventDefault();
        }
    });

    document.addEventListener('input', function (event) {
        if (!event.target.matches('[data-table-search]')) {
            return;
        }
        var query = event.target.value.toLowerCase();
        var table = document.querySelector('[data-searchable]');
        if (!table) {
            return;
        }
        table.querySelectorAll('tbody tr').forEach(function (row) {
            row.hidden = query !== '' && row.textContent.toLowerCase().indexOf(query) === -1;
        });
    });
}());
