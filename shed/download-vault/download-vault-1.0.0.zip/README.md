# Download Vault

Download Vault is a self-hosted PHP 8.2 application for delivering protected files through controlled, trackable download links. It uses JSON flat-file storage, PHP sessions, and local assets only. It does not require SQL, Composer, Node.js, a framework, cloud storage, or recipient accounts.

## Features

- Single administrator login
- Protected file uploads with randomized internal filenames
- Import directory for large FTP/file-manager uploads
- Clean URLs such as `/d/client-brand-assets`
- Query-string fallback URLs such as `download.php?slug=client-brand-assets`
- Landing-page or direct-download behavior
- Optional download passwords using `password_hash()` and `password_verify()`
- Expiration dates and maximum download limits
- Locked counter increments before file streaming
- Daily aggregate statistics and recent history
- Manual backups and backup restore
- Responsive admin dashboard
- Apache `.htaccess` protections for public installs

## Requirements

- PHP 8.2 or newer
- Apache with `mod_rewrite` recommended
- Writable private storage, file, import, backup, lock, and log directories
- PHP `fileinfo` extension for MIME detection

## Installation

1. Upload the Download Vault folder to your hosting account.
2. Move `storage`, `private-files`, and `import` outside the public web root when possible.
3. Copy `config.example.php` to `config.php` if needed.
4. Edit `config.php` and set `base_url`, `timezone`, paths, `privacy_salt`, and `admin_password_hash`.
5. Generate the password hash at `/tools/generate-password.php` or with:

   ```bash
   php tools/generate-password.php 'your admin password'
   ```

6. Paste the hash into `config.php`.
7. Delete `tools/generate-password.php`.
8. Open `/admin/` and log in.

## Private Storage

Best layout:

```text
/home/account/private/download-vault/storage
/home/account/private/download-vault/files
/home/account/private/download-vault/import
/home/account/public_html/download-vault
```

If private directories must stay inside the public project folder, keep the bundled `.htaccess` files in place and use the Settings page to check permissions. Files are always streamed through PHP and never linked directly.

## Apache URLs

The bundled `.htaccess` enables:

```text
/d/my-download
/admin/
```

If rewrites are unavailable, set `routing_mode` to `fallback` in `config.php` and use:

```text
download.php?slug=my-download
admin/index.php?page=downloads
```

## Nginx Example

```nginx
location /download-vault/ {
    try_files $uri $uri/ /download-vault/index.php?$query_string;
}

location ~ ^/download-vault/d/([A-Za-z0-9_-]+)/?$ {
    rewrite ^/download-vault/d/([A-Za-z0-9_-]+)/?$ /download-vault/download.php?slug=$1 last;
}

location ~ ^/download-vault/(storage|private-files|import)/ {
    deny all;
}
```

## Creating a Download

Log in, choose Add Download, upload a file or select an import file, enter a title, adjust the slug, and choose access rules. A download count represents an authorized file transfer started by the server. Interrupted transfers may still count because PHP cannot reliably know whether every recipient completed the transfer.

## Large Files

Upload large files into the configured `import_path` by FTP or your hosting file manager. The Add Download form can register only files found inside that import directory. Download Vault never accepts arbitrary server paths from a form.

## Backups and Restore

Backups are written to `storage/backups`. Download Vault creates backups before destructive changes such as delete, reset, and restore. Use the Backups page for manual backups and restore. Restore validates JSON before replacing current data and creates a backup of the current records first.

## Upgrading

Back up the full project and private storage. Replace application files, keep your `config.php`, then open the admin dashboard and verify diagnostics. Data files include `schema_version` for future migrations.

## Troubleshooting

- Login fails: confirm `admin_password_hash` is set and the helper was used with the same password.
- Upload fails: compare `max_upload_bytes`, `upload_max_filesize`, and `post_max_size`.
- Downloads return unavailable: check the file exists in `files_path` and the record status is active.
- Clean URLs fail: confirm Apache rewrite support or switch `routing_mode` to `fallback`.

## Known Limitations

- HTTP range requests, X-Sendfile, X-Accel-Redirect, email delivery, QR codes, and multi-file bundles are planned for later releases.
- PHP streaming is practical for small-business traffic, but very large or extremely popular downloads may be better served with web-server acceleration in a future version.

## Uninstallation

Delete the public project folder and the private storage directories configured in `config.php`.

## License

MIT
