# Security Policy

## Supported Versions

Version 1.x is the supported release line.

## Reporting Issues

Report vulnerabilities through the website or contact address where you received Download Vault. Do not post exploit details publicly until a fixed release is available.

## Deployment Recommendations

- Put `storage_path`, `files_path`, and `import_path` outside the public web root whenever possible.
- Delete `tools/generate-password.php` after creating your administrator password hash.
- Change `privacy_salt` before launch.
- Use HTTPS for admin access and download links.
- Keep PHP updated. Download Vault requires PHP 8.2 or newer.
- Secret URLs are convenient, but they are not a substitute for passwords on sensitive files.

Download Vault does not store plaintext passwords, raw session IDs, full referrer URLs, or raw IP addresses by default. Estimated unique download tracking is disabled by default and uses salted hashes.
