<?php
declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/includes/bootstrap.php';
dv_require_admin();

$type = (string) dv_get('type', 'downloads');
$filename = 'download-vault-' . $type . '-' . gmdate('Ymd-His');

if ($type === 'history-csv') {
    header('Content-Type: text/csv; charset=UTF-8');
    header('Content-Disposition: attachment; filename="' . $filename . '.csv"');
    $out = fopen('php://output', 'wb');
    fputcsv($out, ['download_id', 'timestamp', 'result', 'referrer_domain', 'device_type']);
    foreach (dv_history_recent(null, (int) dv_config('history_limit', 1000)) as $event) {
        fputcsv($out, [
            $event['download_id'] ?? '',
            $event['timestamp'] ?? '',
            $event['result'] ?? '',
            $event['referrer_domain'] ?? '',
            $event['device_type'] ?? '',
        ]);
    }
    exit;
}

$store = match ($type) {
    'history' => 'history',
    'daily-stats' => 'daily-stats',
    default => 'downloads',
};
$data = dv_storage_read($store);
header('Content-Type: application/json; charset=UTF-8');
header('Content-Disposition: attachment; filename="' . $filename . '.json"');
echo json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
