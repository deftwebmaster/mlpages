<?php
declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/includes/bootstrap.php';
dv_verify_csrf();
dv_admin_logout();
dv_redirect(dv_url('admin/login.php'));
