<?php
declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/includes/bootstrap.php';
dv_require_admin();
dv_verify_csrf();

try {
    dv_download_delete((string) dv_post('id'), (string) dv_post('delete_mode', 'archive'));
    dv_flash('Download removed.');
} catch (Throwable $e) {
    dv_flash($e->getMessage(), 'danger');
}
dv_redirect(dv_url('admin/?page=downloads'));
