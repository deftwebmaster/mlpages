<?php
declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/includes/bootstrap.php';
dv_require_admin();
dv_verify_csrf();

try {
    $copy = dv_download_duplicate((string) dv_post('id'));
    dv_flash('Download duplicated with a new random link.');
    dv_redirect(dv_url('admin/?page=edit&id=' . rawurlencode((string) $copy['id'])));
} catch (Throwable $e) {
    dv_flash($e->getMessage(), 'danger');
    dv_redirect(dv_url('admin/?page=downloads'));
}
