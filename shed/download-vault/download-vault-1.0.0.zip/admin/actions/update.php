<?php
declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/includes/bootstrap.php';
dv_require_admin();
dv_verify_csrf();

$id = (string) dv_post('id');
try {
    $existing = dv_download_find($id);
    if (!$existing) {
        throw new RuntimeException('Download record was not found.');
    }
    $record = dv_download_from_form($existing);
    $record['id'] = $id;
    dv_download_save($record, false);
    dv_flash('Download updated.');
    dv_redirect(dv_url('admin/?page=edit&id=' . rawurlencode($id)));
} catch (Throwable $e) {
    dv_flash($e->getMessage(), 'danger');
    dv_redirect(dv_url('admin/?page=edit&id=' . rawurlencode($id)));
}
