<?php
declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/includes/bootstrap.php';
dv_require_admin();
dv_verify_csrf();

$action = (string) dv_post('backup_action', 'create');
try {
    if ($action === 'restore') {
        dv_restore_backup((string) dv_post('backup_name'));
        dv_flash('Backup restored.');
    } else {
        dv_create_backup('downloads');
        dv_flash('Manual backup created.');
    }
} catch (Throwable $e) {
    dv_flash($e->getMessage(), 'danger');
}
dv_redirect(dv_url('admin/?page=backups'));
