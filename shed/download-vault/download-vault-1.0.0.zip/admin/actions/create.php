<?php
declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/includes/bootstrap.php';
dv_require_admin();
dv_verify_csrf();

try {
    $record = dv_download_from_form();
    $source = (string) dv_post('file_source', 'upload');
    if ($source === 'import') {
        $file = dv_store_import_file((string) dv_post('import_file'));
    } else {
        $file = dv_store_uploaded_file($_FILES['download_file'] ?? []);
    }
    $record += $file;
    dv_download_save($record, true);
    dv_flash('Download created.');
    dv_redirect(dv_url('admin/?page=downloads'));
} catch (Throwable $e) {
    dv_flash($e->getMessage(), 'danger');
    dv_redirect(dv_url('admin/?page=create'));
}
