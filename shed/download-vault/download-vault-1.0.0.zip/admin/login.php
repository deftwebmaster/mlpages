<?php
declare(strict_types=1);

require_once dirname(__DIR__) . '/includes/bootstrap.php';

if (dv_admin_logged_in()) {
    dv_redirect(dv_url('admin/'));
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        dv_verify_csrf();
        if (dv_admin_login((string) dv_post('password'))) {
            dv_redirect(dv_url('admin/'));
        }
        $error = 'The login information was not accepted.';
    } catch (Throwable) {
        $error = 'The login information was not accepted.';
    }
}

dv_security_headers('admin');
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Admin Login - <?php echo dv_e(dv_config('app_name')); ?></title>
    <link rel="stylesheet" href="<?php echo dv_e(dv_url('assets/css/admin.css')); ?>">
</head>
<body class="login-screen">
    <main class="login-panel">
        <p class="eyebrow"><?php echo dv_e(dv_config('app_name')); ?></p>
        <h1>Admin Login</h1>
        <?php if ($error): ?><div class="notice danger"><?php echo dv_e($error); ?></div><?php endif; ?>
        <?php if (dv_config('admin_password_hash') === 'REPLACE_WITH_PASSWORD_HASH'): ?>
            <div class="notice warning">Set your administrator password hash in config.php before logging in.</div>
        <?php endif; ?>
        <form method="post">
            <?php echo dv_csrf_field(); ?>
            <label for="password">Password</label>
            <input id="password" name="password" type="password" required autocomplete="current-password">
            <button class="button primary" type="submit">Log In</button>
        </form>
    </main>
</body>
</html>
