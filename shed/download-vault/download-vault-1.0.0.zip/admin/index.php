<?php
declare(strict_types=1);

require_once dirname(__DIR__) . '/includes/bootstrap.php';
dv_require_admin();

$page = (string) dv_get('page', 'dashboard');
$allowed = ['dashboard', 'downloads', 'create', 'edit', 'stats', 'history', 'backups', 'settings'];
if (!in_array($page, $allowed, true)) {
    $page = 'dashboard';
}

if ($page === 'dashboard') {
    dv_render_admin('Dashboard', 'admin-dashboard.php', [
        'summary' => dv_dashboard_summary(),
        'recent' => dv_history_recent(null, 8),
        'downloads' => dv_download_all(),
    ]);
} elseif ($page === 'downloads') {
    dv_render_admin('Downloads', 'admin-downloads.php', ['downloads' => dv_download_all()]);
} elseif ($page === 'create') {
    dv_render_admin('Add Download', 'admin-form.php', ['download' => null, 'importFiles' => dv_import_files()]);
} elseif ($page === 'edit') {
    $download = dv_download_find((string) dv_get('id'));
    if (!$download) {
        dv_flash('Download record was not found.', 'danger');
        dv_redirect(dv_url('admin/?page=downloads'));
    }
    dv_render_admin('Edit Download', 'admin-form.php', ['download' => $download, 'importFiles' => []]);
} elseif ($page === 'stats') {
    $download = dv_download_find((string) dv_get('id'));
    if (!$download) {
        dv_flash('Download record was not found.', 'danger');
        dv_redirect(dv_url('admin/?page=downloads'));
    }
    dv_render_admin('Statistics', 'admin-stats.php', [
        'download' => $download,
        'stats' => dv_stats_for_download((string) $download['id']),
        'events' => dv_history_recent((string) $download['id'], 40),
    ]);
} elseif ($page === 'history') {
    dv_render_admin('History', 'admin-history.php', [
        'events' => dv_history_recent(null, 100),
        'downloads' => dv_download_all(),
    ]);
} elseif ($page === 'backups') {
    dv_render_admin('Backups', 'admin-backups.php', ['backups' => dv_list_backups()]);
} else {
    dv_render_admin('Settings', 'admin-settings.php', ['downloads' => dv_download_all()]);
}
