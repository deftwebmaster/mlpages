# Changelog

## 1.0.0 - 2026-07-28

- Initial Download Vault release.
- Added single-admin authentication, protected uploads, import-directory registration, clean download links, landing/direct delivery, password protection, expiration, maximum download limits, daily stats, history, backups, and documentation.
