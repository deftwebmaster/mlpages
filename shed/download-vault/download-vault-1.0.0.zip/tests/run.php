<?php
declare(strict_types=1);

require_once dirname(__DIR__) . '/includes/bootstrap.php';

$tmp = sys_get_temp_dir() . '/download-vault-tests-' . bin2hex(random_bytes(4));
mkdir($tmp . '/storage/backups', 0755, true);
mkdir($tmp . '/storage/locks', 0755, true);
mkdir($tmp . '/storage/logs', 0755, true);
mkdir($tmp . '/files', 0755, true);
mkdir($tmp . '/import', 0755, true);

dv_configure(array_replace(dv_config(), [
    'storage_path' => $tmp . '/storage',
    'files_path' => $tmp . '/files',
    'import_path' => $tmp . '/import',
    'admin_password_hash' => password_hash('secret', PASSWORD_DEFAULT),
    'privacy_salt' => 'test-salt',
]));

function test_assert(bool $condition, string $message): void
{
    if (!$condition) {
        throw new RuntimeException('Test failed: ' . $message);
    }
    echo "ok - " . $message . PHP_EOL;
}

$store = dv_storage_update('downloads', static function (array $data): array {
    $data['downloads'] = [];
    return $data;
});
test_assert(($store['schema_version'] ?? null) === 1, 'storage writes schema version');

$sample = $tmp . '/files/f_sample.txt';
file_put_contents($sample, 'hello');
$record = dv_download_save([
    'slug' => 'sample-file',
    'title' => 'Sample File',
    'stored_filename' => 'f_sample.txt',
    'original_filename' => 'sample.txt',
    'file_size' => 5,
    'mime_type' => 'text/plain',
    'file_hash' => hash_file('sha256', $sample),
    'maximum_downloads' => 1,
    'landing_page_enabled' => true,
    'force_download' => true,
], true);
test_assert(dv_download_find_by_slug('sample-file') !== null, 'download can be found by slug');

$reserved = dv_download_reserve_start((string) $record['id']);
test_assert((int) $reserved['download_count'] === 1, 'first download start increments counter');

$blocked = false;
try {
    dv_download_reserve_start((string) $record['id']);
} catch (Throwable) {
    $blocked = true;
}
test_assert($blocked, 'download limit blocks second reservation');

dv_create_backup('downloads');
test_assert(count(dv_list_backups('downloads')) >= 1, 'backup creation works');

[$slug, $errors] = dv_validate_slug('../admin');
test_assert($errors !== [], 'reserved or unsafe slug is rejected');
test_assert(dv_validate_filename('shell.php.jpg') !== [], 'double extension executable upload is rejected');

$history = dv_history_recent((string) $record['id']);
test_assert($history !== [] && ($history[0]['result'] ?? '') === 'success', 'successful download writes history');

echo "All tests passed." . PHP_EOL;
