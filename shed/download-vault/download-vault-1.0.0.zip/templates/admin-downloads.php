<?php
declare(strict_types=1);
?>
<section class="panel">
    <div class="panel-head">
        <h2>Download Links</h2>
        <input class="search" type="search" data-table-search placeholder="Search downloads">
    </div>
    <div class="table-wrap">
        <table data-searchable>
            <thead>
            <tr>
                <th>Title</th><th>Slug</th><th>Size</th><th>Status</th><th>Downloads</th><th>Expiration</th><th>Last Downloaded</th><th>Actions</th>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($downloads as $download): $status = dv_download_status($download); $url = dv_public_download_url((string) $download['slug']); ?>
                <tr>
                    <td>
                        <strong><?php echo dv_e($download['title']); ?></strong>
                        <small><?php echo dv_e($download['original_filename']); ?></small>
                    </td>
                    <td><code><?php echo dv_e($download['slug']); ?></code></td>
                    <td><?php echo dv_e(dv_format_bytes((int) $download['file_size'])); ?></td>
                    <td><span class="badge <?php echo dv_e($status['code']); ?>"><?php echo dv_e($status['label']); ?></span></td>
                    <td><?php echo (int) $download['download_count']; ?><?php echo $download['maximum_downloads'] ? ' / ' . (int) $download['maximum_downloads'] : ''; ?></td>
                    <td><?php echo dv_e(dv_local_time($download['expires_at'] ?? null, 'None')); ?></td>
                    <td><?php echo dv_e(dv_local_time($download['last_downloaded_at'] ?? null)); ?></td>
                    <td class="actions">
                        <button class="icon-button" data-copy="<?php echo dv_e($url); ?>" title="Copy public URL">Copy</button>
                        <a class="icon-button" href="<?php echo dv_e($url); ?>" target="_blank" rel="noopener">Open</a>
                        <a class="icon-button" href="<?php echo dv_e(dv_url('admin/?page=stats&id=' . rawurlencode((string) $download['id']))); ?>">Stats</a>
                        <a class="icon-button" href="<?php echo dv_e(dv_url('admin/?page=edit&id=' . rawurlencode((string) $download['id']))); ?>">Edit</a>
                        <form method="post" action="<?php echo dv_e(dv_url('admin/actions/toggle.php')); ?>"><?php echo dv_csrf_field(); ?><input type="hidden" name="id" value="<?php echo dv_e($download['id']); ?>"><button class="icon-button" type="submit"><?php echo ($download['status'] ?? 'active') === 'disabled' ? 'Enable' : 'Disable'; ?></button></form>
                        <form method="post" action="<?php echo dv_e(dv_url('admin/actions/duplicate.php')); ?>"><?php echo dv_csrf_field(); ?><input type="hidden" name="id" value="<?php echo dv_e($download['id']); ?>"><button class="icon-button" type="submit">Duplicate</button></form>
                        <form method="post" action="<?php echo dv_e(dv_url('admin/actions/reset.php')); ?>" data-confirm="Reset the download counter for <?php echo dv_e($download['title']); ?>?"><?php echo dv_csrf_field(); ?><input type="hidden" name="id" value="<?php echo dv_e($download['id']); ?>"><button class="icon-button" type="submit">Reset</button></form>
                    </td>
                </tr>
            <?php endforeach; ?>
            <?php if ($downloads === []): ?><tr><td colspan="8" class="muted">No downloads yet. Add one to create your first protected link.</td></tr><?php endif; ?>
            </tbody>
        </table>
    </div>
</section>
