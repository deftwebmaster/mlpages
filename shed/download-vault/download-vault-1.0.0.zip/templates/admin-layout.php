<?php
declare(strict_types=1);
$flash = dv_flash();
$currentPage = (string) dv_get('page', 'dashboard');
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo dv_e($title); ?> - <?php echo dv_e(dv_config('app_name')); ?></title>
    <link rel="stylesheet" href="<?php echo dv_e(dv_url('assets/css/admin.css')); ?>">
    <script defer src="<?php echo dv_e(dv_url('assets/js/admin.js')); ?>"></script>
</head>
<body>
<div class="app-shell">
    <aside class="sidebar">
        <a class="brand" href="<?php echo dv_e(dv_url('admin/')); ?>">
            <span class="brand-mark">DV</span>
            <span>
                <strong><?php echo dv_e(dv_config('app_name')); ?></strong>
                <small><?php echo dv_e(DV_VERSION); ?></small>
            </span>
        </a>
        <nav>
            <?php foreach ([
                'dashboard' => 'Dashboard',
                'downloads' => 'Downloads',
                'create' => 'Add Download',
                'history' => 'History',
                'backups' => 'Backups',
                'settings' => 'Settings',
            ] as $key => $label): ?>
                <a class="<?php echo $currentPage === $key ? 'active' : ''; ?>" href="<?php echo dv_e(dv_url('admin/?page=' . $key)); ?>"><?php echo dv_e($label); ?></a>
            <?php endforeach; ?>
        </nav>
        <form method="post" action="<?php echo dv_e(dv_url('admin/actions/logout.php')); ?>">
            <?php echo dv_csrf_field(); ?>
            <button class="button ghost full" type="submit">Log Out</button>
        </form>
    </aside>
    <main class="main">
        <header class="topbar">
            <div>
                <h1><?php echo dv_e($title); ?></h1>
                <p><?php echo dv_e(dv_config('tagline')); ?></p>
            </div>
            <a class="button primary" href="<?php echo dv_e(dv_url('admin/?page=create')); ?>">Add Download</a>
        </header>
        <?php if ($flash): ?><div class="notice <?php echo dv_e($flash['type']); ?>"><?php echo dv_e($flash['message']); ?></div><?php endif; ?>
        <?php if (is_file(DV_ROOT . '/tools/generate-password.php')): ?>
            <div class="notice warning">Password helper is still present at tools/generate-password.php. Delete it after setup.</div>
        <?php endif; ?>
        <?php include DV_ROOT . '/templates/' . $contentView; ?>
    </main>
</div>
</body>
</html>
