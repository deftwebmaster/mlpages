<?php
declare(strict_types=1);
$downloadsById = [];
foreach ($downloads as $item) {
    $downloadsById[$item['id']] = $item;
}
?>
<section class="metric-grid">
    <div class="metric"><span>Active links</span><strong><?php echo (int) $summary['active']; ?></strong></div>
    <div class="metric"><span>Download starts</span><strong><?php echo (int) $summary['total_downloads']; ?></strong></div>
    <div class="metric"><span>Today</span><strong><?php echo (int) $summary['today']; ?></strong></div>
    <div class="metric"><span>Last 7 days</span><strong><?php echo (int) $summary['last7']; ?></strong></div>
    <div class="metric"><span>Expired</span><strong><?php echo (int) $summary['expired']; ?></strong></div>
    <div class="metric"><span>Near limit</span><strong><?php echo (int) $summary['near_limit']; ?></strong></div>
</section>

<section class="panel">
    <div class="panel-head">
        <h2>Attention</h2>
    </div>
    <div class="attention-list">
        <?php
        $warnings = [];
        foreach (['storage_path' => 'Storage', 'files_path' => 'Private files', 'import_path' => 'Import'] as $key => $label) {
            if (!is_writable((string) dv_config($key))) {
                $warnings[] = $label . ' directory is not writable.';
            }
        }
        if (dv_config('admin_password_hash') === 'REPLACE_WITH_PASSWORD_HASH') {
            $warnings[] = 'Administrator password hash has not been configured.';
        }
        if (dv_config('privacy_salt') === 'change-this-to-a-long-random-secret-before-launch') {
            $warnings[] = 'Privacy salt should be changed before launch.';
        }
        foreach ($downloads as $download) {
            $status = dv_download_status($download);
            if ($status['code'] !== 'active') {
                $warnings[] = $download['title'] . ': ' . $status['label'];
            }
        }
        ?>
        <?php if ($warnings === []): ?>
            <p class="muted">No immediate issues found.</p>
        <?php else: ?>
            <?php foreach (array_slice($warnings, 0, 8) as $warning): ?><div class="warning-row"><?php echo dv_e($warning); ?></div><?php endforeach; ?>
        <?php endif; ?>
    </div>
</section>

<section class="panel">
    <div class="panel-head">
        <h2>Recent Activity</h2>
        <a href="<?php echo dv_e(dv_url('admin/?page=history')); ?>">View all</a>
    </div>
    <div class="table-wrap">
        <table>
            <thead><tr><th>File</th><th>Result</th><th>Date</th><th>Referrer</th><th>Device</th></tr></thead>
            <tbody>
            <?php foreach ($recent as $event): $item = $downloadsById[$event['download_id'] ?? ''] ?? null; ?>
                <tr>
                    <td><?php echo dv_e($item['title'] ?? 'Unknown download'); ?></td>
                    <td><span class="badge"><?php echo dv_e(str_replace('_', ' ', (string) $event['result'])); ?></span></td>
                    <td><?php echo dv_e(dv_local_time((string) $event['timestamp'])); ?></td>
                    <td><?php echo dv_e($event['referrer_domain'] ?? '-'); ?></td>
                    <td><?php echo dv_e($event['device_type'] ?? '-'); ?></td>
                </tr>
            <?php endforeach; ?>
            <?php if ($recent === []): ?><tr><td colspan="5" class="muted">No activity has been recorded yet.</td></tr><?php endif; ?>
            </tbody>
        </table>
    </div>
</section>
