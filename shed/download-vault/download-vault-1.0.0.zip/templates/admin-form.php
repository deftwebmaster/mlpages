<?php
declare(strict_types=1);
$isEdit = is_array($download);
$action = $isEdit ? dv_url('admin/actions/update.php') : dv_url('admin/actions/create.php');
$d = $download ?? [
    'title' => '', 'slug' => '', 'description' => '', 'custom_filename' => '', 'status' => 'active',
    'expires_at' => null, 'maximum_downloads' => null, 'landing_page_enabled' => true, 'force_download' => true,
    'show_file_size' => true, 'show_expiration' => true, 'show_remaining' => false, 'admin_notes' => '',
];
?>
<form class="panel form-grid" method="post" action="<?php echo dv_e($action); ?>" enctype="multipart/form-data">
    <?php echo dv_csrf_field(); ?>
    <?php if ($isEdit): ?><input type="hidden" name="id" value="<?php echo dv_e($d['id']); ?>"><?php endif; ?>

    <?php if (!$isEdit): ?>
    <fieldset>
        <legend>File</legend>
        <label><input type="radio" name="file_source" value="upload" checked> Upload new file</label>
        <input type="file" name="download_file">
        <label><input type="radio" name="file_source" value="import"> Import existing file</label>
        <select name="import_file">
            <option value="">Choose from import directory</option>
            <?php foreach ($importFiles as $file): ?>
                <option value="<?php echo dv_e($file['name']); ?>" <?php echo !$file['valid'] ? 'disabled' : ''; ?>><?php echo dv_e($file['name'] . ' - ' . dv_format_bytes((int) $file['size'])); ?></option>
            <?php endforeach; ?>
        </select>
    </fieldset>
    <?php else: ?>
    <section class="file-summary">
        <strong><?php echo dv_e($d['original_filename']); ?></strong>
        <span><?php echo dv_e(dv_format_bytes((int) $d['file_size'])); ?> - <?php echo dv_e($d['mime_type']); ?></span>
    </section>
    <?php endif; ?>

    <fieldset>
        <legend>Public Information</legend>
        <label for="title">Title</label>
        <input id="title" name="title" required value="<?php echo dv_e($d['title']); ?>">
        <label for="slug">Slug</label>
        <div class="inline-control">
            <input id="slug" name="slug" value="<?php echo dv_e($d['slug']); ?>" placeholder="client-brand-assets">
            <button class="button" type="button" data-random-slug>Random</button>
        </div>
        <label for="description">Description</label>
        <textarea id="description" name="description" rows="4"><?php echo dv_e($d['description']); ?></textarea>
        <label for="custom_filename">Custom download filename</label>
        <input id="custom_filename" name="custom_filename" value="<?php echo dv_e($d['custom_filename'] ?? ''); ?>">
    </fieldset>

    <fieldset>
        <legend>Access Controls</legend>
        <label for="password"><?php echo $isEdit ? 'New password' : 'Password'; ?></label>
        <input id="password" name="password" type="password" autocomplete="new-password">
        <?php if ($isEdit && !empty($d['password_hash'])): ?><label><input type="checkbox" name="remove_password" value="1"> Remove current password</label><?php endif; ?>
        <label for="expires_at">Expiration</label>
        <input id="expires_at" name="expires_at" type="datetime-local" value="<?php echo dv_e(dv_date_input($d['expires_at'] ?? null)); ?>">
        <label for="maximum_downloads">Maximum downloads</label>
        <input id="maximum_downloads" name="maximum_downloads" type="number" min="1" value="<?php echo dv_e($d['maximum_downloads'] ?? ''); ?>">
        <label for="status">Status</label>
        <select id="status" name="status">
            <?php foreach (['active' => 'Active', 'disabled' => 'Disabled', 'archived' => 'Archived'] as $value => $label): ?>
                <option value="<?php echo dv_e($value); ?>" <?php echo ($d['status'] ?? 'active') === $value ? 'selected' : ''; ?>><?php echo dv_e($label); ?></option>
            <?php endforeach; ?>
        </select>
    </fieldset>

    <fieldset>
        <legend>Delivery Behavior</legend>
        <label><input type="checkbox" name="landing_page_enabled" value="1" <?php echo !empty($d['landing_page_enabled']) ? 'checked' : ''; ?>> Show landing page</label>
        <label><input type="checkbox" name="force_download" value="1" <?php echo !empty($d['force_download']) ? 'checked' : ''; ?>> Force download</label>
        <label><input type="checkbox" name="show_file_size" value="1" <?php echo !empty($d['show_file_size']) ? 'checked' : ''; ?>> Show file size publicly</label>
        <label><input type="checkbox" name="show_expiration" value="1" <?php echo !empty($d['show_expiration']) ? 'checked' : ''; ?>> Show expiration publicly</label>
        <label><input type="checkbox" name="show_remaining" value="1" <?php echo !empty($d['show_remaining']) ? 'checked' : ''; ?>> Show remaining downloads publicly</label>
    </fieldset>

    <fieldset>
        <legend>Internal Notes</legend>
        <textarea name="admin_notes" rows="4"><?php echo dv_e($d['admin_notes'] ?? ''); ?></textarea>
    </fieldset>

    <div class="form-actions">
        <button class="button primary" type="submit"><?php echo $isEdit ? 'Save Changes' : 'Create Download'; ?></button>
        <a class="button" href="<?php echo dv_e(dv_url('admin/?page=downloads')); ?>">Cancel</a>
    </div>
</form>

<?php if ($isEdit): ?>
<section class="panel danger-zone">
    <h2>Delete or Archive</h2>
    <form method="post" action="<?php echo dv_e(dv_url('admin/actions/delete.php')); ?>" data-confirm="Delete or archive <?php echo dv_e($d['title']); ?>? This action creates a backup first.">
        <?php echo dv_csrf_field(); ?>
        <input type="hidden" name="id" value="<?php echo dv_e($d['id']); ?>">
        <label for="delete_mode">Action</label>
        <select id="delete_mode" name="delete_mode">
            <option value="archive">Archive instead of deleting</option>
            <option value="keep_file">Delete record but retain stored file</option>
            <option value="delete_file">Delete record and stored file</option>
        </select>
        <button class="button danger" type="submit">Apply Delete Action</button>
    </form>
</section>
<?php endif; ?>
