<?php
declare(strict_types=1);
$status = dv_download_status($download);
?>
<section class="metric-grid">
    <div class="metric"><span>Status</span><strong><?php echo dv_e($status['label']); ?></strong></div>
    <div class="metric"><span>Total starts</span><strong><?php echo (int) $download['download_count']; ?></strong></div>
    <div class="metric"><span>Today</span><strong><?php echo (int) $stats['today']; ?></strong></div>
    <div class="metric"><span>Last 7 days</span><strong><?php echo (int) $stats['last7']; ?></strong></div>
    <div class="metric"><span>Last 30 days</span><strong><?php echo (int) $stats['last30']; ?></strong></div>
    <div class="metric"><span>Highest day</span><strong><?php echo dv_e($stats['highest_day'] ?: 'None'); ?></strong></div>
</section>
<section class="panel">
    <div class="panel-head">
        <h2><?php echo dv_e($download['title']); ?></h2>
        <button class="button" data-copy="<?php echo dv_e(dv_public_download_url((string) $download['slug'])); ?>">Copy Public URL</button>
    </div>
    <div class="chart-bars" aria-label="Daily download starts">
        <?php foreach (array_slice($stats['days'], -30, 30, true) as $day => $count): $height = min(100, 8 + ((int) $count * 12)); ?>
            <div title="<?php echo dv_e($day . ': ' . $count); ?>"><span style="height: <?php echo $height; ?>%"></span><small><?php echo dv_e(substr((string) $day, 5)); ?></small></div>
        <?php endforeach; ?>
        <?php if ($stats['days'] === []): ?><p class="muted">No successful download starts yet.</p><?php endif; ?>
    </div>
</section>
<section class="panel">
    <h2>Recent Events</h2>
    <div class="table-wrap">
        <table><thead><tr><th>Result</th><th>Date</th><th>Referrer</th><th>Device</th></tr></thead><tbody>
        <?php foreach ($events as $event): ?>
            <tr><td><?php echo dv_e(str_replace('_', ' ', (string) $event['result'])); ?></td><td><?php echo dv_e(dv_local_time((string) $event['timestamp'])); ?></td><td><?php echo dv_e($event['referrer_domain'] ?? '-'); ?></td><td><?php echo dv_e($event['device_type'] ?? '-'); ?></td></tr>
        <?php endforeach; ?>
        <?php if ($events === []): ?><tr><td colspan="4" class="muted">No events recorded.</td></tr><?php endif; ?>
        </tbody></table>
    </div>
</section>
