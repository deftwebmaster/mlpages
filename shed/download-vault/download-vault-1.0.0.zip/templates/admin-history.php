<?php
declare(strict_types=1);
$downloadsById = [];
foreach ($downloads as $download) {
    $downloadsById[$download['id']] = $download;
}
?>
<section class="panel">
    <div class="panel-head"><h2>Event History</h2><input class="search" type="search" data-table-search placeholder="Search history"></div>
    <div class="table-wrap">
        <table data-searchable><thead><tr><th>File</th><th>Result</th><th>Date</th><th>Referrer</th><th>Device</th></tr></thead><tbody>
        <?php foreach ($events as $event): $item = $downloadsById[$event['download_id'] ?? ''] ?? null; ?>
            <tr><td><?php echo dv_e($item['title'] ?? 'Unknown download'); ?></td><td><?php echo dv_e(str_replace('_', ' ', (string) $event['result'])); ?></td><td><?php echo dv_e(dv_local_time((string) $event['timestamp'])); ?></td><td><?php echo dv_e($event['referrer_domain'] ?? '-'); ?></td><td><?php echo dv_e($event['device_type'] ?? '-'); ?></td></tr>
        <?php endforeach; ?>
        <?php if ($events === []): ?><tr><td colspan="5" class="muted">No history yet.</td></tr><?php endif; ?>
        </tbody></table>
    </div>
</section>
