<?php
declare(strict_types=1);
?>
<section class="panel">
    <div class="panel-head">
        <h2>Backups</h2>
        <form method="post" action="<?php echo dv_e(dv_url('admin/actions/backup.php')); ?>"><?php echo dv_csrf_field(); ?><input type="hidden" name="backup_action" value="create"><button class="button primary" type="submit">Create Backup</button></form>
    </div>
    <div class="table-wrap">
        <table><thead><tr><th>Name</th><th>Size</th><th>Created</th><th>Action</th></tr></thead><tbody>
        <?php foreach ($backups as $backup): ?>
            <tr>
                <td><code><?php echo dv_e($backup['name']); ?></code></td>
                <td><?php echo dv_e(dv_format_bytes((int) $backup['size'])); ?></td>
                <td><?php echo dv_e(date('M j, Y g:i A', (int) $backup['created'])); ?></td>
                <td><form method="post" action="<?php echo dv_e(dv_url('admin/actions/backup.php')); ?>" data-confirm="Restore <?php echo dv_e($backup['name']); ?>? A backup of current data will be created first."><?php echo dv_csrf_field(); ?><input type="hidden" name="backup_action" value="restore"><input type="hidden" name="backup_name" value="<?php echo dv_e($backup['name']); ?>"><button class="icon-button" type="submit">Restore</button></form></td>
            </tr>
        <?php endforeach; ?>
        <?php if ($backups === []): ?><tr><td colspan="4" class="muted">No backups have been created yet.</td></tr><?php endif; ?>
        </tbody></table>
    </div>
</section>
