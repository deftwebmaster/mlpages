<?php
declare(strict_types=1);
$title = $title ?? 'Download unavailable';
$message = $message ?? 'This download is unavailable.';
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo dv_e($title); ?> - <?php echo dv_e(dv_config('app_name', 'Download Vault')); ?></title>
    <link rel="stylesheet" href="<?php echo dv_e(dv_url('assets/css/public.css')); ?>">
</head>
<body>
<main class="download-card">
    <p class="eyebrow"><?php echo dv_e(dv_config('app_name', 'Download Vault')); ?></p>
    <h1><?php echo dv_e($title); ?></h1>
    <p class="description"><?php echo dv_e($message); ?></p>
    <?php if (dv_config('homepage_url')): ?><a class="button" href="<?php echo dv_e((string) dv_config('homepage_url')); ?>">Return to website</a><?php endif; ?>
    <?php if (dv_config('show_powered_by', true)): ?><footer><?php echo dv_e(dv_config('public_footer', 'Powered by Download Vault')); ?></footer><?php endif; ?>
</main>
</body>
</html>
