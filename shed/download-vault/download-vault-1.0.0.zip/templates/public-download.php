<?php
declare(strict_types=1);
$expires = $download['expires_at'] ?? null;
$remaining = null;
if (($download['maximum_downloads'] ?? null) !== null) {
    $remaining = max(0, (int) $download['maximum_downloads'] - (int) $download['download_count']);
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo dv_e($download['title']); ?> - <?php echo dv_e(dv_config('app_name')); ?></title>
    <link rel="stylesheet" href="<?php echo dv_e(dv_url('assets/css/public.css')); ?>">
</head>
<body>
<main class="download-card">
    <p class="eyebrow"><?php echo dv_e(dv_config('app_name')); ?></p>
    <h1><?php echo dv_e($download['title']); ?></h1>
    <?php if (!empty($download['description'])): ?><p class="description"><?php echo nl2br(dv_e($download['description'])); ?></p><?php endif; ?>
    <dl class="file-facts">
        <dt>Filename</dt><dd><?php echo dv_e($download['original_filename']); ?></dd>
        <dt>Type</dt><dd><?php echo dv_e(strtoupper(dv_extension((string) $download['original_filename']))); ?></dd>
        <?php if (!empty($download['show_file_size'])): ?><dt>Size</dt><dd><?php echo dv_e(dv_format_bytes((int) $download['file_size'])); ?></dd><?php endif; ?>
        <?php if (!empty($download['show_expiration']) && $expires): ?><dt>Expires</dt><dd><?php echo dv_e(dv_local_time((string) $expires)); ?></dd><?php endif; ?>
        <?php if (!empty($download['show_remaining']) && $remaining !== null): ?><dt>Remaining</dt><dd><?php echo (int) $remaining; ?> download starts</dd><?php endif; ?>
    </dl>
    <?php if ($requiresPassword && !$authorized): ?>
        <?php if ($passwordError): ?><div class="notice danger"><?php echo dv_e($passwordError); ?></div><?php endif; ?>
        <form method="post">
            <?php echo dv_csrf_field(); ?>
            <label for="download_password">Password</label>
            <input id="download_password" name="download_password" type="password" required autocomplete="off">
            <button class="button primary" type="submit">Unlock Download</button>
        </form>
    <?php else: ?>
        <a class="button primary" href="<?php echo dv_e(dv_public_download_url((string) $download['slug']) . (str_contains(dv_public_download_url((string) $download['slug']), '?') ? '&' : '?') . 'download=1'); ?>">Download File</a>
    <?php endif; ?>
    <?php if (dv_config('show_powered_by', true)): ?><footer><?php echo dv_e(dv_config('public_footer', 'Powered by Download Vault')); ?></footer><?php endif; ?>
</main>
</body>
</html>
