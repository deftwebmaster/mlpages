<?php

declare(strict_types=1);

require_once __DIR__ . '/../includes/bootstrap.php';
cc_start_session();
cc_require_admin();
if (cc_get_value('format') === 'csv') {
    cc_send_links_csv(cc_get_value('id') ? (string) cc_get_value('id') : null);
}
cc_send_admin_headers();
ob_start();
?>
<div class="page-head"><div><h1>Exports</h1><p class="muted">Download CSV reports or complete JSON backups.</p></div></div>
<section class="panel stack">
    <h2>CSV Reports</h2>
    <p class="muted">Spreadsheet-formula characters are escaped with a leading apostrophe.</p>
    <a class="button primary" href="<?= cc_h(cc_base_url('admin/exports.php?format=csv')) ?>">Export all links as CSV</a>
</section>
<section class="panel stack" style="margin-top:1rem">
    <h2>Import Backup</h2>
    <form method="post" action="<?= cc_h(cc_base_url('admin/actions/import.php')) ?>" enctype="multipart/form-data">
        <?= cc_csrf_field() ?>
        <div class="field"><label for="import">Backup JSON</label><input id="import" name="import" type="file" accept="application/json"></div>
        <button type="submit">Import backup</button>
    </form>
</section>
<?php
$content = ob_get_clean();
$pageTitle = 'Exports';
require cc_root_path('templates/admin-layout.php');
