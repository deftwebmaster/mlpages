<?php

declare(strict_types=1);

require_once __DIR__ . '/../../includes/bootstrap.php';
cc_start_session();
cc_require_admin();
cc_require_csrf();

$existing = cc_find_link_by_id((string) ($_POST['id'] ?? ''));
if (!$existing) {
    cc_admin_error('The requested link was not found.', 404);
}
[$errors, $validated] = cc_validate_link_input($_POST, $existing);
if ($validated['type'] === 'protected_download' && !empty($_FILES['upload']['name'])) {
    try {
        cc_create_backup('before-replace-file');
        $validated = array_replace($validated, cc_store_uploaded_file($_FILES['upload']));
    } catch (Throwable $e) {
        $errors['upload'] = $e->getMessage();
    }
} elseif ($validated['type'] === 'protected_download') {
    foreach (['stored_filename', 'original_filename', 'file_size', 'mime_type', 'sha256'] as $key) {
        $validated[$key] = $existing[$key] ?? null;
    }
}
$validated['force_download'] = cc_bool_from_post('force_download');
$validated['allow_inline'] = cc_bool_from_post('allow_inline');
if ($errors !== []) {
    $_SESSION['form_errors'] = $errors;
    $_SESSION['form_values'] = array_replace($existing, $_POST);
    header('Location: ' . cc_base_url('admin/link-edit.php?id=' . rawurlencode((string) $existing['id'])));
    exit;
}
$link = cc_link_payload($validated, $existing);
foreach (['stored_filename', 'original_filename', 'file_size', 'mime_type', 'sha256', 'force_download', 'allow_inline'] as $key) {
    if (array_key_exists($key, $validated)) {
        $link[$key] = $validated[$key];
    }
}
cc_save_link($link);
cc_flash('Link saved.');
header('Location: ' . cc_base_url('admin/link-stats.php?id=' . rawurlencode((string) $link['id'])));
exit;
