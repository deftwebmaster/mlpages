<?php

declare(strict_types=1);

require_once __DIR__ . '/../../includes/bootstrap.php';
cc_start_session();
cc_require_admin();
cc_require_csrf();

if (empty($_FILES['import']['tmp_name'])) {
    cc_admin_error('Choose a Click Counter backup JSON file to import.', 400);
}
$data = cc_read_json_file((string) $_FILES['import']['tmp_name']);
if (($data['schema_version'] ?? null) !== 1 || !is_array($data['data'] ?? null)) {
    cc_admin_error('The import file is not a valid Click Counter backup.', 400);
}
cc_create_backup('before-import');
foreach (['links', 'daily-stats', 'recent-events'] as $name) {
    if (!is_array($data['data'][$name] ?? null)) {
        cc_admin_error('The import file is missing required data.', 400);
    }
}
cc_with_lock('data', static function () use ($data): void {
    foreach (['links', 'daily-stats', 'recent-events'] as $name) {
        cc_atomic_write_json(cc_json_path($name), $data['data'][$name]);
    }
});
cc_flash('Import completed.');
header('Location: ' . cc_base_url('admin/links.php'));
exit;
