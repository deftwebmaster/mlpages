<?php

declare(strict_types=1);

require_once __DIR__ . '/../../includes/bootstrap.php';
cc_start_session();
cc_require_admin();
cc_require_csrf();

$id = (string) ($_POST['id'] ?? '');
cc_delete_link($id, cc_bool_from_post('delete_stats'), cc_bool_from_post('delete_file'));
cc_flash('Link deleted.');
header('Location: ' . cc_base_url('admin/links.php'));
exit;
