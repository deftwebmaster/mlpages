<?php

declare(strict_types=1);

require_once __DIR__ . '/../../includes/bootstrap.php';
cc_start_session();
cc_require_admin();
cc_require_csrf();

$id = (string) ($_POST['id'] ?? '');
$mode = (string) ($_POST['mode'] ?? 'all');
cc_create_backup('before-reset-counter');
cc_update_json('links', static function (array &$data) use ($id): void {
    foreach (($data['links'] ?? []) as &$link) {
        if (($link['id'] ?? '') === $id) {
            $link['total_clicks'] = 0;
            $link['estimated_unique_clicks'] = 0;
            $link['last_clicked_at'] = null;
            $link['updated_at'] = cc_now();
        }
    }
});
if ($mode === 'all' || $mode === 'daily') {
    cc_update_json('daily-stats', static function (array &$data) use ($id): void {
        unset($data['links'][$id]);
    });
}
cc_flash('Counter reset.');
header('Location: ' . cc_base_url('admin/link-stats.php?id=' . rawurlencode($id)));
exit;
