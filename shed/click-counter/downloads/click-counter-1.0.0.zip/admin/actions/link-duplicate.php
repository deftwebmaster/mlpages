<?php

declare(strict_types=1);

require_once __DIR__ . '/../../includes/bootstrap.php';
cc_start_session();
cc_require_admin();
cc_require_csrf();

$copy = cc_duplicate_link((string) ($_POST['id'] ?? ''));
if (!$copy) {
    cc_admin_error('The requested link was not found.', 404);
}
cc_flash('Link duplicated with a fresh counter.');
header('Location: ' . cc_base_url('admin/link-edit.php?id=' . rawurlencode((string) $copy['id'])));
exit;
