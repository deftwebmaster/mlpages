<?php

declare(strict_types=1);

require_once __DIR__ . '/../../includes/bootstrap.php';
cc_start_session();
cc_require_admin();
cc_require_csrf();
cc_flash('Bulk actions are reserved for a later maintenance release.', 'error');
header('Location: ' . cc_base_url('admin/links.php'));
exit;
