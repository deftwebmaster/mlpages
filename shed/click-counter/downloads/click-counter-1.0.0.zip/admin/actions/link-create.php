<?php

declare(strict_types=1);

require_once __DIR__ . '/../../includes/bootstrap.php';
cc_start_session();
cc_require_admin();
cc_require_csrf();

[$errors, $validated] = cc_validate_link_input($_POST);
if ($validated['type'] === 'protected_download') {
    if (!empty($_FILES['upload']['name'])) {
        try {
            $validated = array_replace($validated, cc_store_uploaded_file($_FILES['upload']));
            $validated['force_download'] = cc_bool_from_post('force_download');
            $validated['allow_inline'] = cc_bool_from_post('allow_inline');
        } catch (Throwable $e) {
            $errors['upload'] = $e->getMessage();
        }
    } else {
        $errors['upload'] = 'Protected downloads need a private file.';
    }
}
if ($errors !== []) {
    $_SESSION['form_errors'] = $errors;
    $_SESSION['form_values'] = $_POST;
    header('Location: ' . cc_base_url('admin/link-create.php'));
    exit;
}
$link = cc_link_payload($validated);
foreach (['stored_filename', 'original_filename', 'file_size', 'mime_type', 'sha256', 'force_download', 'allow_inline'] as $key) {
    if (array_key_exists($key, $validated)) {
        $link[$key] = $validated[$key];
    }
}
cc_save_link($link);
cc_flash('Link created.');
header('Location: ' . cc_base_url('admin/links.php'));
exit;
