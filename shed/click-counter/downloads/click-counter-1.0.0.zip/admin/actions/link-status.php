<?php

declare(strict_types=1);

require_once __DIR__ . '/../../includes/bootstrap.php';
cc_start_session();
cc_require_admin();
cc_require_csrf();

$id = (string) ($_POST['id'] ?? '');
$status = (string) ($_POST['status'] ?? 'disabled');
if (!in_array($status, ['active', 'disabled', 'archived'], true)) {
    $status = 'disabled';
}
$link = cc_find_link_by_id($id);
if (!$link) {
    cc_admin_error('The requested link was not found.', 404);
}
$link['status'] = $status;
$link['updated_at'] = cc_now();
cc_save_link($link);
cc_flash('Link status updated.');
header('Location: ' . cc_base_url('admin/links.php'));
exit;
