<?php

declare(strict_types=1);

require_once __DIR__ . '/../includes/bootstrap.php';
cc_start_session();
cc_require_admin();
if (cc_get_value('download')) {
    $name = basename((string) cc_get_value('download'));
    $path = cc_storage_path('backups/' . $name);
    if (!is_file($path)) {
        cc_admin_error('Backup not found.', 404);
    }
    header('Content-Type: application/json; charset=UTF-8');
    header('Content-Disposition: attachment; filename="' . $name . '"');
    readfile($path);
    exit;
}
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'create') {
    cc_require_csrf();
    cc_create_backup('manual');
    cc_flash('Backup created.');
    header('Location: ' . cc_base_url('admin/backups.php'));
    exit;
}
cc_send_admin_headers();
$backups = cc_list_backups();
ob_start();
?>
<div class="page-head">
    <div><h1>Backups</h1><p class="muted">Backups include application data, not protected file contents.</p></div>
    <form method="post"><?= cc_csrf_field() ?><input type="hidden" name="action" value="create"><button class="primary" type="submit">Create backup</button></form>
</div>
<div class="table-wrap"><table>
    <thead><tr><th>Name</th><th>Created</th><th>Size</th><th>Actions</th></tr></thead>
    <tbody>
    <?php foreach ($backups as $backup): ?>
        <tr><td><?= cc_h($backup['name']) ?></td><td><?= cc_h($backup['created']) ?></td><td><?= cc_h(cc_bytes($backup['size'])) ?></td><td class="actions"><a class="button" href="<?= cc_h(cc_base_url('admin/backups.php?download=' . rawurlencode($backup['name']))) ?>">Download</a><form class="inline" method="post" action="<?= cc_h(cc_base_url('admin/actions/restore.php')) ?>"><?= cc_csrf_field() ?><input type="hidden" name="name" value="<?= cc_h($backup['name']) ?>"><button type="submit">Restore</button></form></td></tr>
    <?php endforeach; ?>
    <?php if ($backups === []): ?><tr><td colspan="4">No backups yet.</td></tr><?php endif; ?>
    </tbody>
</table></div>
<?php
$content = ob_get_clean();
$pageTitle = 'Backups';
require cc_root_path('templates/admin-layout.php');
