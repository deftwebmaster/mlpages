<?php

declare(strict_types=1);

require_once __DIR__ . '/../includes/bootstrap.php';
cc_start_session();
cc_require_admin();
cc_send_admin_headers();

$links = cc_all_links();
$active = array_filter($links, static fn (array $link): bool => cc_effective_status($link) === 'active');
$total = array_sum(array_map(static fn (array $link): int => (int) ($link['total_clicks'] ?? 0), $links));
$today = cc_total_for_period(null, 1);
$seven = cc_total_for_period(null, 7);
$thirty = cc_total_for_period(null, 30);
$most = null;
foreach ($links as $link) {
    if ($most === null || (int) ($link['total_clicks'] ?? 0) > (int) ($most['total_clicks'] ?? 0)) {
        $most = $link;
    }
}
$attention = [];
foreach ([cc_config('storage_path'), cc_config('files_path'), cc_storage_path('backups'), cc_storage_path('locks'), cc_storage_path('temporary')] as $path) {
    if (!is_writable((string) $path)) {
        $attention[] = 'Storage path is not writable: ' . basename((string) $path);
    }
}
if (is_file(cc_root_path('tools/generate-password.php'))) {
    $attention[] = 'Password hash helper exists. Delete it after setup.';
}
foreach ($links as $link) {
    if (cc_effective_status($link) === 'missing_file') {
        $attention[] = 'Protected file missing for ' . ($link['name'] ?? 'a link');
    }
}
$series = cc_chart_series(null, 30);
ob_start();
?>
<div class="page-head">
    <div>
        <h1>Dashboard</h1>
        <p class="muted">A compact view of tracked links, counts, and items needing attention.</p>
    </div>
    <a class="button primary" href="<?= cc_h(cc_base_url('admin/link-create.php')) ?>">Create link</a>
</div>
<section class="grid" aria-label="Summary">
    <div class="metric"><strong><?= count($active) ?></strong><span>Active links</span></div>
    <div class="metric"><strong><?= (int) $total ?></strong><span>Total clicks</span></div>
    <div class="metric"><strong><?= (int) $today ?></strong><span>Today</span></div>
    <div class="metric"><strong><?= (int) $seven ?></strong><span>Last 7 days</span></div>
</section>
<div class="two-col" style="margin-top:1rem">
    <section class="panel">
        <h2>Last 30 Days</h2>
        <div class="chart" data-chart="<?= cc_h(json_encode($series) ?: '[]') ?>" aria-label="Daily click chart"></div>
        <p class="muted">Numerical summary: <?= (int) $thirty ?> clicks in the last 30 days.</p>
    </section>
    <section class="panel">
        <h2>Attention Required</h2>
        <?php if ($attention === []): ?>
            <p class="muted">No immediate issues found.</p>
        <?php else: ?>
            <ul><?php foreach (array_slice($attention, 0, 8) as $item): ?><li><?= cc_h($item) ?></li><?php endforeach; ?></ul>
        <?php endif; ?>
        <p class="muted">Most-clicked link: <?= $most ? cc_h($most['name']) . ' (' . (int) $most['total_clicks'] . ')' : 'None yet' ?></p>
    </section>
</div>
<section class="panel" style="margin-top:1rem">
    <h2>Recent Activity</h2>
    <?php $events = cc_recent_events(10); ?>
    <?php if ($events === []): ?>
        <p class="muted">No clicks have been recorded yet.</p>
    <?php else: ?>
        <div class="table-wrap"><table>
            <thead><tr><th>Link</th><th>Result</th><th>Date</th><th>Referrer</th><th>Device</th></tr></thead>
            <tbody>
            <?php foreach ($events as $event): ?>
                <tr><td><?= cc_h($event['link_name'] ?? '') ?></td><td><?= cc_h($event['result'] ?? '') ?></td><td><?= cc_h(cc_to_local($event['timestamp'] ?? null)) ?></td><td><?= cc_h($event['referrer_domain'] ?? '-') ?></td><td><?= cc_h($event['device_type'] ?? '-') ?></td></tr>
            <?php endforeach; ?>
            </tbody>
        </table></div>
    <?php endif; ?>
</section>
<script src="<?= cc_h(cc_base_url('assets/js/charts.js')) ?>" defer></script>
<?php
$content = ob_get_clean();
$pageTitle = 'Dashboard';
require cc_root_path('templates/admin-layout.php');
