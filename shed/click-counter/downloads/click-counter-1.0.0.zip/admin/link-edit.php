<?php

declare(strict_types=1);

require_once __DIR__ . '/../includes/bootstrap.php';
cc_start_session();
cc_require_admin();
cc_send_admin_headers();
$link = cc_find_link_by_id((string) cc_get_value('id'));
if (!$link) {
    cc_admin_error('The requested link was not found.', 404);
}
$errors = $_SESSION['form_errors'] ?? [];
if (!empty($_SESSION['form_values'])) {
    $link = array_replace($link, $_SESSION['form_values']);
}
unset($_SESSION['form_errors'], $_SESSION['form_values']);
ob_start();
?>
<div class="page-head"><div><h1>Edit Link</h1><p class="muted">Changing a slug stops the old tracking URL from working.</p></div></div>
<?php $action = cc_base_url('admin/actions/link-update.php'); require cc_root_path('templates/components/link-form.php'); ?>
<?php
$content = ob_get_clean();
$pageTitle = 'Edit Link';
require cc_root_path('templates/admin-layout.php');
