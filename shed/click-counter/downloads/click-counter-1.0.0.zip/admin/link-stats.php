<?php

declare(strict_types=1);

require_once __DIR__ . '/../includes/bootstrap.php';
cc_start_session();
cc_require_admin();
cc_send_admin_headers();
$link = cc_find_link_by_id((string) cc_get_value('id'));
if (!$link) {
    cc_admin_error('The requested link was not found.', 404);
}
$series = cc_chart_series((string) $link['id'], 30);
$highest = cc_highest_day((string) $link['id']);
$remaining = $link['maximum_clicks'] ? max(0, (int) $link['maximum_clicks'] - (int) $link['total_clicks']) : null;
$events = cc_recent_events(20, (string) $link['id']);
ob_start();
?>
<div class="page-head">
    <div><h1><?= cc_h($link['name']) ?></h1><p class="muted"><?= cc_h(cc_tracking_url($link)) ?></p></div>
    <div class="actions"><button data-copy="<?= cc_h(cc_tracking_url($link)) ?>">Copy URL</button><a class="button" href="<?= cc_h(cc_base_url('admin/link-edit.php?id=' . rawurlencode((string) $link['id']))) ?>">Edit</a></div>
</div>
<section class="grid">
    <div class="metric"><strong><?= (int) $link['total_clicks'] ?></strong><span>Total <?= ($link['type'] ?? '') === 'redirect' ? 'clicks' : 'download starts' ?></span></div>
    <div class="metric"><strong><?= (int) (cc_daily_counts_for_link((string) $link['id'])[cc_today_key()] ?? 0) ?></strong><span>Today</span></div>
    <div class="metric"><strong><?= cc_total_for_period((string) $link['id'], 7) ?></strong><span>Last 7 days</span></div>
    <div class="metric"><strong><?= $remaining === null ? 'Unlimited' : (string) $remaining ?></strong><span>Remaining</span></div>
</section>
<div class="two-col" style="margin-top:1rem">
    <section class="panel">
        <h2>Daily Counts</h2>
        <div class="chart" data-chart="<?= cc_h(json_encode($series) ?: '[]') ?>"></div>
        <p class="muted">Highest day: <?= $highest ? cc_h($highest['date']) . ' with ' . (int) $highest['count'] : 'None yet' ?>. Estimated unique clicks are approximate and only shown when enabled.</p>
    </section>
    <section class="panel">
        <h2>Details</h2>
        <p><strong>Status:</strong> <?= cc_h(cc_status_label(cc_effective_status($link))) ?></p>
        <p><strong>Destination:</strong> <?= cc_h(($link['type'] ?? '') === 'protected_download' ? ($link['original_filename'] ?? '') : ($link['destination_url'] ?? '')) ?></p>
        <p><strong>Created:</strong> <?= cc_h(cc_to_local($link['created_at'] ?? null)) ?></p>
        <p><strong>Last clicked:</strong> <?= cc_h(cc_to_local($link['last_clicked_at'] ?? null)) ?></p>
        <p><strong>Public counter:</strong> <?= !empty($link['public_counter_enabled']) ? 'Enabled' : 'Disabled' ?></p>
        <div class="actions">
            <form method="post" action="<?= cc_h(cc_base_url('admin/actions/link-reset.php')) ?>">
                <?= cc_csrf_field() ?>
                <input type="hidden" name="id" value="<?= cc_h($link['id']) ?>">
                <input type="hidden" name="mode" value="all">
                <button type="submit">Reset counter</button>
            </form>
            <form method="post" action="<?= cc_h(cc_base_url('admin/actions/link-status.php')) ?>">
                <?= cc_csrf_field() ?>
                <input type="hidden" name="id" value="<?= cc_h($link['id']) ?>">
                <input type="hidden" name="status" value="archived">
                <button type="submit">Archive</button>
            </form>
            <form method="post" action="<?= cc_h(cc_base_url('admin/actions/link-delete.php')) ?>">
                <?= cc_csrf_field() ?>
                <input type="hidden" name="id" value="<?= cc_h($link['id']) ?>">
                <label class="check"><input type="checkbox" name="delete_stats" value="1" checked> Delete statistics</label>
                <label class="check"><input type="checkbox" name="delete_file" value="1"> Delete protected file when unused</label>
                <button class="danger" type="submit">Delete link</button>
            </form>
        </div>
    </section>
</div>
<section class="panel" style="margin-top:1rem">
    <h2>Recent Activity</h2>
    <?php if ($events === []): ?><p class="muted">No recent activity for this link.</p><?php else: ?>
    <div class="table-wrap"><table><thead><tr><th>Date</th><th>Result</th><th>Referrer</th><th>Device</th></tr></thead><tbody>
        <?php foreach ($events as $event): ?><tr><td><?= cc_h(cc_to_local($event['timestamp'] ?? null)) ?></td><td><?= cc_h($event['result'] ?? '') ?></td><td><?= cc_h($event['referrer_domain'] ?? '-') ?></td><td><?= cc_h($event['device_type'] ?? '-') ?></td></tr><?php endforeach; ?>
    </tbody></table></div>
    <?php endif; ?>
</section>
<script src="<?= cc_h(cc_base_url('assets/js/charts.js')) ?>" defer></script>
<?php
$content = ob_get_clean();
$pageTitle = 'Link Statistics';
require cc_root_path('templates/admin-layout.php');
