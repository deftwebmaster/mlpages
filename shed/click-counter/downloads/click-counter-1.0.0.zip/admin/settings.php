<?php

declare(strict_types=1);

require_once __DIR__ . '/../includes/bootstrap.php';
cc_start_session();
cc_require_admin();
cc_send_admin_headers();
$config = cc_config();
ob_start();
?>
<div class="page-head"><div><h1>Settings</h1><p class="muted">Edit these values in <code>config.php</code>. Version 1 keeps settings file-based for simple deployment.</p></div></div>
<section class="panel">
    <div class="table-wrap"><table>
        <thead><tr><th>Setting</th><th>Value</th></tr></thead>
        <tbody>
        <?php foreach (['app_name', 'base_url', 'timezone', 'storage_path', 'files_path', 'default_redirect_status', 'default_bot_mode', 'recent_activity_limit', 'backup_retention', 'public_counter_cors', 'routing_mode'] as $key): ?>
            <tr><td><code><?= cc_h($key) ?></code></td><td><?= cc_h(is_array($config[$key] ?? null) ? json_encode($config[$key]) : (string) ($config[$key] ?? '')) ?></td></tr>
        <?php endforeach; ?>
        </tbody>
    </table></div>
</section>
<?php
$content = ob_get_clean();
$pageTitle = 'Settings';
require cc_root_path('templates/admin-layout.php');
