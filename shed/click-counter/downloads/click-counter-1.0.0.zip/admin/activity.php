<?php

declare(strict_types=1);

require_once __DIR__ . '/../includes/bootstrap.php';
cc_start_session();
cc_require_admin();
cc_send_admin_headers();
$events = cc_recent_events(200);
ob_start();
?>
<div class="page-head"><div><h1>Activity</h1><p class="muted">Recent counted requests and selected rejected attempts. Raw IP addresses and full user agents are not stored.</p></div></div>
<div class="table-wrap"><table>
    <thead><tr><th>Date</th><th>Link</th><th>Slug</th><th>Result</th><th>Referrer</th><th>Device</th></tr></thead>
    <tbody>
    <?php foreach ($events as $event): ?>
        <tr><td><?= cc_h(cc_to_local($event['timestamp'] ?? null)) ?></td><td><?= cc_h($event['link_name'] ?? '') ?></td><td><?= cc_h($event['slug'] ?? '') ?></td><td><?= cc_h($event['result'] ?? '') ?></td><td><?= cc_h($event['referrer_domain'] ?? '-') ?></td><td><?= cc_h($event['device_type'] ?? '-') ?></td></tr>
    <?php endforeach; ?>
    <?php if ($events === []): ?><tr><td colspan="6">No activity yet.</td></tr><?php endif; ?>
    </tbody>
</table></div>
<?php
$content = ob_get_clean();
$pageTitle = 'Activity';
require cc_root_path('templates/admin-layout.php');
