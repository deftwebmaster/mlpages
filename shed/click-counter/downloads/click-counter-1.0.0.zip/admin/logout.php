<?php

declare(strict_types=1);

require_once __DIR__ . '/../includes/bootstrap.php';
cc_start_session();
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    cc_admin_error('Logout requires a secure form submission.', 405);
}
cc_require_csrf();
cc_logout();
