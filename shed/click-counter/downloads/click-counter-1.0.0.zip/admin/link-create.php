<?php

declare(strict_types=1);

require_once __DIR__ . '/../includes/bootstrap.php';
cc_start_session();
cc_require_admin();
cc_send_admin_headers();
$link = ['type' => 'redirect', 'status' => 'active', 'redirect_status' => cc_config('default_redirect_status'), 'track_referrer' => cc_config('track_referrer_domains')];
$errors = $_SESSION['form_errors'] ?? [];
if (!empty($_SESSION['form_values'])) {
    $link = array_replace($link, $_SESSION['form_values']);
}
unset($_SESSION['form_errors'], $_SESSION['form_values']);
ob_start();
?>
<div class="page-head"><div><h1>Create Link</h1><p class="muted">Create a clean tracking URL that resolves to a stored destination.</p></div></div>
<?php $action = cc_base_url('admin/actions/link-create.php'); require cc_root_path('templates/components/link-form.php'); ?>
<?php
$content = ob_get_clean();
$pageTitle = 'Create Link';
require cc_root_path('templates/admin-layout.php');
