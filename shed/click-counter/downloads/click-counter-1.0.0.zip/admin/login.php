<?php

declare(strict_types=1);

require_once __DIR__ . '/../includes/bootstrap.php';
cc_start_session();
cc_send_admin_headers();

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    cc_require_csrf();
    if (cc_attempt_login((string) ($_POST['password'] ?? ''))) {
        header('Location: ' . cc_base_url('admin/'));
        exit;
    }
    $error = 'The login details were not accepted.';
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Admin Login - <?= cc_h(cc_config('app_name')) ?></title>
    <link rel="stylesheet" href="<?= cc_h(cc_base_url('assets/css/admin.css')) ?>">
</head>
<body>
<main class="shell" style="max-width:480px">
    <form class="panel stack" method="post">
        <?= cc_csrf_field() ?>
        <div>
            <h1><?= cc_h(cc_config('app_name')) ?></h1>
            <p class="muted">Administrator login</p>
        </div>
        <?php if (!cc_password_configured()): ?>
            <div class="flash error">Configure <code>admin_password_hash</code> before using the admin area.</div>
        <?php endif; ?>
        <?php if ($error !== ''): ?>
            <div class="flash error" role="alert"><?= cc_h($error) ?></div>
        <?php endif; ?>
        <div class="field">
            <label for="password">Password</label>
            <input id="password" name="password" type="password" autocomplete="current-password" required>
        </div>
        <button class="primary" type="submit">Log in</button>
    </form>
</main>
</body>
</html>
