<?php

declare(strict_types=1);

require_once __DIR__ . '/../includes/bootstrap.php';
cc_start_session();
cc_require_admin();
cc_send_admin_headers();

$links = cc_all_links();
ob_start();
?>
<div class="page-head">
    <div>
        <h1>Links</h1>
        <p class="muted">Search, manage, copy, and inspect tracked links.</p>
    </div>
    <a class="button primary" href="<?= cc_h(cc_base_url('admin/link-create.php')) ?>">Create link</a>
</div>
<section class="panel">
    <label for="search">Search links</label>
    <input id="search" data-table-search placeholder="Name, slug, type, or destination">
</section>
<div class="table-wrap" style="margin-top:1rem">
    <table>
        <thead><tr><th>Name</th><th>Type</th><th>Slug</th><th>Status</th><th>Total</th><th>Today</th><th>Last clicked</th><th>Actions</th></tr></thead>
        <tbody>
        <?php foreach ($links as $link): $status = cc_effective_status($link); $search = implode(' ', [$link['name'] ?? '', $link['slug'] ?? '', $link['type'] ?? '', $link['destination_url'] ?? '', $link['original_filename'] ?? '']); ?>
            <tr data-search-row="<?= cc_h($search) ?>">
                <td><strong><?= cc_h($link['name']) ?></strong><br><span class="muted"><?= cc_h($link['description'] ?? '') ?></span></td>
                <td><?= cc_h(str_replace('_', ' ', $link['type'])) ?></td>
                <td><code><?= cc_h($link['slug']) ?></code></td>
                <td><span class="badge <?= cc_h($status) ?>"><?= cc_h(cc_status_label($status)) ?></span></td>
                <td><?= (int) ($link['total_clicks'] ?? 0) ?></td>
                <td><?= (int) (cc_daily_counts_for_link((string) $link['id'])[cc_today_key()] ?? 0) ?></td>
                <td><?= cc_h(cc_to_local($link['last_clicked_at'] ?? null)) ?></td>
                <td class="actions">
                    <button type="button" data-copy="<?= cc_h(cc_tracking_url($link)) ?>">Copy</button>
                    <a class="button" href="<?= cc_h(cc_tracking_url($link)) ?>" target="_blank" rel="noopener">Open</a>
                    <a class="button" href="<?= cc_h(cc_base_url('admin/link-stats.php?id=' . rawurlencode((string) $link['id']))) ?>">Stats</a>
                    <a class="button" href="<?= cc_h(cc_base_url('admin/link-edit.php?id=' . rawurlencode((string) $link['id']))) ?>">Edit</a>
                    <form class="inline" method="post" action="<?= cc_h(cc_base_url('admin/actions/link-status.php')) ?>"><?= cc_csrf_field() ?><input type="hidden" name="id" value="<?= cc_h($link['id']) ?>"><input type="hidden" name="status" value="<?= ($link['status'] ?? '') === 'active' ? 'disabled' : 'active' ?>"><button type="submit"><?= ($link['status'] ?? '') === 'active' ? 'Disable' : 'Enable' ?></button></form>
                    <form class="inline" method="post" action="<?= cc_h(cc_base_url('admin/actions/link-duplicate.php')) ?>"><?= cc_csrf_field() ?><input type="hidden" name="id" value="<?= cc_h($link['id']) ?>"><button type="submit">Duplicate</button></form>
                </td>
            </tr>
        <?php endforeach; ?>
        <?php if ($links === []): ?><tr><td colspan="8">No links yet. Create your first tracked link.</td></tr><?php endif; ?>
        </tbody>
    </table>
</div>
<?php
$content = ob_get_clean();
$pageTitle = 'Links';
require cc_root_path('templates/admin-layout.php');
