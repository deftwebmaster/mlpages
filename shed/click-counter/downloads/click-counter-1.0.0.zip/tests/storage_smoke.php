<?php

declare(strict_types=1);

require_once __DIR__ . '/../includes/bootstrap.php';

$backup = cc_create_backup('test');
if (!is_file(cc_storage_path('backups/' . $backup))) {
    throw new RuntimeException('Backup was not created.');
}
[$ok] = cc_validate_redirect_url('javascript:alert(1)');
if ($ok) {
    throw new RuntimeException('Unsafe URL was accepted.');
}
[$ok] = cc_validate_redirect_url('https://example.com/path?a=1');
if (!$ok) {
    throw new RuntimeException('Safe HTTPS URL was rejected.');
}
echo "Storage smoke test passed.\n";
