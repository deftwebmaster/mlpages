<?php

declare(strict_types=1);

require_once __DIR__ . '/../includes/bootstrap.php';

$slug = 'stress-' . strtolower(bin2hex(random_bytes(3)));
$link = cc_link_payload([
    'name' => 'Stress Test',
    'slug' => $slug,
    'description' => '',
    'type' => 'redirect',
    'destination_url' => 'https://example.com/',
    'status' => 'active',
    'redirect_status' => 302,
    'public_counter_enabled' => true,
    'expires_at' => null,
    'maximum_clicks' => 25,
    'deduplication_seconds' => 0,
    'bot_mode' => 'count_all',
    'track_referrer' => false,
    'track_device' => false,
    'estimate_unique' => false,
    'notes' => '',
]);
cc_save_link($link);
for ($i = 0; $i < 40; $i++) {
    cc_count_request($slug, ['redirect']);
}
$saved = cc_find_link_by_slug($slug);
if (!$saved || (int) $saved['total_clicks'] !== 25) {
    throw new RuntimeException('Maximum-click limit was not enforced.');
}
echo "Counter limit test passed.\n";
