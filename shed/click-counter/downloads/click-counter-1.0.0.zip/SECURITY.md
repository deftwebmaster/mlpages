# Security Policy

## Supported Versions

Version 1.x receives security fixes while it is the current Script Shed release.

## Reporting Vulnerabilities

Report vulnerabilities privately to the maintainer before public disclosure. Include the affected version, setup details, steps to reproduce, and whether private data or redirects were exposed.

## Safe Redirect Behavior

Public requests may provide only a stored slug. They cannot provide arbitrary destinations. Click Counter validates destination URLs when saved and again immediately before redirecting. By default, only `https` and `http` destinations are allowed.

Blocked inputs include `javascript:`, `data:`, `file:`, protocol-relative URLs, control characters, null bytes, newlines, and invalid redirect status codes.

Click Counter must not be used for deceptive cloaking, scanner evasion, malware delivery, or bypassing platform rules.

## Private Storage

Place `storage_path` outside the web root whenever possible. If storage must be inside the project, keep the included `.htaccess` deny files and disable directory listing.

Never publish `config.php`, logs, backup JSON, visitor hashes, rate limits, or private file paths.

## Protected Downloads

Protected download files are stored with randomized filenames. Original filenames are metadata only. Before streaming, Click Counter resolves the configured files directory and the stored file path with `realpath()`, verifies the file remains inside the private directory, rejects symlinks where practical, and streams in chunks.

Executable and server configuration uploads are blocked, including PHP variants, PHTML, PHAR, CGI, shell scripts, `.htaccess`, and `.user.ini`.

## Public Counters

Public counters intentionally expose counts for links where the administrator enabled that feature. They do not expose destinations, internal IDs, notes, referrer data, visitor hashes, or private analytics.

## HTTPS

Use HTTPS in production, especially for administrator pages. Session cookies are marked secure when HTTPS is detected.

## File Permissions

Use the least permissive permissions your host supports. PHP needs write access to data, locks, backups, logs, temporary files, and protected file storage. Public visitors should not be able to browse those directories.

## Shared Hosting

Shared hosting varies. Run the Diagnostics page after installation and after moving storage. Delete the password helper once setup is complete.
