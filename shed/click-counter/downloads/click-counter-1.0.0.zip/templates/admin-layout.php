<?php

declare(strict_types=1);

$pageTitle = $pageTitle ?? cc_config('app_name');
$content = $content ?? '';
$flash = cc_flash();
$accent = cc_config('branding')['accent_color'] ?? '#2563eb';
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="color-scheme" content="light dark">
    <title><?= cc_h($pageTitle) ?> - <?= cc_h(cc_config('app_name')) ?></title>
    <link rel="stylesheet" href="<?= cc_h(cc_base_url('assets/css/admin.css')) ?>">
    <style>:root{--accent:<?= cc_h($accent) ?>}</style>
    <script src="<?= cc_h(cc_base_url('assets/js/admin.js')) ?>" defer></script>
</head>
<body>
<a class="skip-link" href="#content">Skip to content</a>
<header class="topbar">
    <div>
        <a class="brand" href="<?= cc_h(cc_base_url('admin/')) ?>"><?= cc_h(cc_config('app_name')) ?></a>
        <p><?= cc_h(cc_config('tagline')) ?></p>
    </div>
    <nav aria-label="Administrator">
        <a href="<?= cc_h(cc_base_url('admin/')) ?>">Dashboard</a>
        <a href="<?= cc_h(cc_base_url('admin/links.php')) ?>">Links</a>
        <a href="<?= cc_h(cc_base_url('admin/link-create.php')) ?>">Create</a>
        <a href="<?= cc_h(cc_base_url('admin/activity.php')) ?>">Activity</a>
        <a href="<?= cc_h(cc_base_url('admin/exports.php')) ?>">Exports</a>
        <a href="<?= cc_h(cc_base_url('admin/backups.php')) ?>">Backups</a>
        <a href="<?= cc_h(cc_base_url('admin/diagnostics.php')) ?>">Diagnostics</a>
        <form method="post" action="<?= cc_h(cc_base_url('admin/logout.php')) ?>">
            <?= cc_csrf_field() ?>
            <button type="submit">Log out</button>
        </form>
    </nav>
</header>
<main id="content" class="shell">
    <?php if ($flash): ?>
        <div class="flash <?= cc_h($flash['type']) ?>" role="status"><?= cc_h($flash['message']) ?></div>
    <?php endif; ?>
    <?= $content ?>
</main>
<footer class="footer">
    <?= cc_h(cc_config('branding')['admin_footer'] ?? '') ?>
</footer>
</body>
</html>
