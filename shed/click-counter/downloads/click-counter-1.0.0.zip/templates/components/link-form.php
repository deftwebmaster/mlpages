<?php

declare(strict_types=1);

$link = $link ?? [];
$errors = $errors ?? [];
$action = $action ?? cc_base_url('admin/actions/link-create.php');
$isEdit = !empty($link['id']);
?>
<form class="panel stack" method="post" action="<?= cc_h($action) ?>" enctype="multipart/form-data">
    <?= cc_csrf_field() ?>
    <?php if ($isEdit): ?>
        <input type="hidden" name="id" value="<?= cc_h($link['id']) ?>">
    <?php endif; ?>
    <div class="form-grid">
        <div class="field">
            <label for="name">Link name</label>
            <input id="name" name="name" value="<?= cc_h($link['name'] ?? '') ?>" required data-slug-source>
            <?php if (isset($errors['name'])): ?><div class="error"><?= cc_h($errors['name']) ?></div><?php endif; ?>
        </div>
        <div class="field">
            <label for="slug">Slug</label>
            <input id="slug" name="slug" value="<?= cc_h($link['slug'] ?? '') ?>" required data-slug-target>
            <?php if (isset($errors['slug'])): ?><div class="error"><?= cc_h($errors['slug']) ?></div><?php endif; ?>
        </div>
        <div class="field">
            <label for="type">Link type</label>
            <select id="type" name="type">
                <?php foreach (['redirect' => 'Redirect link', 'external_download' => 'External download', 'protected_download' => 'Protected local download'] as $value => $label): ?>
                    <option value="<?= cc_h($value) ?>" <?= ($link['type'] ?? 'redirect') === $value ? 'selected' : '' ?>><?= cc_h($label) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="field">
            <label for="status">Status</label>
            <select id="status" name="status">
                <?php foreach (['active' => 'Active', 'disabled' => 'Disabled', 'archived' => 'Archived'] as $value => $label): ?>
                    <option value="<?= cc_h($value) ?>" <?= ($link['status'] ?? 'active') === $value ? 'selected' : '' ?>><?= cc_h($label) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="field">
            <label for="destination_url">Destination or external file URL</label>
            <input id="destination_url" name="destination_url" value="<?= cc_h($link['destination_url'] ?? '') ?>" placeholder="https://example.com/resource">
            <?php if (isset($errors['destination_url'])): ?><div class="error"><?= cc_h($errors['destination_url']) ?></div><?php endif; ?>
        </div>
        <div class="field">
            <label for="redirect_status">Redirect status</label>
            <select id="redirect_status" name="redirect_status">
                <?php foreach ([302, 307, 301, 308] as $code): ?>
                    <option value="<?= $code ?>" <?= (int) ($link['redirect_status'] ?? cc_config('default_redirect_status')) === $code ? 'selected' : '' ?>><?= $code ?></option>
                <?php endforeach; ?>
            </select>
            <small class="muted">Permanent redirects can be cached and may stop future counts.</small>
        </div>
        <div class="field">
            <label for="upload">Protected download file</label>
            <input id="upload" name="upload" type="file">
            <?php if (!empty($link['original_filename'])): ?><small class="muted">Current file: <?= cc_h($link['original_filename']) ?></small><?php endif; ?>
            <?php if (isset($errors['upload'])): ?><div class="error"><?= cc_h($errors['upload']) ?></div><?php endif; ?>
        </div>
        <div class="field">
            <label for="expires_at">Expiration</label>
            <input id="expires_at" name="expires_at" type="datetime-local" value="">
            <?php if (!empty($link['expires_at'])): ?><small class="muted">Current: <?= cc_h(cc_to_local($link['expires_at'])) ?></small><?php endif; ?>
        </div>
        <div class="field">
            <label for="maximum_clicks">Maximum clicks</label>
            <input id="maximum_clicks" name="maximum_clicks" inputmode="numeric" value="<?= cc_h($link['maximum_clicks'] ?? '') ?>" placeholder="Blank for unlimited">
            <?php if (isset($errors['maximum_clicks'])): ?><div class="error"><?= cc_h($errors['maximum_clicks']) ?></div><?php endif; ?>
        </div>
        <div class="field">
            <label for="deduplication_seconds">Deduplication seconds</label>
            <input id="deduplication_seconds" name="deduplication_seconds" inputmode="numeric" value="<?= cc_h($link['deduplication_seconds'] ?? cc_config('default_deduplication_seconds')) ?>">
        </div>
        <div class="field">
            <label for="bot_mode">Bot filtering</label>
            <select id="bot_mode" name="bot_mode">
                <?php foreach (['count_all' => 'Count all requests', 'ignore_bots' => 'Ignore known bots and previews'] as $value => $label): ?>
                    <option value="<?= cc_h($value) ?>" <?= ($link['bot_mode'] ?? cc_config('default_bot_mode')) === $value ? 'selected' : '' ?>><?= cc_h($label) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
    </div>
    <div class="field">
        <label for="description">Description</label>
        <textarea id="description" name="description"><?= cc_h($link['description'] ?? '') ?></textarea>
    </div>
    <div class="form-grid">
        <label class="check"><input type="checkbox" name="public_counter_enabled" value="1" <?= !empty($link['public_counter_enabled']) ? 'checked' : '' ?>> Public counter enabled</label>
        <label class="check"><input type="checkbox" name="track_referrer" value="1" <?= !empty($link['track_referrer']) ? 'checked' : '' ?>> Track referrer hostnames</label>
        <label class="check"><input type="checkbox" name="track_device" value="1" <?= !empty($link['track_device']) ? 'checked' : '' ?>> Track device category</label>
        <label class="check"><input type="checkbox" name="estimate_unique" value="1" <?= !empty($link['estimate_unique']) ? 'checked' : '' ?>> Estimate unique clicks</label>
        <label class="check"><input type="checkbox" name="force_download" value="1" <?= !empty($link['force_download']) ? 'checked' : '' ?>> Force protected-file download</label>
        <label class="check"><input type="checkbox" name="allow_inline" value="1" <?= !empty($link['allow_inline']) ? 'checked' : '' ?>> Allow inline viewing</label>
    </div>
    <div class="field">
        <label for="notes">Administrator notes</label>
        <textarea id="notes" name="notes"><?= cc_h($link['notes'] ?? '') ?></textarea>
    </div>
    <div class="actions">
        <button class="primary" type="submit"><?= $isEdit ? 'Save link' : 'Create link' ?></button>
        <a class="button" href="<?= cc_h(cc_base_url('admin/links.php')) ?>">Cancel</a>
    </div>
</form>
