<?php

declare(strict_types=1);

$attribution = (bool) (cc_config('branding')['show_public_attribution'] ?? true);
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= cc_h($title) ?> - <?= cc_h($appName) ?></title>
    <link rel="stylesheet" href="<?= cc_h(cc_base_url('assets/css/public.css')) ?>">
</head>
<body>
<main class="public-message">
    <h1><?= cc_h($title) ?></h1>
    <p><?= cc_h($message) ?></p>
    <?php if ($attribution): ?>
        <small>Powered by <?= cc_h($appName) ?></small>
    <?php endif; ?>
</main>
</body>
</html>
