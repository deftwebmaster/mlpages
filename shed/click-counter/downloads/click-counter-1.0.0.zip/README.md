# Click Counter

Click Counter is a private, self-hosted click and download counter for ordinary websites. It creates clean tracking URLs, counts valid clicks or download starts, shows basic daily statistics, and can expose a small public count for pages that need one.

It does not use SQL, Composer, npm, a PHP framework, third-party analytics, external APIs, or public user accounts.

## Features

- Single administrator login with secure PHP sessions, CSRF tokens, and login rate limiting.
- Redirect links for internal or external URLs.
- External download redirects for counting download starts.
- Protected local downloads streamed through PHP from private storage.
- Clean Apache routes such as `/go/summer-sale` and `/download/free-guide`.
- Query-string fallbacks: `redirect.php?slug=summer-sale` and `download.php?slug=free-guide`.
- Total counters, daily counters, recent activity, expiration, maximum-click limits, optional bot filtering, and optional temporary deduplication.
- Public count endpoints and a local JavaScript embed.
- CSV export with spreadsheet formula-injection protection.
- JSON backups, restore, diagnostics, and maintenance scripts.

Screenshot placeholders:

- `docs/screenshots/dashboard.png`
- `docs/screenshots/link-form.png`
- `docs/screenshots/link-stats.png`

## Requirements

- PHP 8.2 or newer
- Apache with `mod_rewrite` for clean URLs, or any PHP host using query-string fallback routes
- PHP JSON and sessions
- PHP Fileinfo recommended for protected file uploads
- Writable private storage directory

## Installation

1. Upload the `click-counter` folder to your website, for example `/shed/click-counter/`.
2. Create a private storage folder outside the public web root when your host allows it, for example `/home/account/private/click-counter`.
3. Copy `config.example.php` to `config.php`.
4. Edit `config.php`:
   - Set `base_url` to `https://MattLivingston.com/shed/click-counter`.
   - Set `timezone`.
   - Set `storage_path` and `files_path`.
   - Set `admin_password_hash`.
5. Make storage folders writable by PHP.
6. Open `/tools/generate-password.php`, generate a password hash, paste it into `config.php`, then delete the helper.
7. Open `/admin/` and create your first tracked link.

For a local smoke run with PHP installed:

```bash
php -S localhost:8000
```

Then open `http://localhost:8000/admin/`.

## Private Storage

Recommended private structure:

```text
click-counter-private/
├── data/
├── files/
├── backups/
├── logs/
├── locks/
└── temporary/
```

If storage must live inside the public project folder, Click Counter includes `.htaccess` deny files. Outside-web-root storage is still preferred.

## Creating Links

In the admin area, choose **Create** and enter a name, slug, link type, and destination.

Redirect links count the request and redirect to a stored URL. External download links count the request and redirect to a stored file URL. Protected local downloads count the request and stream a private file through PHP.

Slugs are normalized to lowercase letters, numbers, hyphens, and underscores. Reserved slugs such as `admin`, `go`, `download`, `api`, and `tools` are blocked.

## Clean URL Setup

Apache rules are included in `.htaccess`:

```apache
RewriteRule ^go/([A-Za-z0-9_-]+)/?$ redirect.php?slug=$1 [L,QSA]
RewriteRule ^download/([A-Za-z0-9_-]+)/?$ download.php?slug=$1 [L,QSA]
RewriteRule ^api/count/([A-Za-z0-9_-]+)/?$ api/count.php?slug=$1 [L,QSA]
```

Nginx example:

```nginx
location /shed/click-counter/ {
    try_files $uri $uri/ /shed/click-counter/index.php?$query_string;
}

rewrite ^/shed/click-counter/go/([A-Za-z0-9_-]+)/?$ /shed/click-counter/redirect.php?slug=$1 last;
rewrite ^/shed/click-counter/download/([A-Za-z0-9_-]+)/?$ /shed/click-counter/download.php?slug=$1 last;
rewrite ^/shed/click-counter/api/count/([A-Za-z0-9_-]+)/?$ /shed/click-counter/api/count.php?slug=$1 last;
```

## Public Counter Embed

Enable public counters for a link, then use:

```html
<span data-click-count="summer-sale" data-prefix="Downloaded " data-suffix=" times">-</span>
<script src="https://example.com/click-counter/assets/js/counter.js" defer></script>
```

Plain-text endpoint:

```text
/api/count/summer-sale
```

JSON endpoint:

```text
/api/count/summer-sale/json
```

Public count endpoints expose only slug and count. They do not expose destinations, internal IDs, referrers, history, notes, visitor hashes, or private analytics.

## Privacy Behavior

By default, Click Counter stores aggregate counts and recent activity only. It does not store raw IP addresses, full user-agent strings, tracking cookies, external analytics, or browser fingerprints. Referrer storage keeps only the hostname. Device categories are approximate.

Temporary deduplication and estimated unique clicks use salted hashes and expiration windows. These are estimates, not identity systems.

## Backups and Restore

Use **Backups** in the admin area to create, download, and restore JSON backups. Backups are created before destructive actions such as deletion, reset, import, restore, and protected-file replacement.

Backups include JSON application data. They do not include protected file contents.

## CSV Export

Use **Exports** to download link reports as CSV. Values beginning with `=`, `+`, `-`, or `@` receive a leading apostrophe to reduce spreadsheet formula-injection risk.

## Maintenance

Run manually or by cron when desired:

```bash
php bin/maintenance.php
```

Maintenance trims recent activity, removes expired temporary visitor hashes and rate-limit records, prunes old backups, and reports missing protected files. The application still works without cron.

## Troubleshooting

- Admin login fails: verify `admin_password_hash` is set and regenerate the hash if needed.
- Clean URLs fail: confirm Apache rewrite support or use query-string fallbacks.
- Counts do not change: check storage and lock directories are writable.
- Protected downloads fail: confirm `files_path` points to a readable private directory and files were uploaded through the admin form.
- Public counter returns 404: enable the public counter for that link.
- Diagnostics warns about the password helper: delete `tools/generate-password.php` after setup.

## Scalability Limits

Click Counter is designed for personal sites, small businesses, blogs, landing pages, affiliate links, email campaigns, and modest download pages. Flat-file JSON storage is not intended for public URL-shortening services, millions of clicks, multi-server deployments, high-concurrency ad networks, or enterprise analytics.

## Upgrading

Back up your current installation, replace application files, keep your `config.php`, and run diagnostics. Schema versioning is present in the data files for future migrations.

## Uninstallation

Remove the public Click Counter folder and the private storage folder. If you embedded public counters on other pages, remove the `<script>` tag and `data-click-count` elements.
