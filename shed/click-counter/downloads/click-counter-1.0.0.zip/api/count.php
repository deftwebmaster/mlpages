<?php

declare(strict_types=1);

require_once __DIR__ . '/../includes/bootstrap.php';

cc_apply_counter_cors();
$slug = cc_slugify((string) ($_GET['slug'] ?? ''));
$format = (string) ($_GET['format'] ?? 'text');
$link = $slug !== '' ? cc_find_link_by_slug($slug) : null;
if (!$link || empty($link['public_counter_enabled'])) {
    http_response_code(404);
    header($format === 'json' ? 'Content-Type: application/json; charset=UTF-8' : 'Content-Type: text/plain; charset=UTF-8');
    echo $format === 'json' ? json_encode(['success' => false]) : 'Not found';
    exit;
}

if ($format === 'json') {
    header('Content-Type: application/json; charset=UTF-8');
    echo json_encode([
        'success' => true,
        'slug' => $link['slug'],
        'count' => (int) ($link['total_clicks'] ?? 0),
    ], JSON_UNESCAPED_SLASHES);
    exit;
}

header('Content-Type: text/plain; charset=UTF-8');
echo (string) (int) ($link['total_clicks'] ?? 0);
