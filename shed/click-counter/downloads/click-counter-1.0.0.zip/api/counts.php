<?php

declare(strict_types=1);

require_once __DIR__ . '/../includes/bootstrap.php';

cc_apply_counter_cors();
$slugs = array_filter(array_map('cc_slugify', explode(',', (string) ($_GET['slugs'] ?? ''))));
$payload = ['success' => true, 'counts' => []];
foreach ($slugs as $slug) {
    $link = cc_find_link_by_slug($slug);
    if ($link && !empty($link['public_counter_enabled'])) {
        $payload['counts'][$slug] = (int) ($link['total_clicks'] ?? 0);
    }
}
header('Content-Type: application/json; charset=UTF-8');
echo json_encode($payload, JSON_UNESCAPED_SLASHES);
