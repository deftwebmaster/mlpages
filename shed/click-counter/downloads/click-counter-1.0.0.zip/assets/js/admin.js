(function () {
    const name = document.querySelector('[data-slug-source]');
    const slug = document.querySelector('[data-slug-target]');
    if (name && slug) {
        let touched = Boolean(slug.value);
        slug.addEventListener('input', () => { touched = true; });
        name.addEventListener('input', () => {
            if (touched) return;
            slug.value = name.value.toLowerCase()
                .replace(/[^a-z0-9_-]+/g, '-')
                .replace(/^-+|-+$/g, '')
                .replace(/-+/g, '-');
        });
    }

    document.querySelectorAll('[data-copy]').forEach((button) => {
        button.addEventListener('click', async () => {
            try {
                await navigator.clipboard.writeText(button.getAttribute('data-copy') || '');
                button.textContent = 'Copied';
                setTimeout(() => { button.textContent = 'Copy'; }, 1200);
            } catch (_) {}
        });
    });

    const search = document.querySelector('[data-table-search]');
    if (search) {
        const rows = Array.from(document.querySelectorAll('[data-search-row]'));
        search.addEventListener('input', () => {
            const q = search.value.toLowerCase();
            rows.forEach((row) => {
                row.hidden = !(row.getAttribute('data-search-row') || '').toLowerCase().includes(q);
            });
        });
    }
})();
