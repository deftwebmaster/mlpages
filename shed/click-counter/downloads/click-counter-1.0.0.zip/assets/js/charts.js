(function () {
    document.querySelectorAll('[data-chart]').forEach((chart) => {
        const values = JSON.parse(chart.getAttribute('data-chart') || '[]');
        const max = Math.max(1, ...values.map((item) => item.count || 0));
        chart.innerHTML = '';
        values.forEach((item) => {
            const bar = document.createElement('span');
            bar.className = 'bar';
            bar.style.height = `${Math.max(3, ((item.count || 0) / max) * 100)}%`;
            bar.title = `${item.date}: ${item.count}`;
            chart.appendChild(bar);
        });
    });
})();
