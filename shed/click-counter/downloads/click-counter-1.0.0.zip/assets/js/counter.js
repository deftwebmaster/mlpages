(function () {
    const elements = Array.from(document.querySelectorAll('[data-click-count]'));
    if (!elements.length) return;
    const base = new URL(document.currentScript.src, window.location.href);
    const root = base.pathname.replace(/\/assets\/js\/counter\.js$/, '');
    elements.forEach(async (el) => {
        const slug = el.getAttribute('data-click-count');
        if (!slug) return;
        try {
            const response = await fetch(`${base.origin}${root}/api/count/${encodeURIComponent(slug)}`, { credentials: 'omit' });
            if (!response.ok) return;
            const text = await response.text();
            const prefix = el.getAttribute('data-prefix') || '';
            const suffix = el.getAttribute('data-suffix') || '';
            el.textContent = `${prefix}${text.trim()}${suffix}`;
        } catch (_) {}
    });
})();
