<?php

declare(strict_types=1);

require_once __DIR__ . '/includes/bootstrap.php';

$slug = (string) ($_GET['slug'] ?? '');
if ($slug === '') {
    cc_public_error('Link not found', 'This tracked link could not be found.', 404);
}

$result = cc_count_request($slug, ['redirect']);
$link = $result['link'] ?? null;
if (!$result['ok'] || !is_array($link)) {
    $status = (string) ($result['status'] ?? 'missing');
    match ($status) {
        'expired', 'limit_reached' => cc_public_error('Link unavailable', $status === 'expired' ? 'This link has expired.' : 'This link is no longer available.', 410),
        'disabled', 'archived', 'missing' => cc_public_error('Link not found', 'This tracked link could not be found.', 404),
        default => cc_public_error('Link unavailable', (string) (cc_config('branding')['public_unavailable_text'] ?? 'This tracked link is unavailable.'), 503),
    };
}

cc_safe_redirect((string) $link['destination_url'], (int) ($link['redirect_status'] ?? 302));
