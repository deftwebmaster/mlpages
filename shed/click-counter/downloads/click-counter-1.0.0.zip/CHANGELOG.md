# Changelog

## 1.0.0 - 2026-07-28

- Initial Click Counter release.
- Added flat-file JSON storage, safe redirects, download counting, protected local downloads, admin login, CSRF protection, backups, diagnostics, public counters, CSV export, and documentation.
