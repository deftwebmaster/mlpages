<?php

declare(strict_types=1);

require_once __DIR__ . '/includes/bootstrap.php';

$slug = (string) ($_GET['slug'] ?? '');
if ($slug === '') {
    cc_public_error('Download not found', 'This download could not be found.', 404);
}

$result = cc_count_request($slug, ['external_download', 'protected_download']);
$link = $result['link'] ?? null;
if (!$result['ok'] || !is_array($link)) {
    $status = (string) ($result['status'] ?? 'missing');
    match ($status) {
        'expired', 'limit_reached' => cc_public_error('Download unavailable', $status === 'expired' ? 'This download has expired.' : 'This download is no longer available.', 410),
        'disabled', 'archived', 'missing', 'missing_file' => cc_public_error('Download not found', 'This download could not be found.', 404),
        default => cc_public_error('Download unavailable', 'This download is temporarily unavailable.', 503),
    };
}

if (($link['type'] ?? '') === 'external_download') {
    cc_safe_redirect((string) $link['destination_url'], (int) ($link['redirect_status'] ?? 302));
}

cc_stream_protected_download($link);
