<?php

declare(strict_types=1);

$hash = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $password = (string) ($_POST['password'] ?? '');
    if ($password !== '') {
        $hash = password_hash($password, PASSWORD_DEFAULT);
    }
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Generate Click Counter Password Hash</title>
    <style>
        body{font:16px/1.5 system-ui,sans-serif;max-width:720px;margin:3rem auto;padding:0 1rem}
        input,button,textarea{font:inherit;width:100%;padding:.65rem;margin:.25rem 0 1rem}
        textarea{min-height:120px}
        .warn{border:1px solid #b42318;padding:1rem;border-radius:8px}
    </style>
</head>
<body>
<h1>Password Hash Helper</h1>
<p class="warn">Use this once, paste the generated hash into <code>config.php</code>, then delete <code>tools/generate-password.php</code> from your server.</p>
<form method="post">
    <label for="password">Administrator password</label>
    <input id="password" name="password" type="password" autocomplete="new-password" required>
    <button type="submit">Generate hash</button>
</form>
<?php if ($hash !== ''): ?>
    <label for="hash">Password hash</label>
    <textarea id="hash" readonly><?= htmlspecialchars($hash, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') ?></textarea>
<?php endif; ?>
</body>
</html>
