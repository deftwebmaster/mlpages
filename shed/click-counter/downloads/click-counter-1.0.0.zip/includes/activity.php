<?php

declare(strict_types=1);

function cc_referrer_domain(): ?string
{
    $ref = (string) ($_SERVER['HTTP_REFERER'] ?? '');
    if ($ref === '' || strlen($ref) > 2048 || preg_match('/[\x00-\x1F\x7F]/', $ref)) {
        return null;
    }
    $host = parse_url($ref, PHP_URL_HOST);
    if (!is_string($host) || $host === '') {
        return null;
    }
    return substr(strtolower($host), 0, 190);
}

function cc_make_event(array $link, string $result): array
{
    return [
        'link_id' => $link['id'] ?? '',
        'link_name' => $link['name'] ?? '',
        'slug' => $link['slug'] ?? '',
        'timestamp' => cc_now(),
        'result' => $result,
        'referrer_domain' => !empty($link['track_referrer']) || (bool) cc_config('track_referrer_domains') ? cc_referrer_domain() : null,
        'device_type' => !empty($link['track_device']) || (bool) cc_config('track_device_category') ? cc_device_type() : null,
        'visitor_hash' => null,
    ];
}

function cc_add_recent_event(array &$eventsData, array $event): void
{
    $events = $eventsData['events'] ?? [];
    array_unshift($events, $event);
    $limit = max(1, (int) cc_config('recent_activity_limit'));
    $eventsData['events'] = array_slice($events, 0, $limit);
}

function cc_recent_events(int $limit = 20, ?string $linkId = null): array
{
    $data = cc_read_json('recent-events');
    $events = $data['events'] ?? [];
    if ($linkId !== null) {
        $events = array_values(array_filter($events, static fn (array $event): bool => ($event['link_id'] ?? '') === $linkId));
    }
    return array_slice($events, 0, $limit);
}
