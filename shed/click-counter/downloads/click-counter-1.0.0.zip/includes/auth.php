<?php

declare(strict_types=1);

function cc_start_session(): void
{
    if (session_status() === PHP_SESSION_ACTIVE) {
        return;
    }
    $secure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'secure' => $secure,
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_name('cc_admin');
    session_start();
}

function cc_password_configured(): bool
{
    $hash = (string) cc_config('admin_password_hash');
    return $hash !== '' && $hash !== 'REPLACE_WITH_PASSWORD_HASH';
}

function cc_admin_logged_in(): bool
{
    cc_start_session();
    if (empty($_SESSION['admin_authenticated'])) {
        return false;
    }
    $last = (int) ($_SESSION['last_activity'] ?? 0);
    $timeout = (int) cc_config('session_timeout_minutes') * 60;
    if ($last > 0 && time() - $last > $timeout) {
        cc_logout(false);
        return false;
    }
    $_SESSION['last_activity'] = time();
    return true;
}

function cc_require_admin(): void
{
    cc_start_session();
    if (!cc_admin_logged_in()) {
        header('Location: ' . cc_base_url('admin/login.php'));
        exit;
    }
}

function cc_attempt_login(string $password): bool
{
    if (cc_login_is_rate_limited()) {
        return false;
    }
    $hash = (string) cc_config('admin_password_hash');
    if (!cc_password_configured() || !password_verify($password, $hash)) {
        cc_login_register_failure();
        cc_log('Failed administrator login attempt.');
        return false;
    }
    cc_login_clear_failures();
    session_regenerate_id(true);
    $_SESSION['admin_authenticated'] = true;
    $_SESSION['last_activity'] = time();
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    cc_log('Administrator logged in.');
    return true;
}

function cc_logout(bool $redirect = true): void
{
    cc_start_session();
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $params['path'], $params['domain'] ?? '', (bool) $params['secure'], (bool) $params['httponly']);
    }
    session_destroy();
    if ($redirect) {
        header('Location: ' . cc_base_url('admin/login.php'));
        exit;
    }
}
