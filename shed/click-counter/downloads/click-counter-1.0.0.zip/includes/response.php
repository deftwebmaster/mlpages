<?php

declare(strict_types=1);

function cc_redirect_admin(string $path): never
{
    header('Location: ' . cc_base_url('admin/' . ltrim($path, '/')));
    exit;
}

function cc_public_error(string $title, string $message, int $status = 404): never
{
    http_response_code($status);
    cc_send_public_error_headers();
    $appName = cc_config('app_name');
    require cc_root_path('templates/public-error.php');
    exit;
}

function cc_admin_error(string $message, int $status = 500): never
{
    http_response_code($status);
    cc_send_admin_headers();
    $pageTitle = 'Error';
    $content = '<section class="panel"><h1>Something needs attention</h1><p>' . cc_h($message) . '</p></section>';
    require cc_root_path('templates/admin-layout.php');
    exit;
}
