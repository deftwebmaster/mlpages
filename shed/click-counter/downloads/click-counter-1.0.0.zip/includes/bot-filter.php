<?php

declare(strict_types=1);

function cc_device_type(?string $ua = null): string
{
    $ua = strtolower($ua ?? (string) ($_SERVER['HTTP_USER_AGENT'] ?? ''));
    if ($ua === '') {
        return 'unknown';
    }
    if (cc_is_known_bot($ua)) {
        return 'bot';
    }
    if (str_contains($ua, 'ipad') || str_contains($ua, 'tablet')) {
        return 'tablet';
    }
    if (str_contains($ua, 'mobile') || str_contains($ua, 'iphone') || str_contains($ua, 'android')) {
        return 'mobile';
    }
    return 'desktop';
}

function cc_is_known_bot(?string $ua = null): bool
{
    $ua = strtolower($ua ?? (string) ($_SERVER['HTTP_USER_AGENT'] ?? ''));
    if ($ua === '') {
        return false;
    }
    $needles = [
        'bot', 'crawl', 'spider', 'slurp', 'mediapartners', 'preview',
        'facebookexternalhit', 'twitterbot', 'linkedinbot', 'discordbot',
        'slackbot', 'uptime', 'monitor', 'scanner', 'validator',
    ];
    foreach ($needles as $needle) {
        if (str_contains($ua, $needle)) {
            return true;
        }
    }
    return false;
}

function cc_should_ignore_bot(array $link): bool
{
    $mode = (string) ($link['bot_mode'] ?? cc_config('default_bot_mode'));
    return $mode !== 'count_all' && cc_is_known_bot();
}
