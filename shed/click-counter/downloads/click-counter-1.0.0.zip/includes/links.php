<?php

declare(strict_types=1);

function cc_all_links(bool $includeArchived = true): array
{
    $data = cc_read_json('links');
    $links = $data['links'] ?? [];
    if (!$includeArchived) {
        $links = array_values(array_filter($links, static fn (array $link): bool => ($link['status'] ?? '') !== 'archived'));
    }
    usort($links, static fn (array $a, array $b): int => strcmp((string) ($b['created_at'] ?? ''), (string) ($a['created_at'] ?? '')));
    return $links;
}

function cc_find_link_by_slug(string $slug): ?array
{
    $slug = cc_slugify($slug);
    foreach (cc_all_links() as $link) {
        if (($link['slug'] ?? '') === $slug) {
            return $link;
        }
    }
    return null;
}

function cc_find_link_by_id(string $id): ?array
{
    foreach (cc_all_links() as $link) {
        if (($link['id'] ?? '') === $id) {
            return $link;
        }
    }
    return null;
}

function cc_effective_status(array $link): string
{
    $status = (string) ($link['status'] ?? 'disabled');
    if ($status !== 'active') {
        return $status;
    }
    if (!empty($link['expires_at'])) {
        try {
            if (new DateTimeImmutable((string) $link['expires_at']) <= new DateTimeImmutable('now', new DateTimeZone('UTC'))) {
                return 'expired';
            }
        } catch (Throwable) {
            return 'misconfigured';
        }
    }
    $max = $link['maximum_clicks'] ?? null;
    if ($max !== null && (int) $max > 0 && (int) ($link['total_clicks'] ?? 0) >= (int) $max) {
        return 'limit_reached';
    }
    if (($link['type'] ?? '') === 'protected_download') {
        $file = (string) ($link['stored_filename'] ?? '');
        if ($file === '' || !cc_protected_file_path($file)) {
            return 'missing_file';
        }
    }
    if (in_array(($link['type'] ?? ''), ['redirect', 'external_download'], true)) {
        [$ok] = cc_validate_redirect_url((string) ($link['destination_url'] ?? ''));
        if (!$ok) {
            return 'misconfigured';
        }
    }
    return 'active';
}

function cc_status_label(string $status): string
{
    return [
        'active' => 'Active',
        'disabled' => 'Disabled',
        'archived' => 'Archived',
        'expired' => 'Expired',
        'limit_reached' => 'Limit reached',
        'missing_file' => 'Missing file',
        'misconfigured' => 'Misconfigured',
    ][$status] ?? ucfirst(str_replace('_', ' ', $status));
}

function cc_tracking_url(array $link): string
{
    $slug = rawurlencode((string) $link['slug']);
    return match ($link['type'] ?? 'redirect') {
        'external_download', 'protected_download' => cc_base_url('download/' . $slug),
        default => cc_base_url('go/' . $slug),
    };
}

function cc_link_payload(array $validated, ?array $existing = null): array
{
    $now = cc_now();
    return array_replace($existing ?? [], [
        'id' => $existing['id'] ?? cc_random_id('lnk'),
        'slug' => $validated['slug'],
        'name' => $validated['name'],
        'description' => $validated['description'],
        'type' => $validated['type'],
        'destination_url' => $validated['destination_url'],
        'status' => $validated['status'],
        'redirect_status' => $validated['redirect_status'],
        'public_counter_enabled' => $validated['public_counter_enabled'],
        'total_clicks' => (int) ($existing['total_clicks'] ?? 0),
        'estimated_unique_clicks' => (int) ($existing['estimated_unique_clicks'] ?? 0),
        'created_at' => $existing['created_at'] ?? $now,
        'updated_at' => $now,
        'last_clicked_at' => $existing['last_clicked_at'] ?? null,
        'expires_at' => $validated['expires_at'],
        'maximum_clicks' => $validated['maximum_clicks'],
        'deduplication_seconds' => $validated['deduplication_seconds'],
        'bot_mode' => $validated['bot_mode'],
        'track_referrer' => $validated['track_referrer'],
        'track_device' => $validated['track_device'],
        'estimate_unique' => $validated['estimate_unique'],
        'notes' => $validated['notes'],
    ]);
}

function cc_save_link(array $link): void
{
    cc_update_json('links', static function (array &$data) use ($link): void {
        $links = $data['links'] ?? [];
        $saved = false;
        foreach ($links as $index => $existing) {
            if (($existing['slug'] ?? '') === ($link['slug'] ?? '') && ($existing['id'] ?? '') !== ($link['id'] ?? '')) {
                throw new RuntimeException('That slug was just taken by another request.');
            }
            if (($existing['id'] ?? '') === $link['id']) {
                $links[$index] = $link;
                $saved = true;
                break;
            }
        }
        if (!$saved) {
            $links[] = $link;
        }
        $data['links'] = array_values($links);
    });
}

function cc_delete_link(string $id, bool $deleteStats = true, bool $deleteFile = false): void
{
    cc_create_backup('before-delete-link');
    $deleted = null;
    cc_update_json('links', static function (array &$data) use ($id, &$deleted): void {
        $links = [];
        foreach (($data['links'] ?? []) as $link) {
            if (($link['id'] ?? '') === $id) {
                $deleted = $link;
                continue;
            }
            $links[] = $link;
        }
        $data['links'] = $links;
    });
    if ($deleteStats) {
        cc_update_json('daily-stats', static function (array &$data) use ($id): void {
            unset($data['links'][$id]);
        });
    }
    if ($deleteFile && is_array($deleted ?? null) && !empty($deleted['stored_filename'])) {
        $stillReferenced = false;
        foreach (cc_all_links() as $link) {
            if (($link['stored_filename'] ?? '') === $deleted['stored_filename']) {
                $stillReferenced = true;
                break;
            }
        }
        if (!$stillReferenced && ($path = cc_protected_file_path((string) $deleted['stored_filename']))) {
            @unlink($path);
        }
    }
}

function cc_duplicate_link(string $id): ?array
{
    $source = cc_find_link_by_id($id);
    if (!$source) {
        return null;
    }
    $copy = $source;
    $copy['id'] = cc_random_id('lnk');
    $copy['slug'] = cc_slugify(($source['slug'] ?? 'copy') . '-' . substr(bin2hex(random_bytes(3)), 0, 6));
    $copy['name'] = ($source['name'] ?? 'Link') . ' Copy';
    $copy['total_clicks'] = 0;
    $copy['estimated_unique_clicks'] = 0;
    $copy['created_at'] = cc_now();
    $copy['updated_at'] = cc_now();
    $copy['last_clicked_at'] = null;
    if (($source['type'] ?? '') === 'protected_download' && !empty($source['stored_filename'])) {
        $path = cc_protected_file_path((string) $source['stored_filename']);
        if ($path) {
            $stored = 'file_' . gmdate('YmdHis') . '_' . bin2hex(random_bytes(8)) . '.bin';
            @copy($path, rtrim((string) cc_config('files_path'), '/') . '/' . $stored);
            $copy['stored_filename'] = $stored;
        }
    }
    cc_save_link($copy);
    return $copy;
}
