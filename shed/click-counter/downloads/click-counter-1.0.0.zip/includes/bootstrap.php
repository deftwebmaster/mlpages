<?php

declare(strict_types=1);

require_once __DIR__ . '/helpers.php';
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/security.php';
require_once __DIR__ . '/response.php';
require_once __DIR__ . '/storage.php';
require_once __DIR__ . '/backup.php';
require_once __DIR__ . '/validation.php';
require_once __DIR__ . '/bot-filter.php';
require_once __DIR__ . '/rate-limit.php';
require_once __DIR__ . '/csrf.php';
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/activity.php';
require_once __DIR__ . '/statistics.php';
require_once __DIR__ . '/links.php';
require_once __DIR__ . '/counters.php';
require_once __DIR__ . '/downloads.php';
require_once __DIR__ . '/export.php';

set_exception_handler(static function (Throwable $e): void {
    cc_log('Unhandled error: ' . $e->getMessage());
    if ((bool) cc_config('debug')) {
        throw $e;
    }
    if (str_starts_with(cc_current_url_path(), '/admin')) {
        cc_admin_error('The request could not be completed. No private details were exposed.');
    }
    cc_public_error('Temporarily unavailable', 'This request could not be completed right now.', 503);
});

cc_storage_bootstrap();
