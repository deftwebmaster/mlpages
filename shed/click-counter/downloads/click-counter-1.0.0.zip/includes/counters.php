<?php

declare(strict_types=1);

function cc_count_request(string $slug, array $allowedTypes): array
{
    $slug = cc_slugify($slug);
    return cc_update_counter_files(static function (array &$data) use ($slug, $allowedTypes): array {
        $index = null;
        foreach (($data['links']['links'] ?? []) as $i => $link) {
            if (($link['slug'] ?? '') === $slug) {
                $index = $i;
                break;
            }
        }
        if ($index === null) {
            return ['ok' => false, 'status' => 'missing', 'link' => null, 'counted' => false];
        }
        $link = $data['links']['links'][$index];
        if (!in_array((string) ($link['type'] ?? ''), $allowedTypes, true)) {
            return ['ok' => false, 'status' => 'misconfigured', 'link' => $link, 'counted' => false];
        }
        $effective = cc_effective_status($link);
        if ($effective !== 'active') {
            cc_add_recent_event($data['events'], cc_make_event($link, $effective));
            return ['ok' => false, 'status' => $effective, 'link' => $link, 'counted' => false];
        }
        if (cc_should_ignore_bot($link)) {
            cc_add_recent_event($data['events'], cc_make_event($link, 'bot_ignored'));
            return ['ok' => true, 'status' => 'bot_ignored', 'link' => $link, 'counted' => false];
        }
        $visitorHash = null;
        $dedupe = (int) ($link['deduplication_seconds'] ?? 0);
        $records = $data['visitors']['records'] ?? [];
        if ($dedupe > 0) {
            $visitorHash = 'dedupe_' . cc_private_hash(($link['id'] ?? '') . '|' . cc_client_ip() . '|' . cc_device_type());
            $expiresAt = (int) ($records[$visitorHash]['expires_at'] ?? 0);
            if ($expiresAt > time()) {
                cc_add_recent_event($data['events'], cc_make_event($link, 'duplicate_suppressed'));
                return ['ok' => true, 'status' => 'duplicate_suppressed', 'link' => $link, 'counted' => false];
            }
            $records[$visitorHash] = ['link_id' => $link['id'], 'expires_at' => time() + $dedupe];
            foreach ($records as $key => $record) {
                if ((int) ($record['expires_at'] ?? 0) < time()) {
                    unset($records[$key]);
                }
            }
        }
        $isEstimatedUnique = false;
        if (!empty($link['estimate_unique'])) {
            $uniqueHash = 'unique_' . cc_private_hash(($link['id'] ?? '') . '|' . cc_client_ip() . '|' . cc_device_type() . '|' . gmdate('Y-m-d'));
            if (empty($records[$uniqueHash]) || (int) ($records[$uniqueHash]['expires_at'] ?? 0) < time()) {
                $isEstimatedUnique = true;
                $records[$uniqueHash] = ['link_id' => $link['id'], 'expires_at' => time() + 86400];
            }
        }
        $data['visitors']['records'] = $records;
        $max = $link['maximum_clicks'] ?? null;
        if ($max !== null && (int) ($link['total_clicks'] ?? 0) >= (int) $max) {
            cc_add_recent_event($data['events'], cc_make_event($link, 'limit_reached'));
            return ['ok' => false, 'status' => 'limit_reached', 'link' => $link, 'counted' => false];
        }
        $link['total_clicks'] = ((int) ($link['total_clicks'] ?? 0)) + 1;
        $link['last_clicked_at'] = cc_now();
        $link['updated_at'] = cc_now();
        if ($isEstimatedUnique) {
            $link['estimated_unique_clicks'] = ((int) ($link['estimated_unique_clicks'] ?? 0)) + 1;
        }
        $day = cc_today_key();
        $id = (string) $link['id'];
        if (!isset($data['daily']['links'][$id]) || !is_array($data['daily']['links'][$id])) {
            $data['daily']['links'][$id] = [];
        }
        $data['daily']['links'][$id][$day] = ((int) ($data['daily']['links'][$id][$day] ?? 0)) + 1;
        $event = cc_make_event($link, 'counted');
        $event['visitor_hash'] = null;
        cc_add_recent_event($data['events'], $event);
        $data['links']['links'][$index] = $link;
        return ['ok' => true, 'status' => 'counted', 'link' => $link, 'counted' => true];
    });
}
