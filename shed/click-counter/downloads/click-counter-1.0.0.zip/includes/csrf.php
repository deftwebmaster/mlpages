<?php

declare(strict_types=1);

function cc_csrf_token(): string
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return (string) $_SESSION['csrf_token'];
}

function cc_csrf_field(): string
{
    return '<input type="hidden" name="csrf_token" value="' . cc_h(cc_csrf_token()) . '">';
}

function cc_require_csrf(): void
{
    $token = (string) ($_POST['csrf_token'] ?? '');
    if ($token === '' || empty($_SESSION['csrf_token']) || !hash_equals((string) $_SESSION['csrf_token'], $token)) {
        cc_admin_error('The form could not be accepted because its security token expired. Please try again.', 403);
    }
}
