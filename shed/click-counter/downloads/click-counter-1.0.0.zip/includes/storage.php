<?php

declare(strict_types=1);

function cc_storage_path(string $relative = ''): string
{
    $base = rtrim((string) cc_config('storage_path'), '/');
    return $relative === '' ? $base : $base . '/' . ltrim($relative, '/');
}

function cc_storage_bootstrap(): void
{
    $dirs = ['', 'data', 'files', 'backups', 'logs', 'locks', 'temporary'];
    foreach ($dirs as $dir) {
        $path = cc_storage_path($dir);
        if (!is_dir($path)) {
            @mkdir($path, 0750, true);
        }
    }
    $files = [
        'data/links.json' => ['schema_version' => 1, 'links' => []],
        'data/daily-stats.json' => ['schema_version' => 1, 'links' => []],
        'data/recent-events.json' => ['schema_version' => 1, 'events' => []],
        'data/rate-limits.json' => ['schema_version' => 1, 'records' => []],
        'data/visitor-hashes.json' => ['schema_version' => 1, 'records' => []],
        'data/settings.json' => ['schema_version' => 1, 'settings' => []],
    ];
    foreach ($files as $relative => $initial) {
        $path = cc_storage_path($relative);
        if (!is_file($path)) {
            cc_atomic_write_json($path, $initial);
        }
    }
    foreach (['.htaccess', 'index.php'] as $guard) {
        $path = cc_storage_path($guard);
        if (!is_file($path)) {
            @file_put_contents($path, $guard === '.htaccess' ? "Require all denied\nDeny from all\n" : "<?php\nhttp_response_code(404);\n");
        }
    }
}

function cc_log(string $message): void
{
    $dir = cc_storage_path('logs');
    if (!is_dir($dir)) {
        @mkdir($dir, 0750, true);
    }
    $path = $dir . '/app.log';
    if (is_file($path) && filesize($path) > 1048576) {
        @rename($path, $dir . '/app-' . gmdate('Ymd-His') . '.log');
    }
    @file_put_contents($path, '[' . cc_now() . '] ' . $message . PHP_EOL, FILE_APPEND | LOCK_EX);
}

function cc_json_path(string $name): string
{
    return cc_storage_path('data/' . $name . '.json');
}

function cc_lock_path(string $name): string
{
    return cc_storage_path('locks/' . $name . '.lock');
}

function cc_read_json_file(string $path): array
{
    if (!is_file($path)) {
        throw new RuntimeException('Data file is missing.');
    }
    $raw = file_get_contents($path);
    if ($raw === false) {
        throw new RuntimeException('Data file could not be read.');
    }
    $data = json_decode($raw, true);
    if (!is_array($data) || json_last_error() !== JSON_ERROR_NONE) {
        $corrupt = $path . '.corrupt-' . gmdate('Ymd-His');
        @copy($path, $corrupt);
        cc_log('Malformed JSON preserved at ' . basename($corrupt));
        throw new RuntimeException('Data file contains malformed JSON.');
    }
    return $data;
}

function cc_read_json(string $name): array
{
    return cc_read_json_file(cc_json_path($name));
}

function cc_atomic_write_json(string $path, array $data): void
{
    $json = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
    if (!is_string($json)) {
        throw new RuntimeException('Data could not be encoded as JSON.');
    }
    $json .= PHP_EOL;
    $tmp = dirname($path) . '/.' . basename($path) . '.' . bin2hex(random_bytes(6)) . '.tmp';
    $handle = fopen($tmp, 'wb');
    if ($handle === false) {
        throw new RuntimeException('Temporary data file could not be created.');
    }
    try {
        if (fwrite($handle, $json) === false) {
            throw new RuntimeException('Temporary data file could not be written.');
        }
        fflush($handle);
        fclose($handle);
        $handle = null;
        json_decode((string) file_get_contents($tmp), true, flags: JSON_THROW_ON_ERROR);
        if (!@rename($tmp, $path)) {
            throw new RuntimeException('Data file could not be replaced atomically.');
        }
        @chmod($path, 0640);
    } finally {
        if (is_resource($handle)) {
            fclose($handle);
        }
        if (is_file($tmp)) {
            @unlink($tmp);
        }
    }
}

function cc_with_lock(string $name, callable $callback): mixed
{
    $lockFile = cc_lock_path($name);
    $handle = fopen($lockFile, 'c');
    if ($handle === false) {
        throw new RuntimeException('Lock file could not be opened.');
    }
    $start = microtime(true);
    try {
        do {
            if (flock($handle, LOCK_EX | LOCK_NB)) {
                return $callback();
            }
            usleep(25000);
        } while (microtime(true) - $start < 10);
        throw new RuntimeException('Timed out while waiting for data lock.');
    } finally {
        flock($handle, LOCK_UN);
        fclose($handle);
    }
}

function cc_update_json(string $name, callable $callback): mixed
{
    return cc_with_lock('data', static function () use ($name, $callback): mixed {
        $path = cc_json_path($name);
        $data = cc_read_json_file($path);
        $result = $callback($data);
        if (!is_array($data)) {
            throw new RuntimeException('Updated data is invalid.');
        }
        cc_atomic_write_json($path, $data);
        return $result;
    });
}

function cc_update_counter_files(callable $callback): mixed
{
    // Public click increments use the same aggregate data lock as admin writes
    // so link edits, resets, limits, daily counts, hashes, and activity events
    // cannot overwrite one another during mixed traffic.
    return cc_with_lock('data', static function () use ($callback): mixed {
        $paths = [
            'links' => cc_json_path('links'),
            'daily' => cc_json_path('daily-stats'),
            'events' => cc_json_path('recent-events'),
            'visitors' => cc_json_path('visitor-hashes'),
        ];
        $data = [
            'links' => cc_read_json_file($paths['links']),
            'daily' => cc_read_json_file($paths['daily']),
            'events' => cc_read_json_file($paths['events']),
            'visitors' => cc_read_json_file($paths['visitors']),
        ];
        $result = $callback($data);
        cc_atomic_write_json($paths['links'], $data['links']);
        cc_atomic_write_json($paths['daily'], $data['daily']);
        cc_atomic_write_json($paths['events'], $data['events']);
        cc_atomic_write_json($paths['visitors'], $data['visitors']);
        return $result;
    });
}
