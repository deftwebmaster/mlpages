<?php

declare(strict_types=1);

function cc_csv_cell(mixed $value): string
{
    $value = (string) $value;
    if ($value !== '' && in_array($value[0], ['=', '+', '-', '@'], true)) {
        $value = "'" . $value;
    }
    return $value;
}

function cc_send_links_csv(?string $id = null): never
{
    $links = cc_all_links();
    if ($id !== null) {
        $links = array_values(array_filter($links, static fn (array $link): bool => ($link['id'] ?? '') === $id));
    }
    header('Content-Type: text/csv; charset=UTF-8');
    header('Content-Disposition: attachment; filename="click-counter-links-' . gmdate('Ymd-His') . '.csv"');
    $out = fopen('php://output', 'wb');
    if ($out === false) {
        exit;
    }
    fputcsv($out, ['Link ID', 'Name', 'Slug', 'Type', 'Status', 'Destination or File', 'Total Clicks', 'Estimated Unique Clicks', 'Clicks Today', 'Created', 'Last Clicked', 'Expiration', 'Maximum Clicks']);
    foreach ($links as $link) {
        $today = cc_daily_counts_for_link((string) $link['id'])[cc_today_key()] ?? 0;
        fputcsv($out, array_map('cc_csv_cell', [
            $link['id'] ?? '',
            $link['name'] ?? '',
            $link['slug'] ?? '',
            $link['type'] ?? '',
            cc_status_label(cc_effective_status($link)),
            ($link['type'] ?? '') === 'protected_download' ? ($link['original_filename'] ?? '') : ($link['destination_url'] ?? ''),
            $link['total_clicks'] ?? 0,
            $link['estimated_unique_clicks'] ?? 0,
            $today,
            $link['created_at'] ?? '',
            $link['last_clicked_at'] ?? '',
            $link['expires_at'] ?? '',
            $link['maximum_clicks'] ?? '',
        ]));
    }
    fclose($out);
    exit;
}
