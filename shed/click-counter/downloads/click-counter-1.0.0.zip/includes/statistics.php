<?php

declare(strict_types=1);

function cc_daily_counts_for_link(string $linkId): array
{
    $data = cc_read_json('daily-stats');
    return is_array($data['links'][$linkId] ?? null) ? $data['links'][$linkId] : [];
}

function cc_total_for_period(?string $linkId, int $days): int
{
    $data = cc_read_json('daily-stats');
    $tz = new DateTimeZone(cc_config('timezone'));
    $sum = 0;
    for ($i = 0; $i < $days; $i++) {
        $day = (new DateTimeImmutable('today', $tz))->modify("-{$i} days")->format('Y-m-d');
        if ($linkId) {
            $sum += (int) ($data['links'][$linkId][$day] ?? 0);
        } else {
            foreach (($data['links'] ?? []) as $counts) {
                $sum += (int) ($counts[$day] ?? 0);
            }
        }
    }
    return $sum;
}

function cc_chart_series(?string $linkId = null, int $days = 30): array
{
    $data = cc_read_json('daily-stats');
    $tz = new DateTimeZone(cc_config('timezone'));
    $series = [];
    for ($i = $days - 1; $i >= 0; $i--) {
        $day = (new DateTimeImmutable('today', $tz))->modify("-{$i} days")->format('Y-m-d');
        $count = 0;
        if ($linkId) {
            $count = (int) ($data['links'][$linkId][$day] ?? 0);
        } else {
            foreach (($data['links'] ?? []) as $counts) {
                $count += (int) ($counts[$day] ?? 0);
            }
        }
        $series[] = ['date' => $day, 'count' => $count];
    }
    return $series;
}

function cc_highest_day(string $linkId): ?array
{
    $counts = cc_daily_counts_for_link($linkId);
    if ($counts === []) {
        return null;
    }
    arsort($counts);
    $day = array_key_first($counts);
    return ['date' => $day, 'count' => (int) $counts[$day]];
}
