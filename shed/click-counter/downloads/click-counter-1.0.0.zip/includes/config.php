<?php

declare(strict_types=1);

function cc_load_config(): array
{
    $path = cc_root_path('config.php');
    if (!is_file($path)) {
        $path = cc_root_path('config.example.php');
    }
    $config = require $path;
    if (!is_array($config)) {
        throw new RuntimeException('Configuration file must return an array.');
    }

    $defaults = [
        'app_name' => 'Click Counter',
        'tagline' => 'Simple click and download tracking for your own website.',
        'base_url' => '',
        'timezone' => 'UTC',
        'admin_password_hash' => '',
        'session_timeout_minutes' => 30,
        'login_max_attempts' => 5,
        'login_window_seconds' => 900,
        'storage_path' => cc_root_path('private-storage'),
        'files_path' => cc_root_path('private-storage/files'),
        'default_redirect_status' => 302,
        'default_bot_mode' => 'count_all',
        'default_deduplication_seconds' => 0,
        'track_referrer_domains' => true,
        'track_device_category' => false,
        'estimate_unique_clicks' => false,
        'recent_activity_limit' => 1000,
        'backup_retention' => 10,
        'maximum_upload_bytes' => 104857600,
        'public_counter_cors' => 'disabled',
        'allowed_counter_origins' => [],
        'routing_mode' => 'rewrite',
        'allow_mailto_tel' => false,
        'debug' => false,
        'branding' => [],
    ];

    $config = array_replace_recursive($defaults, $config);
    if (!in_array((int) $config['default_redirect_status'], [301, 302, 307, 308], true)) {
        $config['default_redirect_status'] = 302;
    }
    if (!in_array((string) $config['public_counter_cors'], ['disabled', 'allow_all', 'configured_origins'], true)) {
        $config['public_counter_cors'] = 'disabled';
    }
    if (@timezone_open((string) $config['timezone']) === false) {
        $config['timezone'] = 'UTC';
    }

    return $config;
}

function cc_config(?string $key = null, mixed $default = null): mixed
{
    static $config = null;
    if ($config === null) {
        $config = cc_load_config();
    }
    if ($key === null) {
        return $config;
    }
    return $config[$key] ?? $default;
}
