<?php

declare(strict_types=1);

function cc_protected_file_path(string $storedFilename): ?string
{
    // Protected downloads never trust stored or requested paths directly. Both
    // the configured files directory and candidate file are resolved before use.
    if ($storedFilename === '' || str_contains($storedFilename, '..') || preg_match('/[\/\\\\\x00-\x1F]/', $storedFilename)) {
        return null;
    }
    $base = realpath((string) cc_config('files_path'));
    if ($base === false) {
        return null;
    }
    $candidate = $base . DIRECTORY_SEPARATOR . $storedFilename;
    $real = realpath($candidate);
    if ($real === false || !str_starts_with($real, $base . DIRECTORY_SEPARATOR)) {
        return null;
    }
    if (!is_file($real) || is_link($real) || !is_readable($real)) {
        return null;
    }
    return $real;
}

function cc_store_uploaded_file(array $upload): array
{
    [$ok, $meta, $error] = cc_validate_upload($upload);
    if (!$ok || !is_array($meta)) {
        throw new RuntimeException($error);
    }
    $target = rtrim((string) cc_config('files_path'), '/') . '/' . $meta['stored_filename'];
    if (!move_uploaded_file((string) $meta['tmp_name'], $target)) {
        throw new RuntimeException('The uploaded file could not be moved into private storage.');
    }
    @chmod($target, 0640);
    $meta['sha256'] = hash_file('sha256', $target) ?: '';
    return $meta;
}

function cc_stream_protected_download(array $link): never
{
    $path = cc_protected_file_path((string) ($link['stored_filename'] ?? ''));
    if (!$path) {
        cc_public_error('Unavailable download', 'This download is not available.', 404);
    }
    $filename = cc_safe_filename((string) ($link['original_filename'] ?? 'download'));
    $mime = (string) ($link['mime_type'] ?? 'application/octet-stream');
    $disposition = !empty($link['allow_inline']) ? 'inline' : 'attachment';
    if (!empty($link['force_download'])) {
        $disposition = 'attachment';
    }
    header('Content-Type: ' . str_replace(["\r", "\n"], '', $mime));
    header('Content-Length: ' . (string) filesize($path));
    header('Content-Disposition: ' . $disposition . '; filename="' . addcslashes($filename, "\"\\") . '"');
    header('X-Content-Type-Options: nosniff');
    header('Cache-Control: private, no-store');
    header('Pragma: no-cache');
    header('Expires: 0');
    $handle = fopen($path, 'rb');
    if ($handle === false) {
        cc_log('Protected file stream failed.');
        cc_public_error('Unavailable download', 'This download is temporarily unavailable.', 503);
    }
    while (!feof($handle)) {
        echo fread($handle, 1048576);
        flush();
    }
    fclose($handle);
    exit;
}
