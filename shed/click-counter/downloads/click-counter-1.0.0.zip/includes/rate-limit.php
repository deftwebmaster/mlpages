<?php

declare(strict_types=1);

function cc_rate_limit_key(string $scope): string
{
    return cc_private_hash($scope . '|' . cc_client_ip());
}

function cc_login_is_rate_limited(): bool
{
    $key = cc_rate_limit_key('login');
    $now = time();
    $window = (int) cc_config('login_window_seconds');
    $max = (int) cc_config('login_max_attempts');
    $limited = false;
    cc_update_json('rate-limits', static function (array &$data) use ($key, $now, $window, $max, &$limited): void {
        $records = $data['records'] ?? [];
        $record = $records[$key] ?? ['attempts' => 0, 'first_at' => $now];
        if (($now - (int) $record['first_at']) > $window) {
            $record = ['attempts' => 0, 'first_at' => $now];
        }
        $limited = ((int) $record['attempts']) >= $max;
        $records[$key] = $record;
        foreach ($records as $id => $item) {
            if (($now - (int) ($item['first_at'] ?? $now)) > ($window * 4)) {
                unset($records[$id]);
            }
        }
        $data['records'] = $records;
    });
    return $limited;
}

function cc_login_register_failure(): void
{
    $key = cc_rate_limit_key('login');
    $now = time();
    $window = (int) cc_config('login_window_seconds');
    cc_update_json('rate-limits', static function (array &$data) use ($key, $now, $window): void {
        $records = $data['records'] ?? [];
        $record = $records[$key] ?? ['attempts' => 0, 'first_at' => $now];
        if (($now - (int) $record['first_at']) > $window) {
            $record = ['attempts' => 0, 'first_at' => $now];
        }
        $record['attempts'] = ((int) $record['attempts']) + 1;
        $records[$key] = $record;
        $data['records'] = $records;
    });
}

function cc_login_clear_failures(): void
{
    $key = cc_rate_limit_key('login');
    cc_update_json('rate-limits', static function (array &$data) use ($key): void {
        unset($data['records'][$key]);
    });
}
