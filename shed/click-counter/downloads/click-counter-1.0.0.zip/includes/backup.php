<?php

declare(strict_types=1);

function cc_create_backup(string $reason = 'manual'): string
{
    $backup = [
        'schema_version' => 1,
        'created_at' => cc_now(),
        'reason' => $reason,
        'data' => [
            'links' => cc_read_json('links'),
            'daily-stats' => cc_read_json('daily-stats'),
            'recent-events' => cc_read_json('recent-events'),
            'settings' => cc_read_json('settings'),
        ],
    ];
    $name = 'backup-' . gmdate('Ymd-His') . '-' . preg_replace('/[^a-z0-9_-]+/i', '-', $reason) . '.json';
    $path = cc_storage_path('backups/' . $name);
    cc_atomic_write_json($path, $backup);
    cc_prune_backups();
    return $name;
}

function cc_list_backups(): array
{
    $files = glob(cc_storage_path('backups/*.json')) ?: [];
    rsort($files);
    return array_map(static fn (string $path): array => [
        'name' => basename($path),
        'size' => filesize($path) ?: 0,
        'created' => gmdate('Y-m-d H:i', filemtime($path) ?: time()),
    ], $files);
}

function cc_prune_backups(): void
{
    $retention = max(1, (int) cc_config('backup_retention'));
    $files = glob(cc_storage_path('backups/*.json')) ?: [];
    rsort($files);
    foreach (array_slice($files, $retention) as $file) {
        @unlink($file);
    }
}

function cc_restore_backup(string $name): void
{
    $safe = basename($name);
    $path = cc_storage_path('backups/' . $safe);
    $data = cc_read_json_file($path);
    if (($data['schema_version'] ?? null) !== 1 || !is_array($data['data'] ?? null)) {
        throw new RuntimeException('Backup schema is invalid.');
    }
    cc_create_backup('before-restore');
    cc_with_lock('data', static function () use ($data): void {
        foreach (['links', 'daily-stats', 'recent-events', 'settings'] as $name) {
            if (!is_array($data['data'][$name] ?? null)) {
                throw new RuntimeException('Backup is missing ' . $name . '.');
            }
            cc_atomic_write_json(cc_json_path($name), $data['data'][$name]);
        }
    });
}
