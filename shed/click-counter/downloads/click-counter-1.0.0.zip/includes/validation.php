<?php

declare(strict_types=1);

function cc_reserved_slugs(): array
{
    return ['admin', 'login', 'logout', 'assets', 'api', 'download', 'go', 'storage', 'config', 'tools', 'index'];
}

function cc_validate_slug(string $slug, ?string $currentId = null): array
{
    $slug = cc_slugify($slug);
    if (strlen($slug) < 2 || strlen($slug) > 80) {
        return [false, $slug, 'Use a slug between 2 and 80 characters.'];
    }
    if (!preg_match('/^[a-z0-9][a-z0-9_-]*[a-z0-9]$/', $slug)) {
        return [false, $slug, 'Slugs may contain letters, numbers, hyphens, and underscores.'];
    }
    if (in_array($slug, cc_reserved_slugs(), true)) {
        return [false, $slug, 'That slug is reserved.'];
    }
    $existing = cc_find_link_by_slug($slug);
    if ($existing && ($currentId === null || $existing['id'] !== $currentId)) {
        return [false, $slug, 'That slug is already in use.'];
    }
    return [true, $slug, ''];
}

function cc_validate_link_input(array $input, ?array $existing = null): array
{
    $errors = [];
    $name = trim((string) ($input['name'] ?? ''));
    if ($name === '') {
        $errors['name'] = 'Enter a link name.';
    }
    $type = (string) ($input['type'] ?? 'redirect');
    if (!in_array($type, ['redirect', 'external_download', 'protected_download'], true)) {
        $errors['type'] = 'Choose a valid link type.';
    }
    [$slugOk, $slug, $slugError] = cc_validate_slug((string) ($input['slug'] ?? $name), $existing['id'] ?? null);
    if (!$slugOk) {
        $errors['slug'] = $slugError;
    }

    $destination = trim((string) ($input['destination_url'] ?? ''));
    if (in_array($type, ['redirect', 'external_download'], true)) {
        [$urlOk, $destination, $urlError] = cc_validate_redirect_url($destination);
        if (!$urlOk) {
            $errors['destination_url'] = $urlError;
        }
    }

    $redirectStatus = (int) ($input['redirect_status'] ?? cc_config('default_redirect_status'));
    if (!in_array($redirectStatus, [301, 302, 307, 308], true)) {
        $redirectStatus = 302;
    }

    $maximumClicks = trim((string) ($input['maximum_clicks'] ?? ''));
    $maximumClicksValue = null;
    if ($maximumClicks !== '') {
        if (!ctype_digit($maximumClicks) || (int) $maximumClicks < 1) {
            $errors['maximum_clicks'] = 'Maximum clicks must be blank or a positive number.';
        } else {
            $maximumClicksValue = (int) $maximumClicks;
        }
    }

    $expiresAt = trim((string) ($input['expires_at'] ?? ''));
    $expiresUtc = null;
    if ($expiresAt !== '') {
        try {
            $dt = new DateTimeImmutable($expiresAt, new DateTimeZone(cc_config('timezone')));
            $expiresUtc = $dt->setTimezone(new DateTimeZone('UTC'))->format('Y-m-d\TH:i:s\Z');
        } catch (Throwable) {
            $errors['expires_at'] = 'Enter a valid expiration date and time.';
        }
    }

    $status = (string) ($input['status'] ?? 'active');
    if (!in_array($status, ['active', 'disabled', 'archived'], true)) {
        $status = 'active';
    }

    return [$errors, [
        'name' => $name,
        'slug' => $slug,
        'description' => trim((string) ($input['description'] ?? '')),
        'type' => $type,
        'destination_url' => $destination,
        'status' => $status,
        'redirect_status' => $redirectStatus,
        'public_counter_enabled' => !empty($input['public_counter_enabled']),
        'expires_at' => $expiresUtc,
        'maximum_clicks' => $maximumClicksValue,
        'deduplication_seconds' => max(0, (int) ($input['deduplication_seconds'] ?? cc_config('default_deduplication_seconds'))),
        'bot_mode' => (string) ($input['bot_mode'] ?? cc_config('default_bot_mode')),
        'track_referrer' => !empty($input['track_referrer']),
        'track_device' => !empty($input['track_device']),
        'estimate_unique' => !empty($input['estimate_unique']),
        'notes' => trim((string) ($input['notes'] ?? '')),
    ]];
}

function cc_validate_upload(array $file): array
{
    if (($file['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) {
        return [false, null, 'Choose a file to upload.'];
    }
    if (($file['error'] ?? UPLOAD_ERR_OK) !== UPLOAD_ERR_OK) {
        return [false, null, 'The file upload failed.'];
    }
    if ((int) $file['size'] > (int) cc_config('maximum_upload_bytes')) {
        return [false, null, 'The uploaded file is too large.'];
    }
    $original = cc_safe_filename((string) $file['name']);
    $lower = strtolower($original);
    $blocked = ['php', 'phtml', 'phar', 'cgi', 'pl', 'py', 'sh', 'htaccess', 'user.ini'];
    $parts = explode('.', $lower);
    foreach ($parts as $part) {
        if (in_array($part, $blocked, true)) {
            return [false, null, 'Executable or server configuration files are not allowed.'];
        }
    }
    $tmp = (string) $file['tmp_name'];
    $mime = 'application/octet-stream';
    if (function_exists('finfo_open')) {
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        if ($finfo) {
            $detected = finfo_file($finfo, $tmp);
            if (is_string($detected) && $detected !== '') {
                $mime = $detected;
            }
            finfo_close($finfo);
        }
    }
    $stored = 'file_' . gmdate('YmdHis') . '_' . bin2hex(random_bytes(8)) . '.bin';
    return [true, [
        'tmp_name' => $tmp,
        'stored_filename' => $stored,
        'original_filename' => $original,
        'file_size' => (int) $file['size'],
        'mime_type' => $mime,
    ], ''];
}
