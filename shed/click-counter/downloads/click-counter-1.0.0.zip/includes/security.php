<?php

declare(strict_types=1);

function cc_send_admin_headers(): void
{
    header('X-Content-Type-Options: nosniff');
    header('X-Frame-Options: DENY');
    header('Referrer-Policy: no-referrer');
    header('Cache-Control: no-store');
    header("Content-Security-Policy: default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; base-uri 'self'; form-action 'self'");
    header('Permissions-Policy: geolocation=(), microphone=(), camera=()');
}

function cc_send_public_headers(): void
{
    header('X-Content-Type-Options: nosniff');
    header('Referrer-Policy: strict-origin-when-cross-origin');
}

function cc_send_public_error_headers(): void
{
    header('X-Content-Type-Options: nosniff');
    header('X-Frame-Options: SAMEORIGIN');
    header("Content-Security-Policy: default-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; base-uri 'self'");
}

function cc_validate_redirect_url(string $url): array
{
    $url = trim($url);
    if ($url === '' || preg_match('/[\x00-\x1F\x7F]/', $url)) {
        return [false, '', 'Enter a valid URL without control characters.'];
    }
    if (str_starts_with($url, '//')) {
        return [false, '', 'Protocol-relative URLs are not allowed.'];
    }
    $parts = parse_url($url);
    if (!is_array($parts) || empty($parts['scheme'])) {
        return [false, '', 'The destination must include a URL scheme such as https://.'];
    }
    $scheme = strtolower((string) $parts['scheme']);
    $allowed = ['https', 'http'];
    if ((bool) cc_config('allow_mailto_tel')) {
        $allowed[] = 'mailto';
        $allowed[] = 'tel';
    }
    if (!in_array($scheme, $allowed, true)) {
        return [false, '', 'That URL scheme is not allowed.'];
    }
    if (in_array($scheme, ['http', 'https'], true) && empty($parts['host'])) {
        return [false, '', 'HTTP destinations must include a host.'];
    }
    return [true, $url, ''];
}

function cc_safe_redirect(string $destination, int $status = 302): never
{
    [$ok] = cc_validate_redirect_url($destination);
    if (!$ok) {
        cc_public_error('Link unavailable', 'This link is temporarily unavailable.', 503);
    }
    if (!in_array($status, [301, 302, 307, 308], true)) {
        $status = 302;
    }
    cc_send_public_headers();
    header('Location: ' . str_replace(["\r", "\n"], '', $destination), true, $status);
    exit;
}

function cc_apply_counter_cors(): void
{
    $mode = (string) cc_config('public_counter_cors');
    if ($mode === 'disabled') {
        return;
    }
    if ($mode === 'allow_all') {
        header('Access-Control-Allow-Origin: *');
        return;
    }
    $origin = (string) ($_SERVER['HTTP_ORIGIN'] ?? '');
    $allowed = cc_config('allowed_counter_origins', []);
    if ($origin !== '' && is_array($allowed) && in_array($origin, $allowed, true)) {
        header('Access-Control-Allow-Origin: ' . $origin);
        header('Vary: Origin');
    }
}
