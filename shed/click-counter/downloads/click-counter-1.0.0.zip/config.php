<?php

declare(strict_types=1);

// Copy config.example.php to config.php on your server and replace this file's
// values. This checked-in starter lets local smoke testing work immediately.
return require __DIR__ . '/config.example.php';
