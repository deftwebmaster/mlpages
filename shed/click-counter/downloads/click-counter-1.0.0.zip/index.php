<?php

declare(strict_types=1);

$path = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH);
$path = is_string($path) ? trim($path, '/') : '';

if (preg_match('#(?:^|/)go/([^/]+)$#', $path, $m)) {
    $_GET['slug'] = rawurldecode($m[1]);
    require __DIR__ . '/redirect.php';
    exit;
}
if (preg_match('#(?:^|/)download/([^/]+)$#', $path, $m)) {
    $_GET['slug'] = rawurldecode($m[1]);
    require __DIR__ . '/download.php';
    exit;
}
if (preg_match('#(?:^|/)api/count/([^/]+)$#', $path, $m)) {
    $_GET['slug'] = rawurldecode($m[1]);
    require __DIR__ . '/api/count.php';
    exit;
}
if (preg_match('#(?:^|/)api/count/([^/]+)/json$#', $path, $m)) {
    $_GET['slug'] = rawurldecode($m[1]);
    $_GET['format'] = 'json';
    require __DIR__ . '/api/count.php';
    exit;
}

require_once __DIR__ . '/includes/bootstrap.php';
cc_send_public_error_headers();
$appName = cc_config('app_name');
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= cc_h($appName) ?></title>
    <link rel="stylesheet" href="<?= cc_h(cc_base_url('assets/css/public.css')) ?>">
</head>
<body>
<main class="public-message">
    <h1><?= cc_h($appName) ?></h1>
    <p><?= cc_h(cc_config('tagline')) ?></p>
    <p><a href="<?= cc_h(cc_base_url('admin/')) ?>">Administrator login</a></p>
</main>
</body>
</html>
